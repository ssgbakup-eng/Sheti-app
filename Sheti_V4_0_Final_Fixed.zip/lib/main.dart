import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const ShetiApp());

class ShetiApp extends StatelessWidget {
  const ShetiApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'शेती',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.green,
        scaffoldBackgroundColor: const Color(0xFFF7FAF3),
        inputDecorationTheme: const InputDecorationTheme(border: OutlineInputBorder()),
      ),
      home: const AppShell(),
    );
  }
}

class Gut {
  String no, area, crop, length, remark;
  String rowDirection, numberStart;
  int topRows, bottomRows;
  Map<String, String> marks;
  List<RowLink> links;
  List<int> runningRows;

  Gut({
    required this.no,
    this.area = '',
    this.crop = '',
    this.length = '',
    this.remark = '',
    this.rowDirection = 'उत्तर → दक्षिण',
    this.numberStart = 'पूर्व',
    this.topRows = 0,
    this.bottomRows = 0,
    Map<String, String>? marks,
    List<RowLink>? links,
    List<int>? runningRows,
  })  : marks = marks ?? {'उत्तर': '', 'दक्षिण': '', 'पूर्व': '', 'पश्चिम': ''},
        links = links ?? [],
        runningRows = runningRows ?? [];

  Map<String, dynamic> toJson() => {
        'no': no,
        'area': area,
        'crop': crop,
        'length': length,
        'remark': remark,
        'rowDirection': rowDirection,
        'numberStart': numberStart,
        'topRows': topRows,
        'bottomRows': bottomRows,
        'marks': marks,
        'links': links.map((e) => e.toJson()).toList(),
        'runningRows': runningRows,
      };

  factory Gut.fromJson(Map<String, dynamic> j) => Gut(
        no: '${j['no'] ?? ''}',
        area: '${j['area'] ?? ''}',
        crop: '${j['crop'] ?? ''}',
        length: '${j['length'] ?? ''}',
        remark: '${j['remark'] ?? ''}',
        rowDirection: '${j['rowDirection'] ?? 'उत्तर → दक्षिण'}',
        numberStart: '${j['numberStart'] ?? 'पूर्व'}',
        topRows: int.tryParse('${j['topRows'] ?? 0}') ?? 0,
        bottomRows: int.tryParse('${j['bottomRows'] ?? 0}') ?? 0,
        marks: Map<String, String>.from(j['marks'] ?? const {}),
        links: (j['links'] as List? ?? const [])
            .map((e) => RowLink.fromJson(Map<String, dynamic>.from(e)))
            .toList(),
        runningRows: List<int>.from(j['runningRows'] ?? const []),
      );
}

class RowLink {
  int top;
  List<int> bottom;
  RowLink(this.top, this.bottom);
  Map<String, dynamic> toJson() => {'top': top, 'bottom': bottom};
  factory RowLink.fromJson(Map<String, dynamic> j) => RowLink(
        int.tryParse('${j['top'] ?? 0}') ?? 0,
        List<int>.from(j['bottom'] ?? const []),
      );
}

class AppStore extends ChangeNotifier {
  List<Gut> guts = [];
  String? activeGut;
  String source = 'मोठी नाली';
  bool loading = true;
  final List<String> sources = ['मोठी नाली', 'विहीर', 'बोअर', 'विहीर मोटर'];

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString('guts');
    if (raw != null && raw.isNotEmpty) {
      final decoded = jsonDecode(raw) as List;
      guts = decoded.map((e) => Gut.fromJson(Map<String, dynamic>.from(e))).toList();
    }
    activeGut = p.getString('activeGut');
    if (activeGut == null && guts.isNotEmpty) activeGut = guts.first.no;
    loading = false;
    notifyListeners();
  }

  Future<void> save() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('guts', jsonEncode(guts.map((e) => e.toJson()).toList()));
    if (activeGut != null) {
      await p.setString('activeGut', activeGut!);
    } else {
      await p.remove('activeGut');
    }
  }

  Gut? get active {
    for (final g in guts) {
      if (g.no == activeGut) return g;
    }
    return null;
  }

  void select(String no) {
    activeGut = no;
    save();
    notifyListeners();
  }

  Future<void> upsert(Gut gut) async {
    final i = guts.indexWhere((g) => g.no == gut.no);
    if (i >= 0) {
      guts[i] = gut;
    } else {
      guts.add(gut);
    }
    activeGut = gut.no;
    await save();
    notifyListeners();
  }

  Future<void> remove(String no) async {
    guts.removeWhere((g) => g.no == no);
    if (activeGut == no) activeGut = guts.isEmpty ? null : guts.first.no;
    await save();
    notifyListeners();
  }
}

class AppShell extends StatefulWidget {
  const AppShell({super.key});
  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  final AppStore store = AppStore();
  int tab = 0;

  @override
  void initState() {
    super.initState();
    store.load();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        if (store.loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
        final pages = [
          Dashboard(store: store, onOpen: (i) => setState(() => tab = i)),
          PlotMappingPage(store: store),
          PlotViewPage(store: store),
          WaterPage(store: store),
        ];
        return Scaffold(
          body: pages[tab],
          bottomNavigationBar: NavigationBar(
            selectedIndex: tab,
            onDestinationSelected: (i) => setState(() => tab = i),
            destinations: const [
              NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'मुख्य'),
              NavigationDestination(icon: Icon(Icons.grid_view_outlined), selectedIcon: Icon(Icons.grid_view), label: 'Mapping'),
              NavigationDestination(icon: Icon(Icons.map_outlined), selectedIcon: Icon(Icons.map), label: 'Plot View'),
              NavigationDestination(icon: Icon(Icons.water_drop_outlined), selectedIcon: Icon(Icons.water_drop), label: 'पाणी'),
            ],
          ),
        );
      },
    );
  }
}

class Dashboard extends StatelessWidget {
  final AppStore store;
  final ValueChanged<int> onOpen;
  const Dashboard({super.key, required this.store, required this.onOpen});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('🌾 शेती • मुख्य मेनू')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        _menuCard(context, 'GUT Update', 'Saved GUT आणि त्याचा Plot Map पाहा / Update करा', Icons.edit_note,
            () => Navigator.push(context, MaterialPageRoute(builder: (_) => GutUpdatePage(store: store)))),
        _menuCard(context, 'Plot Mapping', 'सऱ्या, numbering, link आणि split mapping', Icons.grid_view, () => onOpen(1)),
        _menuCard(context, 'Plot Map View', 'प्रत्यक्ष GUT नकाशा + सऱ्या + बांध + References', Icons.map, () => onOpen(2)),
        _menuCard(context, 'पाणी ON / OFF + Live Map', 'सरी निवडा आणि Live status बदला', Icons.water_drop, () => onOpen(3)),
        const SizedBox(height: 12),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Text('सध्याचे GUT: ${store.activeGut ?? 'निवडलेले नाही'}\nएकूण GUT: ${store.guts.length}',
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
          ),
        ),
      ]),
    );
  }

  Widget _menuCard(BuildContext context, String title, String sub, IconData icon, VoidCallback tap) => Card(
        child: InkWell(
          onTap: tap,
          borderRadius: BorderRadius.circular(16),
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Row(children: [
              CircleAvatar(radius: 26, child: Icon(icon)),
              const SizedBox(width: 16),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 4),
                Text(sub),
              ])),
              const Icon(Icons.chevron_right),
            ]),
          ),
        ),
      );
}

class GutUpdatePage extends StatelessWidget {
  final AppStore store;
  const GutUpdatePage({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('GUT Update')),
      body: store.guts.isEmpty
          ? Center(child: FilledButton.icon(onPressed: () => _openForm(context), icon: const Icon(Icons.add), label: const Text('नवीन GUT तयार करा')))
          : ListView(padding: const EdgeInsets.all(12), children: [
              FilledButton.icon(onPressed: () => _openForm(context), icon: const Icon(Icons.add), label: const Text('नवीन GUT')),
              const SizedBox(height: 10),
              ...store.guts.map((g) => Card(
                    child: ExpansionTile(
                      initiallyExpanded: g.no == store.activeGut,
                      title: Text('GUT ${g.no}', style: const TextStyle(fontWeight: FontWeight.bold)),
                      subtitle: Text('${g.crop} • ${g.area} • ${g.length}'),
                      onExpansionChanged: (v) {
                        if (v) store.select(g.no);
                      },
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(10),
                          child: Column(children: [
                            PlotMapPreview(gut: g, compact: true),
                            const SizedBox(height: 10),
                            Row(children: [
                              Expanded(child: FilledButton.icon(onPressed: () => _openForm(context, g), icon: const Icon(Icons.edit), label: const Text('Update'))),
                              const SizedBox(width: 8),
                              IconButton(onPressed: () => _delete(context, g), icon: const Icon(Icons.delete_outline)),
                            ]),
                          ]),
                        ),
                      ],
                    ),
                  )),
            ]),
    );
  }

  void _openForm(BuildContext context, [Gut? g]) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => GutFormPage(store: store, existing: g)));
  }

  Future<void> _delete(BuildContext context, Gut g) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('GUT Delete'),
        content: Text('GUT ${g.no} हटवायचा आहे का?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('नाही')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('होय')),
        ],
      ),
    );
    if (ok == true) await store.remove(g.no);
  }
}

class GutFormPage extends StatefulWidget {
  final AppStore store;
  final Gut? existing;
  const GutFormPage({super.key, required this.store, this.existing});
  @override
  State<GutFormPage> createState() => _GutFormPageState();
}

class _GutFormPageState extends State<GutFormPage> {
  late final TextEditingController no, area, crop, length, remark;
  late String direction, numberStart;
  late final Map<String, TextEditingController> marks;

  @override
  void initState() {
    super.initState();
    final g = widget.existing;
    no = TextEditingController(text: g?.no ?? '');
    area = TextEditingController(text: g?.area ?? '');
    crop = TextEditingController(text: g?.crop ?? '');
    length = TextEditingController(text: g?.length ?? '');
    remark = TextEditingController(text: g?.remark ?? '');
    direction = g?.rowDirection ?? 'उत्तर → दक्षिण';
    numberStart = g?.numberStart ?? 'पूर्व';
    final m = g?.marks ?? {};
    marks = {for (final d in ['उत्तर', 'दक्षिण', 'पूर्व', 'पश्चिम']) d: TextEditingController(text: m[d] ?? '')};
  }

  @override
  void dispose() {
    for (final c in [no, area, crop, length, remark, ...marks.values]) c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.existing == null ? 'नवीन GUT' : 'GUT Update')),
      body: ListView(padding: const EdgeInsets.fromLTRB(16, 16, 16, 110), children: [
        _field('GUT क्रमांक', no),
        _field('क्षेत्रफळ', area),
        _field('पीक', crop),
        _field('लांबी', length),
        _drop('सऱ्यांची दिशा (पाण्याची दिशा)', direction, ['उत्तर → दक्षिण', 'दक्षिण → उत्तर', 'पूर्व → पश्चिम', 'पश्चिम → पूर्व'], (v) => setState(() => direction = v!)),
        _drop('सऱ्यांची नंबरिंग सुरू होण्याची दिशा', numberStart, ['पूर्व', 'पश्चिम', 'उत्तर', 'दक्षिण'], (v) => setState(() => numberStart = v!)),
        const SizedBox(height: 8),
        const Text('चारही दिशांचे Land Mark', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        for (final d in ['उत्तर', 'दक्षिण', 'पूर्व', 'पश्चिम'])
          Padding(padding: const EdgeInsets.only(top: 10), child: TextField(controller: marks[d], decoration: InputDecoration(labelText: '$d Land Mark'))),
        const SizedBox(height: 10),
        _field('Remark', remark, maxLines: 2),
        if (widget.existing != null && widget.existing!.topRows > 0) ...[
          const SizedBox(height: 8),
          const Text('सेव्ह केलेला Plot Map', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          PlotMapPreview(gut: widget.existing!, compact: true),
        ],
      ]),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: FilledButton.icon(onPressed: _save, icon: const Icon(Icons.save), label: Text(widget.existing == null ? 'Save GUT' : 'Update GUT')),
        ),
      ),
    );
  }

  Widget _field(String label, TextEditingController c, {int maxLines = 1}) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: TextField(controller: c, maxLines: maxLines, decoration: InputDecoration(labelText: label)),
      );

  Widget _drop(String label, String value, List<String> items, ValueChanged<String?> onChanged) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: DropdownButtonFormField<String>(
          value: value,
          decoration: InputDecoration(labelText: label),
          items: items.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
          onChanged: onChanged,
        ),
      );

  Future<void> _save() async {
    final gutNo = no.text.trim();
    if (gutNo.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('GUT क्रमांक भरा')));
      return;
    }
    final old = widget.existing;
    if (old == null && widget.store.guts.any((g) => g.no == gutNo)) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('हा GUT क्रमांक आधीच आहे')));
      return;
    }
    final g = Gut(
      no: gutNo,
      area: area.text.trim(),
      crop: crop.text.trim(),
      length: length.text.trim(),
      remark: remark.text.trim(),
      rowDirection: direction,
      numberStart: numberStart,
      topRows: old?.topRows ?? 0,
      bottomRows: old?.bottomRows ?? 0,
      marks: {for (final e in marks.entries) e.key: e.value.text.trim()},
      links: old?.links,
      runningRows: old?.runningRows,
    );
    await widget.store.upsert(g);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('GUT Update सेव्ह झाला')));
      Navigator.pop(context);
    }
  }
}

class PlotMappingPage extends StatefulWidget {
  final AppStore store;
  const PlotMappingPage({super.key, required this.store});
  @override
  State<PlotMappingPage> createState() => _PlotMappingPageState();
}

class _PlotMappingPageState extends State<PlotMappingPage> {
  Gut? get gut => widget.store.active;
  late TextEditingController top, bottom, firstTop, firstBottom, splitTop, splitA, splitB;
  String? loadedNo;

  @override
  void initState() {
    super.initState();
    _makeControllers();
  }

  void _makeControllers() {
    final g = gut;
    for (final c in _controllers) c.dispose();
    top = TextEditingController(text: '${g?.topRows == 0 ? 37 : g?.topRows}');
    bottom = TextEditingController(text: '${g?.bottomRows == 0 ? 40 : g?.bottomRows}');
    firstTop = TextEditingController(text: '1');
    firstBottom = TextEditingController(text: '3');
    splitTop = TextEditingController(text: '12');
    splitA = TextEditingController(text: '15');
    splitB = TextEditingController(text: '16');
    loadedNo = g?.no;
  }

  List<TextEditingController> get _controllers => [
        if (loadedNo != null) top,
        if (loadedNo != null) bottom,
        if (loadedNo != null) firstTop,
        if (loadedNo != null) firstBottom,
        if (loadedNo != null) splitTop,
        if (loadedNo != null) splitA,
        if (loadedNo != null) splitB,
      ];

  @override
  void dispose() {
    for (final c in _controllers) c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final g = gut;
    if (g == null) return _empty();
    if (loadedNo != g.no) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted && loadedNo != widget.store.activeGut) setState(_makeControllers);
      });
    }
    return Scaffold(
      appBar: AppBar(title: Text('Plot Mapping • GUT ${g.no}'), actions: [IconButton(onPressed: () => _selectGut(context), icon: const Icon(Icons.swap_horiz))]),
      body: ListView(padding: const EdgeInsets.fromLTRB(14, 14, 14, 120), children: [
        _info(g),
        const SizedBox(height: 12),
        _numberSection(),
        const SizedBox(height: 12),
        _linkSection(),
        const SizedBox(height: 12),
        const Text('Plot Layout Preview', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        PlotMapPreview(gut: g, compact: true),
      ]),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: FilledButton.icon(onPressed: _saveMapping, icon: const Icon(Icons.save), label: const Text('Plot Update / Save')),
        ),
      ),
    );
  }

  Widget _empty() => Scaffold(
        appBar: AppBar(title: const Text('Plot Mapping')),
        body: Center(child: FilledButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => GutFormPage(store: widget.store))), child: const Text('पहिले GUT तयार करा'))),
      );

  Widget _info(Gut g) => Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('GUT ${g.no} • ${g.area} • ${g.crop}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            Text('सरी दिशा: ${g.rowDirection} • नंबरिंग: ${g.numberStart}'),
            Text('उत्तर: ${g.marks['उत्तर']} | दक्षिण: ${g.marks['दक्षिण']}'),
            Text('पूर्व: ${g.marks['पूर्व']} | पश्चिम: ${g.marks['पश्चिम']}'),
          ]),
        ),
      );

  Widget _numberSection() => Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('सऱ्यांची संख्या', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(child: TextField(controller: top, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'वरची बाजू सऱ्या'))),
              const SizedBox(width: 10),
              Expanded(child: TextField(controller: bottom, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'खालची बाजू सऱ्या'))),
            ]),
            const SizedBox(height: 10),
            const Text('उदा. 37 वर / 40 खाली: वर 1 → खाली 3. खाली 1-2 = Extra/No Link.'),
          ]),
        ),
      );

  Widget _linkSection() => Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Link Mapping', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(child: TextField(controller: firstTop, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'वरची सरी'))),
              const Padding(padding: EdgeInsets.symmetric(horizontal: 8), child: Text('→')),
              Expanded(child: TextField(controller: firstBottom, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'खालील सरी'))),
            ]),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(child: TextField(controller: splitTop, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Split वरची सरी'))),
              const Padding(padding: EdgeInsets.symmetric(horizontal: 8), child: Text('→')),
              Expanded(child: TextField(controller: splitA, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'खाली A'))),
              const SizedBox(width: 6),
              Expanded(child: TextField(controller: splitB, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'खाली B'))),
            ]),
            const SizedBox(height: 10),
            const Text('Split नंतर पुढील links shift होतील. उदा. 12→15,16; 13→17; 14→18; 37→40.'),
          ]),
        ),
      );

  Future<void> _saveMapping() async {
    final g = gut;
    if (g == null) return;
    final tr = int.tryParse(top.text.trim()) ?? 0;
    final br = int.tryParse(bottom.text.trim()) ?? 0;
    if (tr <= 0 || br <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('सऱ्यांची संख्या भरा')));
      return;
    }
    final ft = int.tryParse(firstTop.text.trim()) ?? 1;
    final fb = int.tryParse(firstBottom.text.trim()) ?? 1;
    final st = int.tryParse(splitTop.text.trim()) ?? -1;
    final sa = int.tryParse(splitA.text.trim()) ?? -1;
    final sb = int.tryParse(splitB.text.trim()) ?? -1;
    final links = <RowLink>[];
    for (int i = 1; i <= tr; i++) {
      if (i == st && sa > 0 && sb > 0) {
        links.add(RowLink(i, [sa, sb]));
      } else {
        final offset = i > st ? 1 : 0;
        final b = fb + (i - ft) + offset;
        if (b > 0 && b <= br) links.add(RowLink(i, [b]));
      }
    }
    g.topRows = tr;
    g.bottomRows = br;
    g.links = links;
    await widget.store.save();
    widget.store.notifyListeners();
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Plot Update सेव्ह झाला')));
  }

  Future<void> _selectGut(BuildContext context) async {
    final n = await showDialog<String>(
      context: context,
      builder: (_) => SimpleDialog(
        title: const Text('GUT निवडा'),
        children: widget.store.guts.map((g) => SimpleDialogOption(onPressed: () => Navigator.pop(context, g.no), child: Text('GUT ${g.no}'))).toList(),
      ),
    );
    if (n != null) {
      widget.store.select(n);
      if (mounted) setState(_makeControllers);
    }
  }
}

class PlotViewPage extends StatelessWidget {
  final AppStore store;
  const PlotViewPage({super.key, required this.store});
  @override
  Widget build(BuildContext context) {
    final g = store.active;
    if (g == null) return Scaffold(appBar: AppBar(title: const Text('Plot View')), body: const Center(child: Text('पहिले GUT तयार करा')));
    return Scaffold(
      appBar: AppBar(title: Text('🌾 गट नं. ${g.no} • ${g.area}')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(12),
        child: PlotMapPreview(gut: g, compact: false),
      ),
    );
  }
}

class PlotMapPreview extends StatelessWidget {
  final Gut gut;
  final bool compact;
  const PlotMapPreview({super.key, required this.gut, this.compact = false});

  static String ref(int n) => n.toString().padLeft(2, '0');

  int bottomForTop(int top) {
    for (final l in gut.links) {
      if (l.top == top && l.bottom.isNotEmpty) return l.bottom.first;
    }
    if (gut.topRows <= 0 || gut.bottomRows <= 0) return 0;
    return top <= gut.bottomRows ? top : 0;
  }

  List<int> bottomRefsForTop(int top) {
    for (final l in gut.links) {
      if (l.top == top) return l.bottom;
    }
    final b = bottomForTop(top);
    return b > 0 ? [b] : [];
  }

  @override
  Widget build(BuildContext context) {
    final topCount = gut.topRows;
    final bottomCount = gut.bottomRows;
    final count = topCount > bottomCount ? topCount : bottomCount;
    if (count <= 0) return const Card(child: Padding(padding: EdgeInsets.all(14), child: Text('Plot Mapping अजून सेव्ह केलेले नाही.')));
    final cellW = compact ? 54.0 : 68.0;
    final plotW = count * cellW + 150;
    final plotH = compact ? 250.0 : 330.0;

    return Card(
      clipBehavior: Clip.antiAlias,
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Padding(
          padding: const EdgeInsets.all(10),
          child: Row(children: [
            const Icon(Icons.north, size: 22),
            const SizedBox(width: 6),
            const Text('उत्तर', style: TextStyle(fontWeight: FontWeight.bold)),
            const Spacer(),
            Text('${gut.length.isEmpty ? '—' : gut.length} फूट • ${gut.crop.isEmpty ? 'पीक' : gut.crop}', style: const TextStyle(fontWeight: FontWeight.bold)),
          ]),
        ),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: SizedBox(
            width: plotW,
            height: plotH,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              child: CustomPaint(
                painter: PlotPainter(gut: gut, cellW: cellW, count: count, ref: ref),
              ),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(10, 4, 10, 10),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('उत्तर: ${gut.marks['उत्तर'] ?? ''}'),
            Text('दक्षिण: ${gut.marks['दक्षिण'] ?? ''}'),
            Text('पूर्व: ${gut.marks['पूर्व'] ?? ''}   •   पश्चिम: ${gut.marks['पश्चिम'] ?? ''}'),
            Text('सरी दिशा: ${gut.rowDirection}   •   पाण्याचा प्रवाह: ${gut.rowDirection}'),
          ]),
        ),
      ]),
    );
  }
}

class PlotPainter extends CustomPainter {
  final Gut gut;
  final double cellW;
  final int count;
  final String Function(int) ref;
  PlotPainter({required this.gut, required this.cellW, required this.count, required this.ref});

  @override
  void paint(Canvas canvas, Size size) {
    final border = Paint()..style = PaintingStyle.stroke..strokeWidth = 3..color = Colors.brown;
    final rowPaint = Paint()..strokeWidth = 1.6..color = Colors.green.shade700;
    final activePaint = Paint()..strokeWidth = 4..color = Colors.orange.shade700;
    final roadPaint = Paint()..style = PaintingStyle.fill..color = Colors.grey.shade300;
    final waterPaint = Paint()..strokeWidth = 3..color = Colors.blue.shade600;
    final bundPaint = Paint()..strokeWidth = 6..color = Colors.brown.shade700;

    final left = 70.0;
    final right = left + count * cellW;
    final top = 38.0;
    final bottom = size.height - 48;
    final mid = (top + bottom) / 2;

    canvas.drawRect(Rect.fromLTRB(left - 20, top - 16, right + 20, bottom + 16), border);
    canvas.drawLine(Offset(0, top - 16), Offset(size.width, top - 16), bundPaint);
    canvas.drawLine(Offset(0, bottom + 16), Offset(size.width, bottom + 16), bundPaint);

    _text(canvas, 'रस्ता', const Offset(2, top - 28), 12, Colors.black87, bold: true);
    _text(canvas, 'नाली', Offset(2, bottom + 22), 12, Colors.black87, bold: true);

    for (int i = 0; i < count; i++) {
      final x = left + i * cellW + cellW / 2;
      final topN = i < gut.topRows ? i + 1 : 0;
      final bottomN = i < gut.bottomRows ? (gut.bottomRows - i) : 0;
      final isActive = topN > 0 && gut.runningRows.contains(topN);
      final p = isActive ? activePaint : rowPaint;
      if (topN > 0 || bottomN > 0) {
        canvas.drawLine(Offset(x, top), Offset(x, bottom), p);
      }
      if (topN > 0) {
        _text(canvas, ref(topN), Offset(x - 12, 8), 12, Colors.black, bold: true);
      }
      if (bottomN > 0) {
        _text(canvas, ref(bottomN), Offset(x - 12, bottom + 20), 12, Colors.black, bold: true);
      }
      if (topN > 0) {
        final links = _bottomLinks(topN);
        if (links.isNotEmpty) {
          final label = links.map(ref).join(',');
          _text(canvas, label, Offset(x - 14, mid - 8), 9, Colors.deepPurple, bold: true);
        }
      }
    }

    // Keep the plot as one continuous map. The road/nali labels are shown at
    // the boundaries; do not draw a band through the middle of the crop rows.
    _text(canvas, 'Plot / शेत', Offset(left + 8, mid - 9), 13, Colors.black87, bold: true);

    if (gut.rowDirection.contains('→')) {
      final startX = right + 38;
      final startY = top + 18;
      final endY = bottom - 18;
      canvas.drawLine(Offset(startX, startY), Offset(startX, endY), waterPaint);
      final arrow = Path()
        ..moveTo(startX, endY)
        ..lineTo(startX - 6, endY - 12)
        ..lineTo(startX + 6, endY - 12)
        ..close();
      canvas.drawPath(arrow, waterPaint);
      _text(canvas, '💧', Offset(startX - 10, mid - 9), 16, Colors.blue.shade700);
    }

    _text(canvas, '↑ N', Offset(right + 25, 4), 12, Colors.black, bold: true);
    _text(canvas, 'सरी', Offset(8, mid - 9), 12, Colors.green.shade800, bold: true);
    _text(canvas, 'बांध', Offset(8, top + 2), 12, Colors.brown.shade800, bold: true);
  }

  List<int> _bottomLinks(int top) {
    for (final l in gut.links) {
      if (l.top == top) return l.bottom;
    }
    return [];
  }

  void _text(Canvas canvas, String value, Offset offset, double size, Color color, {bool bold = false}) {
    final tp = TextPainter(
      text: TextSpan(text: value, style: TextStyle(fontSize: size, color: color, fontWeight: bold ? FontWeight.bold : FontWeight.normal)),
      textDirection: TextDirection.ltr,
    )..layout();
    tp.paint(canvas, offset);
  }

  @override
  bool shouldRepaint(covariant PlotPainter oldDelegate) => true;
}

class WaterPage extends StatefulWidget {
  final AppStore store;
  const WaterPage({super.key, required this.store});
  @override
  State<WaterPage> createState() => _WaterPageState();
}

class _WaterPageState extends State<WaterPage> {
  final Set<int> selected = {};

  @override
  Widget build(BuildContext context) {
    final g = widget.store.active;
    if (g == null) return Scaffold(appBar: AppBar(title: const Text('पाणी नियंत्रण')), body: const Center(child: Text('पहिले GUT तयार करा')));
    return Scaffold(
      appBar: AppBar(title: const Text('पाणी नियंत्रण ON / OFF')),
      body: ListView(padding: const EdgeInsets.fromLTRB(14, 14, 14, 110), children: [
        DropdownButtonFormField<String>(
          value: widget.store.source,
          decoration: const InputDecoration(labelText: 'पाणी स्रोत'),
          items: widget.store.sources.map((s) => DropdownMenuItem(value: s, child: Text(s))).toList(),
          onChanged: (v) => setState(() => widget.store.source = v ?? widget.store.source),
        ),
        const SizedBox(height: 12),
        Text('GUT ${g.no} • ${g.crop}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Wrap(
          spacing: 6,
          runSpacing: 6,
          children: List.generate(g.topRows, (i) {
            final n = i + 1;
            final on = g.runningRows.contains(n);
            return FilterChip(
              label: Text(n.toString().padLeft(2, '0')),
              selected: selected.contains(n),
              avatar: CircleAvatar(backgroundColor: on ? Colors.orange : Colors.green, radius: 7),
              onSelected: (v) => setState(() => v ? selected.add(n) : selected.remove(n)),
            );
          }),
        ),
        const SizedBox(height: 16),
        Row(children: [
          Expanded(child: FilledButton.icon(onPressed: selected.isEmpty ? null : _waterOn, icon: const Icon(Icons.water_drop), label: const Text('पाणी ON'))),
          const SizedBox(width: 10),
          Expanded(child: FilledButton.tonalIcon(onPressed: selected.isEmpty ? null : _waterOff, icon: const Icon(Icons.water_drop_outlined), label: const Text('पाणी OFF'))),
        ]),
        const SizedBox(height: 16),
        Card(child: Padding(padding: const EdgeInsets.all(14), child: Text('🟢 बंद / पूर्ण\n🟡 सध्या पाणी सुरू: ${g.runningRows.length} सऱ्या\n🔴 बाकी सऱ्या\nSource: ${widget.store.source}\nदिशा: ${g.rowDirection}', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)))),
        const SizedBox(height: 8),
        FilledButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PlotViewPage(store: widget.store))), icon: const Icon(Icons.map), label: const Text('Live Plot Map पाहा')),
      ]),
    );
  }

  Future<void> _waterOn() async {
    final g = widget.store.active;
    if (g == null) return;
    g.runningRows = {...g.runningRows, ...selected}.toList()..sort();
    await widget.store.save();
    widget.store.notifyListeners();
    if (mounted) setState(() => selected.clear());
  }

  Future<void> _waterOff() async {
    final g = widget.store.active;
    if (g == null) return;
    g.runningRows.removeWhere(selected.contains);
    await widget.store.save();
    widget.store.notifyListeners();
    if (mounted) setState(() => selected.clear());
  }
}
