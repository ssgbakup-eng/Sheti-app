# Sheti App V4 Final

Final design base: GUT Update, saved Plot Map inside GUT Update, continuous actual Plot Map, single horizontal scroll for the complete map, sरी and बांध marks, two-side row references, mapping links/split links, water ON/OFF and Live Map.

The existing app package id should remain `com.example.sheti_app` when the Android project is prepared by the GitHub workflow.
