import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const ShetiApp());
}

class ShetiRecord {
  final String type;
  final String text;
  final DateTime date;
  final double? amount;

  ShetiRecord({required this.type, required this.text, required this.date, this.amount});

  Map<String, dynamic> toJson() => {
        'type': type,
        'text': text,
        'date': date.toIso8601String(),
        'amount': amount,
      };

  factory ShetiRecord.fromJson(Map<String, dynamic> j) => ShetiRecord(
        type: j['type'] ?? 'इतर',
        text: j['text'] ?? '',
        date: DateTime.tryParse(j['date'] ?? '') ?? DateTime.now(),
        amount: (j['amount'] as num?)?.toDouble(),
      );
}

enum WaterState { pending, running, done }

class RowState {
  final WaterState state;
  final DateTime? started;
  final DateTime? stopped;

  const RowState({this.state = WaterState.pending, this.started, this.stopped});

  Map<String, dynamic> toJson() => {
        'state': state.name,
        'started': started?.toIso8601String(),
        'stopped': stopped?.toIso8601String(),
      };

  factory RowState.fromJson(Map<String, dynamic> j) {
    final raw = j['state'] as String? ?? 'pending';
    final state = WaterState.values.firstWhere((e) => e.name == raw, orElse: () => WaterState.pending);
    return RowState(
      state: state,
      started: DateTime.tryParse(j['started'] ?? ''),
      stopped: DateTime.tryParse(j['stopped'] ?? ''),
    );
  }
}

class ShetiStore extends ChangeNotifier {
  // Keep the existing key so old saved records continue to load after upgrade.
  static const _recordKey = 'sheti_records_v1';
  static const _rowsKey = 'sheti_gut120_rows_v2';

  List<ShetiRecord> records = [];
  final Map<int, RowState> rows = {};

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getStringList(_recordKey) ?? [];
    records = raw.map((x) => ShetiRecord.fromJson(jsonDecode(x))).toList();
    final rowRaw = p.getString(_rowsKey);
    if (rowRaw != null) {
      final decoded = jsonDecode(rowRaw) as Map<String, dynamic>;
      rows
        ..clear()
        ..addAll(decoded.map((k, v) => MapEntry(int.parse(k), RowState.fromJson(v))));
    }
    notifyListeners();
  }

  Future<void> add(ShetiRecord r) async {
    records.insert(0, r);
    final p = await SharedPreferences.getInstance();
    await p.setStringList(_recordKey, records.map((x) => jsonEncode(x.toJson())).toList());
    notifyListeners();
  }

  Future<void> setRow(int row, WaterState state) async {
    final now = DateTime.now();
    final old = rows[row] ?? const RowState();
    rows[row] = RowState(
      state: state,
      started: state == WaterState.running ? now : old.started,
      stopped: state == WaterState.done ? now : old.stopped,
    );
    final p = await SharedPreferences.getInstance();
    await p.setString(_rowsKey, jsonEncode(rows.map((k, v) => MapEntry(k.toString(), v.toJson()))));
    notifyListeners();
  }

  Future<void> setRows(Iterable<int> numbers, WaterState state) async {
    for (final n in numbers) {
      final now = DateTime.now();
      final old = rows[n] ?? const RowState();
      rows[n] = RowState(
        state: state,
        started: state == WaterState.running ? now : old.started,
        stopped: state == WaterState.done ? now : old.stopped,
      );
    }
    final p = await SharedPreferences.getInstance();
    await p.setString(_rowsKey, jsonEncode(rows.map((k, v) => MapEntry(k.toString(), v.toJson()))));
    notifyListeners();
  }
}

class ShetiApp extends StatefulWidget {
  const ShetiApp({super.key});
  @override
  State<ShetiApp> createState() => _ShetiAppState();
}

class _ShetiAppState extends State<ShetiApp> {
  final store = ShetiStore();
  int index = 0;

  @override
  void initState() {
    super.initState();
    store.load();
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
        animation: store,
        builder: (_, __) => MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'शेती',
          theme: ThemeData(
            useMaterial3: true,
            colorSchemeSeed: Colors.green,
            scaffoldBackgroundColor: const Color(0xFFF5F8F4),
            cardTheme: const CardThemeData(margin: EdgeInsets.zero, elevation: 1),
          ),
          home: HomePage(store: store, index: index, onIndex: (i) => setState(() => index = i)),
        ),
      );
}

class HomePage extends StatelessWidget {
  final ShetiStore store;
  final int index;
  final ValueChanged<int> onIndex;
  const HomePage({super.key, required this.store, required this.index, required this.onIndex});

  @override
  Widget build(BuildContext context) {
    final pages = [
      Dashboard(store: store, onIndex: onIndex),
      PlanningPage(store: store),
      ReportsPage(store: store),
      HistoryPage(store: store),
    ];
    return Scaffold(
      appBar: AppBar(
        title: const Text('🌾 शेती', style: TextStyle(fontWeight: FontWeight.w800)),
        actions: [
          IconButton(
            tooltip: 'गट 120',
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PlotPage(store: store))),
            icon: const Icon(Icons.grid_view_rounded),
          )
        ],
      ),
      body: pages[index],
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: onIndex,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'मुख्य'),
          NavigationDestination(icon: Icon(Icons.calendar_month_outlined), selectedIcon: Icon(Icons.calendar_month), label: 'नियोजन'),
          NavigationDestination(icon: Icon(Icons.bar_chart_outlined), selectedIcon: Icon(Icons.bar_chart), label: 'रिपोर्ट'),
          NavigationDestination(icon: Icon(Icons.history), label: 'इतिहास'),
        ],
      ),
    );
  }
}

class Dashboard extends StatelessWidget {
  final ShetiStore store;
  final ValueChanged<int> onIndex;
  const Dashboard({super.key, required this.store, required this.onIndex});

  @override
  Widget build(BuildContext context) {
    final recent = store.records.take(3).toList();
    final today = DateTime.now();
    final todayRecords = store.records.where((r) => r.date.year == today.year && r.date.month == today.month && r.date.day == today.day).length;
    final done = store.rows.values.where((r) => r.state == WaterState.done).length;
    final running = store.rows.values.where((r) => r.state == WaterState.running).length;
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
      children: [
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(24),
            gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF2E7D32), Color(0xFF66BB6A)]),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('आजचे शेती व्यवस्थापन', style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w800)),
            const SizedBox(height: 6),
            Text('$todayRecords आजच्या नोंदी • $done सऱ्या पाणी पूर्ण • $running चालू', style: const TextStyle(color: Colors.white70)),
            const SizedBox(height: 16),
            FilledButton.tonalIcon(
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => VoicePage(store: store))),
              icon: const Icon(Icons.mic_rounded), label: const Text('मराठीत बोलून नोंद करा'),
            ),
          ]),
        ),
        const SizedBox(height: 16),
        Row(children: [
          Expanded(child: _stat('💧', '$done', 'पाणी पूर्ण')),
          const SizedBox(width: 10),
          Expanded(child: _stat('🟡', '$running', 'पाणी चालू')),
          const SizedBox(width: 10),
          Expanded(child: _stat('📝', '${store.records.length}', 'एकूण नोंदी')),
        ]),
        const SizedBox(height: 18),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          const Text('जलद नोंद', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
          TextButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PlotPage(store: store))), icon: const Icon(Icons.map_outlined), label: const Text('गट 120')),
        ]),
        Wrap(spacing: 8, runSpacing: 8, children: [
          _quick(context, '💧 पाणी', 'पाणी'), _quick(context, '🧪 खत', 'खत'), _quick(context, '🚜 मशागत', 'मशागत'),
          _quick(context, '💊 फवारणी', 'फवारणी'), _quick(context, '💰 खर्च', 'खर्च'),
        ]),
        const SizedBox(height: 20),
        const Text('अलीकडील नोंदी', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
        const SizedBox(height: 8),
        if (recent.isEmpty) const Card(child: Padding(padding: EdgeInsets.all(18), child: Text('अजून नोंदी नाहीत.'))),
        ...recent.map((r) => Card(margin: const EdgeInsets.only(bottom: 8), child: ListTile(
              leading: CircleAvatar(child: Text(_icon(r.type))), title: Text(r.type, style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text(r.text), trailing: Text('${r.date.day}/${r.date.month}\n${_hm(r.date)}', textAlign: TextAlign.center),
            ))),
      ],
    );
  }

  Widget _stat(String icon, String value, String label) => Card(child: Padding(padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8), child: Column(children: [Text(icon, style: const TextStyle(fontSize: 20)), Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)), Text(label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 11))])));
  String _icon(String t) => {'पाणी':'💧','खत':'🧪','मशागत':'🚜','फवारणी':'💊','खर्च':'💰'}[t] ?? '📝';
  Widget _quick(BuildContext c, String label, String type) => FilledButton.tonal(onPressed: () => Navigator.push(c, MaterialPageRoute(builder: (_) => AddRecordPage(store: store, type: type))), child: Text(label));
}

class PlanningPage extends StatelessWidget {
  final ShetiStore store;
  const PlanningPage({super.key, required this.store});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
        const Text('नियोजन', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)), const SizedBox(height: 12),
        _tile(context, '💧', 'पाणी नियोजन', 'गट 120 • सरीनुसार पाणी स्थिती', () => Navigator.push(context, MaterialPageRoute(builder: (_) => PlotPage(store: store)))),
        _tile(context, '🧪', 'खत नियोजन', 'खताचे नाव, प्रमाण व तारीख', () => Navigator.push(context, MaterialPageRoute(builder: (_) => AddRecordPage(store: store, type: 'खत')))),
        _tile(context, '🚜', 'मशागत नियोजन', 'काम, तारीख व क्षेत्र', () => Navigator.push(context, MaterialPageRoute(builder: (_) => AddRecordPage(store: store, type: 'मशागत')))),
        _tile(context, '💊', 'फवारणी नियोजन', 'औषध, प्रमाण व तारीख', () => Navigator.push(context, MaterialPageRoute(builder: (_) => AddRecordPage(store: store, type: 'फवारणी')))),
        _tile(context, '💰', 'खर्च नोंद', 'शेतीवरील खर्चाची नोंद', () => Navigator.push(context, MaterialPageRoute(builder: (_) => AddRecordPage(store: store, type: 'खर्च')))),
      ]);

  Widget _tile(BuildContext c, String icon, String title, String sub, VoidCallback tap) => Card(margin: const EdgeInsets.only(bottom: 10), child: ListTile(leading: Text(icon, style: const TextStyle(fontSize: 28)), title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: Text(sub), trailing: const Icon(Icons.chevron_right), onTap: tap));
}

class AddRecordPage extends StatefulWidget {
  final ShetiStore store; final String type;
  const AddRecordPage({super.key, required this.store, required this.type});
  @override State<AddRecordPage> createState() => _AddRecordPageState();
}
class _AddRecordPageState extends State<AddRecordPage> {
  final controller = TextEditingController(); final amount = TextEditingController(); DateTime selected = DateTime.now();
  Future<void> pickDate() async { final d = await showDatePicker(context: context, firstDate: DateTime(2020), lastDate: DateTime(2100), initialDate: selected, locale: const Locale('mr')); if (d != null) setState(() => selected = DateTime(d.year, d.month, d.day, DateTime.now().hour, DateTime.now().minute)); }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: Text('${widget.type} नोंद')), body: Padding(padding: const EdgeInsets.all(16), child: Column(children: [
    TextField(controller: controller, maxLines: 4, decoration: const InputDecoration(labelText: 'तपशील', hintText: 'उदा. गट 120 ला 6 तास पाणी दिले', border: OutlineInputBorder())),
    const SizedBox(height: 12),
    Row(children: [Expanded(child: OutlinedButton.icon(onPressed: pickDate, icon: const Icon(Icons.calendar_today), label: Text('${selected.day.toString().padLeft(2,'0')}-${selected.month.toString().padLeft(2,'0')}-${selected.year}'))), const SizedBox(width: 8), Text(_hm(selected))]),
    const SizedBox(height: 12),
    if (widget.type == 'खर्च') TextField(controller: amount, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'रक्कम', prefixText: '₹ ', border: OutlineInputBorder())),
    const Spacer(), SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: () async { if (controller.text.trim().isEmpty) return; await widget.store.add(ShetiRecord(type: widget.type, text: controller.text.trim(), date: selected, amount: double.tryParse(amount.text.trim()))); if (context.mounted) Navigator.pop(context); }, icon: const Icon(Icons.save), label: const Text('सेव्ह करा'))),
  ])));
}

class VoicePage extends StatefulWidget {
  final ShetiStore store; const VoicePage({super.key, required this.store});
  @override State<VoicePage> createState() => _VoicePageState();
}
class _VoicePageState extends State<VoicePage> {
  final speech = stt.SpeechToText(); final text = TextEditingController(); bool listening = false; bool available = false; String status = 'माइक दाबून मराठीत बोला';
  Future<void> toggle() async {
    if (listening) { await speech.stop(); setState(() { listening = false; status = 'नोंद तपासा आणि सेव्ह करा'; }); return; }
    available = await speech.initialize(onStatus: (s) { if (mounted) setState(() => listening = s == 'listening'); }, onError: (e) { if (mounted) setState(() => status = 'माइक/परवानगी तपासा'); });
    if (!available) { setState(() => status = 'माइकची परवानगी द्या आणि पुन्हा प्रयत्न करा'); return; }
    setState(() { listening = true; status = 'ऐकत आहे...'; });
    await speech.listen(localeId: 'mr_IN', listenOptions: stt.SpeechListenOptions(partialResults: true), onResult: (r) { if (mounted) setState(() => text.text = r.recognizedWords); });
  }
  List<int> _numbers(String s) => RegExp(r'\d+').allMatches(s).map((m) => int.parse(m.group(0)!)).where((n) => n >= 1 && n <= 40).toList();
  Future<void> applyWaterVoice() async {
    final s = text.text.trim(); final nums = _numbers(s);
    if (nums.isEmpty || (!s.contains('पाणी'))) return;
    final isDone = s.contains('बंद') || s.contains('पूर्ण'); final isRun = s.contains('चालू');
    if (!isDone && !isRun) return;
    await widget.store.setRows(nums, isDone ? WaterState.done : WaterState.running);
    await widget.store.add(ShetiRecord(type: 'पाणी', text: s, date: DateTime.now()));
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${nums.join(', ')} सऱ्या ${isDone ? 'हिरव्या' : 'पिवळ्या'} केल्या')));
  }
  Future<void> save() async { if (text.text.trim().isEmpty) return; await widget.store.add(ShetiRecord(type: 'Voice Update', text: text.text.trim(), date: DateTime.now())); if (mounted) Navigator.pop(context); }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('🎤 Voice Update')), body: ListView(padding: const EdgeInsets.all(16), children: [
    Card(child: Padding(padding: const EdgeInsets.all(20), child: Column(children: [Text(status, textAlign: TextAlign.center), const SizedBox(height: 18), FloatingActionButton.large(onPressed: toggle, child: Icon(listening ? Icons.stop_rounded : Icons.mic_rounded)), const SizedBox(height: 10), const Text('उदा. “पाणी बंद सरी 10, 11, 12”', style: TextStyle(fontWeight: FontWeight.w600))]))),
    const SizedBox(height: 14), TextField(controller: text, maxLines: 6, decoration: const InputDecoration(labelText: 'तुमची नोंद', border: OutlineInputBorder())), const SizedBox(height: 12),
    FilledButton.icon(onPressed: applyWaterVoice, icon: const Icon(Icons.water_drop), label: const Text('पाणी अपडेट लागू करा')), const SizedBox(height: 8),
    OutlinedButton.icon(onPressed: save, icon: const Icon(Icons.save), label: const Text('सामान्य नोंद सेव्ह करा')),
  ]));
}

class PlotPage extends StatelessWidget {
  final ShetiStore store; const PlotPage({super.key, required this.store});
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('🌾 गट नं. 120 • 2 एकर'), actions: [IconButton(onPressed: () => showDialog(context: context, builder: (_) => const AlertDialog(title: Text('प्लॉट माहिती'), content: Text('ऊस • लांबी 550 फूट\nरस्ता: दक्षिण\nमोठी नाली: उत्तर\nवरच्या बाजूला 37 सऱ्या • खाली 40 सऱ्या\nसरी 12 → खाली 14 व 15 फाटतात.'))), icon: const Icon(Icons.info_outline))]), body: ListView(padding: const EdgeInsets.all(12), children: [
    const Card(child: Padding(padding: EdgeInsets.all(12), child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text('मोठी नाली\nउत्तर', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.bold)), Text('550 फूट', style: TextStyle(fontWeight: FontWeight.w800)), Text('ऊस • 2 एकर', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.bold))]))),
    const SizedBox(height: 8),
    const Text('वरची बाजू • 37 सऱ्या', style: TextStyle(fontWeight: FontWeight.w800)),
    const SizedBox(height: 6),
    _Rows(store: store, count: 37, top: true),
    const SizedBox(height: 10),
    const Divider(thickness: 2),
    const SizedBox(height: 10),
    const Text('खालची बाजू • 40 सऱ्या', style: TextStyle(fontWeight: FontWeight.w800)),
    const SizedBox(height: 6),
    _Rows(store: store, count: 40, top: false),
    const SizedBox(height: 10),
    const Card(child: Padding(padding: EdgeInsets.all(12), child: Text('रंग:  🟢 पाणी पूर्ण   🟡 पाणी चालू   🔴 पाणी बाकी\nसरी 12 ची खालील बाजू 14 आणि 15 म्हणून दाखवली आहे.', style: TextStyle(fontWeight: FontWeight.w600)))),
    const SizedBox(height: 8),
    const Center(child: Text('टेम्बापुरी रस्ता • दक्षिण', style: TextStyle(fontWeight: FontWeight.bold))),
  ]));
}

class _Rows extends StatelessWidget {
  final ShetiStore store; final int count; final bool top; const _Rows({required this.store, required this.count, required this.top});
  Color _color(int n) { final s = store.rows[n]?.state ?? WaterState.pending; return s == WaterState.done ? Colors.green : s == WaterState.running ? Colors.amber : Colors.red.shade400; }
  String _label(int n) => top ? '$n' : '$n';
  @override Widget build(BuildContext context) => SingleChildScrollView(scrollDirection: Axis.horizontal, child: Row(children: List.generate(count, (i) { final n = i + 1; return GestureDetector(onTap: () async { final current = store.rows[n]?.state ?? WaterState.pending; final next = current == WaterState.pending ? WaterState.running : current == WaterState.running ? WaterState.done : WaterState.pending; await store.setRow(n, next); }, child: Container(width: 22, height: top ? 120 : 120, margin: const EdgeInsets.only(right: 2), decoration: BoxDecoration(color: _color(n), borderRadius: BorderRadius.circular(3), border: Border.all(color: Colors.white, width: .7)), child: Column(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Container(width: double.infinity, padding: const EdgeInsets.symmetric(vertical: 2), color: Colors.white, child: Text(_label(n), textAlign: TextAlign.center, style: const TextStyle(fontSize: 9, fontWeight: FontWeight.bold))), const RotatedBox(quarterTurns: 3, child: Text('550 ft', style: TextStyle(fontSize: 7, color: Colors.white, fontWeight: FontWeight.bold))), Container(width: double.infinity, padding: const EdgeInsets.symmetric(vertical: 2), color: Colors.white, child: Text(top ? '$n' : '$n', textAlign: TextAlign.center, style: const TextStyle(fontSize: 9, fontWeight: FontWeight.bold)))]))); })));
}

class ReportsPage extends StatefulWidget { final ShetiStore store; const ReportsPage({super.key, required this.store}); @override State<ReportsPage> createState() => _ReportsPageState(); }
class _ReportsPageState extends State<ReportsPage> {
  DateTimeRange? range;
  Future<void> pick() async { final r = await showDateRangePicker(context: context, firstDate: DateTime(2020), lastDate: DateTime(2100), initialDateRange: range); if (r != null) setState(() => range = r); }
  @override Widget build(BuildContext context) {
    final data = widget.store.records.where((r) => range == null || (!r.date.isBefore(range!.start) && r.date.isBefore(range!.end.add(const Duration(days: 1))))).toList();
    final counts = <String,int>{}; for (final r in data) counts[r.type] = (counts[r.type] ?? 0) + 1;
    return ListView(padding: const EdgeInsets.all(16), children: [
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [const Text('रिपोर्ट', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)), IconButton(onPressed: pick, icon: const Icon(Icons.date_range))]),
      if (range != null) Padding(padding: const EdgeInsets.only(bottom: 12), child: Chip(label: Text('${range!.start.day}/${range!.start.month}/${range!.start.year} ते ${range!.end.day}/${range!.end.month}/${range!.end.year}'))),
      ...counts.entries.map((e) => Card(margin: const EdgeInsets.only(bottom: 8), child: ListTile(title: Text(e.key, style: const TextStyle(fontWeight: FontWeight.bold)), trailing: Text('${e.value} नोंदी')))),
      if (counts.isEmpty) const Card(child: Padding(padding: EdgeInsets.all(20), child: Text('या कालावधीत नोंदी नाहीत.'))),
    ];
  }
}

class HistoryPage extends StatelessWidget { final ShetiStore store; const HistoryPage({super.key, required this.store}); @override Widget build(BuildContext context) => ListView.builder(padding: const EdgeInsets.all(8), itemCount: store.records.length, itemBuilder: (_, i) { final r = store.records[i]; return Card(margin: const EdgeInsets.only(bottom: 8), child: ListTile(leading: const Icon(Icons.event_note), title: Text(r.type, style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: Text('${r.text}\n${r.date.day.toString().padLeft(2,'0')}/${r.date.month.toString().padLeft(2,'0')}/${r.date.year} • ${_hm(r.date)}')); }); }

String _hm(DateTime d) => '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';
