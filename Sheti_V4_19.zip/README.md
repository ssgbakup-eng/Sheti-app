Sheti V4.19

Base: previous V13 source. Only two requested changes:
1) Permanent release signing key restored from the existing Sheti release key used by the recent builds, with the same applicationId and higher versionCode for APK update.
2) Base/Reference row logic: selected Base direction controls B numbering and selection; R is reverse reference only. With EAST as Base, B01 starts at the EAST edge and progresses toward WEST; extra rows beyond the north/top count extend only on the WEST side and remain selectable by their B numbers.

No other design changes intended.
