import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const ShetiApp());

class ShetiApp extends StatelessWidget {
  const ShetiApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'शेती',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.green,
        scaffoldBackgroundColor: const Color(0xFFF7FAF3),
        inputDecorationTheme: const InputDecorationTheme(border: OutlineInputBorder()),
      ),
      home: const AppShell(),
    );
  }
}

class WaterEvent {
  String dateTime;
  int row;
  String action;
  String source;

  WaterEvent({
    required this.dateTime,
    required this.row,
    required this.action,
    required this.source,
  });

  Map<String, dynamic> toJson() => {
        'dateTime': dateTime,
        'row': row,
        'action': action,
        'source': source,
      };

  factory WaterEvent.fromJson(Map<String, dynamic> j) => WaterEvent(
        dateTime: '${j['dateTime'] ?? ''}',
        row: int.tryParse('${j['row'] ?? 0}') ?? 0,
        action: '${j['action'] ?? ''}',
        source: '${j['source'] ?? ''}',
      );
}

class Gut {
  String no, area, crop, length, remark;
  String rowDirection, numberStart;
  int topRows, bottomRows;
  Map<String, String> marks;
  List<RowLink> links;
  List<int> runningRows;
  Map<int, String> rowMarks;
  Map<int, String> completedAt;
  List<WaterEvent> waterHistory;

  Gut({
    required this.no,
    this.area = '',
    this.crop = '',
    this.length = '',
    this.remark = '',
    this.rowDirection = 'उत्तर → दक्षिण',
    this.numberStart = 'पूर्व',
    this.topRows = 0,
    this.bottomRows = 0,
    Map<String, String>? marks,
    List<RowLink>? links,
    List<int>? runningRows,
    Map<int, String>? rowMarks,
    Map<int, String>? completedAt,
    List<WaterEvent>? waterHistory,
  })  : marks = marks ?? {'उत्तर': '', 'दक्षिण': '', 'पूर्व': '', 'पश्चिम': ''},
        links = links ?? [],
        runningRows = runningRows ?? [],
        rowMarks = rowMarks ?? {},
        completedAt = completedAt ?? {},
        waterHistory = waterHistory ?? [];

  Map<String, dynamic> toJson() => {
        'no': no,
        'area': area,
        'crop': crop,
        'length': length,
        'remark': remark,
        'rowDirection': rowDirection,
        'numberStart': numberStart,
        'topRows': topRows,
        'bottomRows': bottomRows,
        'marks': marks,
        'links': links.map((e) => e.toJson()).toList(),
        'runningRows': runningRows,
        'rowMarks': rowMarks.map((k, v) => MapEntry('$k', v)),
        'completedAt': completedAt.map((k, v) => MapEntry('$k', v)),
        'waterHistory': waterHistory.map((e) => e.toJson()).toList(),
      };

  factory Gut.fromJson(Map<String, dynamic> j) => Gut(
        no: '${j['no'] ?? ''}',
        area: '${j['area'] ?? ''}',
        crop: '${j['crop'] ?? ''}',
        length: '${j['length'] ?? ''}',
        remark: '${j['remark'] ?? ''}',
        rowDirection: '${j['rowDirection'] ?? 'उत्तर → दक्षिण'}',
        numberStart: '${j['numberStart'] ?? 'पूर्व'}',
        topRows: int.tryParse('${j['topRows'] ?? 0}') ?? 0,
        bottomRows: int.tryParse('${j['bottomRows'] ?? 0}') ?? 0,
        marks: Map<String, String>.from(j['marks'] ?? const {}),
        links: (j['links'] as List? ?? const [])
            .map((e) => RowLink.fromJson(Map<String, dynamic>.from(e)))
            .toList(),
        runningRows: List<int>.from(j['runningRows'] ?? const []),
        rowMarks: (j['rowMarks'] as Map? ?? const {}).map((k, v) => MapEntry(int.tryParse('$k') ?? 0, '$v')),
        completedAt: (j['completedAt'] as Map? ?? const {}).map((k, v) => MapEntry(int.tryParse('$k') ?? 0, '$v')),
        waterHistory: (j['waterHistory'] as List? ?? const [])
            .map((e) => WaterEvent.fromJson(Map<String, dynamic>.from(e)))
            .toList(),
      );
}

class RowLink {
  int top;
  List<int> bottom;
  RowLink(this.top, this.bottom);
  Map<String, dynamic> toJson() => {'top': top, 'bottom': bottom};
  factory RowLink.fromJson(Map<String, dynamic> j) => RowLink(
        int.tryParse('${j['top'] ?? 0}') ?? 0,
        List<int>.from(j['bottom'] ?? const []),
      );
}

class AppStore extends ChangeNotifier {
  List<Gut> guts = [];
  String? activeGut;
  String source = 'मोठी नाली';
  bool loading = true;
  List<String> sources = ['मोठी नाली', 'विहीर', 'बोअर', 'विहीर मोटर'];

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString('guts');
    if (raw != null && raw.isNotEmpty) {
      final decoded = jsonDecode(raw) as List;
      guts = decoded.map((e) => Gut.fromJson(Map<String, dynamic>.from(e))).toList();
    }
    activeGut = p.getString('activeGut');
    final savedSources = p.getStringList('waterSources');
    if (savedSources != null && savedSources.isNotEmpty) sources = savedSources;
    source = p.getString('activeWaterSource') ?? sources.first;
    if (activeGut == null && guts.isNotEmpty) activeGut = guts.first.no;
    loading = false;
    notifyListeners();
  }

  Future<void> save() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('guts', jsonEncode(guts.map((e) => e.toJson()).toList()));
    await p.setStringList('waterSources', sources);
    await p.setString('activeWaterSource', source);
    if (activeGut != null) {
      await p.setString('activeGut', activeGut!);
    } else {
      await p.remove('activeGut');
    }
  }

  Gut? get active {
    for (final g in guts) {
      if (g.no == activeGut) return g;
    }
    return null;
  }

  Future<void> addWaterSource(String name) async {
    final n = name.trim();
    if (n.isEmpty || sources.contains(n)) return;
    sources.add(n);
    source = n;
    await save();
    notifyListeners();
  }

  void select(String no) {
    activeGut = no;
    save();
    notifyListeners();
  }

  Future<void> upsert(Gut gut) async {
    final i = guts.indexWhere((g) => g.no == gut.no);
    if (i >= 0) {
      guts[i] = gut;
    } else {
      guts.add(gut);
    }
    activeGut = gut.no;
    await save();
    notifyListeners();
  }

  Future<void> remove(String no) async {
    guts.removeWhere((g) => g.no == no);
    if (activeGut == no) activeGut = guts.isEmpty ? null : guts.first.no;
    await save();
    notifyListeners();
  }
}

class AppShell extends StatefulWidget {
  const AppShell({super.key});
  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  final AppStore store = AppStore();
  int tab = 0;

  @override
  void initState() {
    super.initState();
    store.load();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        if (store.loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
        final pages = [
          Dashboard(store: store, onOpen: (i) => setState(() => tab = i)),
          PlotMappingPage(store: store),
          PlotViewPage(store: store),
          WaterPage(store: store),
        ];
        return Scaffold(
          body: pages[tab],
          bottomNavigationBar: NavigationBar(
            selectedIndex: tab,
            onDestinationSelected: (i) => setState(() => tab = i),
            destinations: const [
              NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'मुख्य'),
              NavigationDestination(icon: Icon(Icons.grid_view_outlined), selectedIcon: Icon(Icons.grid_view), label: 'Mapping'),
              NavigationDestination(icon: Icon(Icons.map_outlined), selectedIcon: Icon(Icons.map), label: 'Plot View'),
              NavigationDestination(icon: Icon(Icons.water_drop_outlined), selectedIcon: Icon(Icons.water_drop), label: 'पाणी'),
            ],
          ),
        );
      },
    );
  }
}

class Dashboard extends StatelessWidget {
  final AppStore store;
  final ValueChanged<int> onOpen;
  const Dashboard({super.key, required this.store, required this.onOpen});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('🌾 शेती • मुख्य मेनू')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        _menuCard(context, 'GUT Update', 'Saved GUT आणि त्याचा Plot Map पाहा / Update करा', Icons.edit_note,
            () => Navigator.push(context, MaterialPageRoute(builder: (_) => GutUpdatePage(store: store)))),
        _menuCard(context, 'Plot Mapping', 'सऱ्या, numbering, link आणि split mapping', Icons.grid_view, () => onOpen(1)),
        _menuCard(context, 'Plot Map View', 'प्रत्यक्ष GUT नकाशा + सऱ्या + बांध + References', Icons.map, () => onOpen(2)),
        _menuCard(context, 'पाणी ON / OFF + Live Map', 'सरी निवडा आणि Live status बदला', Icons.water_drop, () => onOpen(3)),
        const SizedBox(height: 12),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Text('सध्याचे GUT: ${store.activeGut ?? 'निवडलेले नाही'}\nएकूण GUT: ${store.guts.length}',
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
          ),
        ),
      ]),
    );
  }

  Widget _menuCard(BuildContext context, String title, String sub, IconData icon, VoidCallback tap) => Card(
        child: InkWell(
          onTap: tap,
          borderRadius: BorderRadius.circular(16),
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Row(children: [
              CircleAvatar(radius: 26, child: Icon(icon)),
              const SizedBox(width: 16),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 4),
                Text(sub),
              ])),
              const Icon(Icons.chevron_right),
            ]),
          ),
        ),
      );
}

class GutUpdatePage extends StatelessWidget {
  final AppStore store;
  const GutUpdatePage({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('GUT Update')),
      body: store.guts.isEmpty
          ? Center(child: FilledButton.icon(onPressed: () => _openForm(context), icon: const Icon(Icons.add), label: const Text('नवीन GUT तयार करा')))
          : ListView(padding: const EdgeInsets.all(12), children: [
              FilledButton.icon(onPressed: () => _openForm(context), icon: const Icon(Icons.add), label: const Text('नवीन GUT')),
              const SizedBox(height: 10),
              ...store.guts.map((g) => Card(
                    child: ExpansionTile(
                      initiallyExpanded: g.no == store.activeGut,
                      title: Text('GUT ${g.no}', style: const TextStyle(fontWeight: FontWeight.bold)),
                      subtitle: Text('${g.crop} • ${g.area} • ${g.length}'),
                      onExpansionChanged: (v) {
                        if (v) store.select(g.no);
                      },
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(10),
                          child: Column(children: [
                            PlotMapPreview(gut: g, compact: true),
                            const SizedBox(height: 10),
                            Row(children: [
                              Expanded(child: FilledButton.icon(onPressed: () => _openForm(context, g), icon: const Icon(Icons.edit), label: const Text('Update'))),
                              const SizedBox(width: 8),
                              IconButton(onPressed: () => _delete(context, g), icon: const Icon(Icons.delete_outline)),
                            ]),
                          ]),
                        ),
                      ],
                    ),
                  )),
            ]),
    );
  }

  void _openForm(BuildContext context, [Gut? g]) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => GutFormPage(store: store, existing: g)));
  }

  Future<void> _delete(BuildContext context, Gut g) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('GUT Delete'),
        content: Text('GUT ${g.no} हटवायचा आहे का?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('नाही')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('होय')),
        ],
      ),
    );
    if (ok == true) await store.remove(g.no);
  }
}

class GutFormPage extends StatefulWidget {
  final AppStore store;
  final Gut? existing;
  const GutFormPage({super.key, required this.store, this.existing});
  @override
  State<GutFormPage> createState() => _GutFormPageState();
}

class _GutFormPageState extends State<GutFormPage> {
  late final TextEditingController no, area, crop, length, remark;
  late String direction, numberStart;
  late final Map<String, TextEditingController> marks;

  @override
  void initState() {
    super.initState();
    final g = widget.existing;
    no = TextEditingController(text: g?.no ?? '');
    area = TextEditingController(text: g?.area ?? '');
    crop = TextEditingController(text: g?.crop ?? '');
    length = TextEditingController(text: g?.length ?? '');
    remark = TextEditingController(text: g?.remark ?? '');
    direction = g?.rowDirection ?? 'उत्तर → दक्षिण';
    numberStart = g?.numberStart ?? 'पूर्व';
    final m = g?.marks ?? {};
    marks = {for (final d in ['उत्तर', 'दक्षिण', 'पूर्व', 'पश्चिम']) d: TextEditingController(text: m[d] ?? '')};
  }

  @override
  void dispose() {
    for (final c in [no, area, crop, length, remark, ...marks.values]) c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.existing == null ? 'नवीन GUT' : 'GUT Update')),
      body: ListView(padding: const EdgeInsets.fromLTRB(16, 16, 16, 110), children: [
        _field('GUT क्रमांक', no),
        _field('क्षेत्रफळ', area),
        _field('पीक', crop),
        _field('लांबी', length),
        _drop('सऱ्यांची दिशा (पाण्याची दिशा)', direction, ['उत्तर → दक्षिण', 'दक्षिण → उत्तर', 'पूर्व → पश्चिम', 'पश्चिम → पूर्व'], (v) => setState(() => direction = v!)),
        _drop('सऱ्यांची नंबरिंग सुरू होण्याची दिशा', numberStart, ['पूर्व', 'पश्चिम', 'उत्तर', 'दक्षिण'], (v) => setState(() => numberStart = v!)),
        const SizedBox(height: 8),
        const Text('चारही दिशांचे Land Mark', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        for (final d in ['उत्तर', 'दक्षिण', 'पूर्व', 'पश्चिम'])
          Padding(padding: const EdgeInsets.only(top: 10), child: TextField(controller: marks[d], decoration: InputDecoration(labelText: '$d Land Mark'))),
        const SizedBox(height: 10),
        _field('Remark', remark, maxLines: 2),
        if (widget.existing != null && widget.existing!.topRows > 0) ...[
          const SizedBox(height: 8),
          const Text('सेव्ह केलेला Plot Map', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          PlotMapPreview(gut: widget.existing!, compact: true),
        ],
      ]),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: FilledButton.icon(onPressed: _save, icon: const Icon(Icons.save), label: Text(widget.existing == null ? 'Save GUT' : 'Update GUT')),
        ),
      ),
    );
  }

  Widget _field(String label, TextEditingController c, {int maxLines = 1}) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: TextField(controller: c, maxLines: maxLines, decoration: InputDecoration(labelText: label)),
      );

  Widget _drop(String label, String value, List<String> items, ValueChanged<String?> onChanged) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: DropdownButtonFormField<String>(
          value: value,
          decoration: InputDecoration(labelText: label),
          items: items.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
          onChanged: onChanged,
        ),
      );

  Future<void> _save() async {
    final gutNo = no.text.trim();
    if (gutNo.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('GUT क्रमांक भरा')));
      return;
    }
    final old = widget.existing;
    if (old == null && widget.store.guts.any((g) => g.no == gutNo)) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('हा GUT क्रमांक आधीच आहे')));
      return;
    }
    final g = Gut(
      no: gutNo,
      area: area.text.trim(),
      crop: crop.text.trim(),
      length: length.text.trim(),
      remark: remark.text.trim(),
      rowDirection: direction,
      numberStart: numberStart,
      topRows: old?.topRows ?? 0,
      bottomRows: old?.bottomRows ?? 0,
      marks: {for (final e in marks.entries) e.key: e.value.text.trim()},
      links: old?.links,
      runningRows: old?.runningRows,
      rowMarks: old?.rowMarks,
      completedAt: old?.completedAt,
    );
    await widget.store.upsert(g);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('GUT Update सेव्ह झाला')));
      Navigator.pop(context);
    }
  }
}

class PlotMappingPage extends StatefulWidget {
  final AppStore store;
  const PlotMappingPage({super.key, required this.store});
  @override
  State<PlotMappingPage> createState() => _PlotMappingPageState();
}

class _PlotMappingPageState extends State<PlotMappingPage> {
  Gut? get gut => widget.store.active;
  late TextEditingController top, bottom, firstTop, firstBottom, splitTop, splitA, splitB, markerRow, markerText;
  String? loadedNo;

  @override
  void initState() {
    super.initState();
    _makeControllers();
  }

  void _makeControllers() {
    final g = gut;
    for (final c in _controllers) c.dispose();
    top = TextEditingController(text: '${g?.topRows == 0 ? 37 : g?.topRows}');
    bottom = TextEditingController(text: '${g?.bottomRows == 0 ? 40 : g?.bottomRows}');
    firstTop = TextEditingController(text: '1');
    firstBottom = TextEditingController(text: '3');
    splitTop = TextEditingController(text: '12');
    splitA = TextEditingController(text: '15');
    splitB = TextEditingController(text: '16');
    markerRow = TextEditingController(text: '1');
    markerText = TextEditingController();
    loadedNo = g?.no;
  }

  List<TextEditingController> get _controllers => [
        if (loadedNo != null) top,
        if (loadedNo != null) bottom,
        if (loadedNo != null) firstTop,
        if (loadedNo != null) firstBottom,
        if (loadedNo != null) splitTop,
        if (loadedNo != null) splitA,
        if (loadedNo != null) splitB,
      ];

  @override
  void dispose() {
    for (final c in _controllers) c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final g = gut;
    if (g == null) return _empty();
    if (loadedNo != g.no) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted && loadedNo != widget.store.activeGut) setState(_makeControllers);
      });
    }
    return Scaffold(
      appBar: AppBar(title: Text('Plot Mapping • GUT ${g.no}'), actions: [IconButton(onPressed: () => _selectGut(context), icon: const Icon(Icons.swap_horiz))]),
      body: ListView(padding: const EdgeInsets.fromLTRB(14, 14, 14, 120), children: [
        _info(g),
        const SizedBox(height: 12),
        _numberSection(),
        const SizedBox(height: 12),
        _linkSection(),
        const SizedBox(height: 12),
        _markerSection(g),
        const SizedBox(height: 12),
        const Text('Plot Layout Preview', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        PlotMapPreview(gut: g, compact: true),
      ]),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: FilledButton.icon(onPressed: _saveMapping, icon: const Icon(Icons.save), label: const Text('Plot Update / Save')),
        ),
      ),
    );
  }

  Widget _empty() => Scaffold(
        appBar: AppBar(title: const Text('Plot Mapping')),
        body: Center(child: FilledButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => GutFormPage(store: widget.store))), child: const Text('पहिले GUT तयार करा'))),
      );

  Widget _info(Gut g) => Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('GUT ${g.no} • ${g.area} • ${g.crop}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            Text('सरी दिशा: ${g.rowDirection} • नंबरिंग: ${g.numberStart}'),
            Text('उत्तर: ${g.marks['उत्तर']} | दक्षिण: ${g.marks['दक्षिण']}'),
            Text('पूर्व: ${g.marks['पूर्व']} | पश्चिम: ${g.marks['पश्चिम']}'),
          ]),
        ),
      );

  Widget _numberSection() => Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('सऱ्यांची संख्या', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(child: TextField(controller: top, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'वरची बाजू सऱ्या'))),
              const SizedBox(width: 10),
              Expanded(child: TextField(controller: bottom, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'खालची बाजू सऱ्या'))),
            ]),
            const SizedBox(height: 10),
            const Text('उदा. 37 वर / 40 खाली: वर 1 → खाली 3. खाली 1-2 = Extra/No Link.'),
          ]),
        ),
      );

  Widget _linkSection() => Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Link Mapping', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(child: TextField(controller: firstTop, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'वरची सरी'))),
              const Padding(padding: EdgeInsets.symmetric(horizontal: 8), child: Text('→')),
              Expanded(child: TextField(controller: firstBottom, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'खालील सरी'))),
            ]),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(child: TextField(controller: splitTop, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Split वरची सरी'))),
              const Padding(padding: EdgeInsets.symmetric(horizontal: 8), child: Text('→')),
              Expanded(child: TextField(controller: splitA, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'खाली A'))),
              const SizedBox(width: 6),
              Expanded(child: TextField(controller: splitB, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'खाली B'))),
            ]),
            const SizedBox(height: 10),
            const Text('Split नंतर पुढील links shift होतील. उदा. 12→15,16; 13→17; 14→18; 37→40.'),
          ]),
        ),
      );

  Widget _markerSection(Gut g) => Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('सरीची खूण / नोंद', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Row(children: [
              Expanded(child: TextField(controller: markerRow, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'सरी नं.'))),
              const SizedBox(width: 8),
              Expanded(child: TextField(controller: markerText, decoration: const InputDecoration(labelText: 'खूण: लिंब / खांबा / कॉक'))),
              const SizedBox(width: 8),
              FilledButton(onPressed: () {
                final n = int.tryParse(markerRow.text.trim());
                final v = markerText.text.trim();
                if (n != null && n > 0 && n <= (g.topRows > g.bottomRows ? g.topRows : g.bottomRows) && v.isNotEmpty) {
                  setState(() => g.rowMarks[n] = v);
                  widget.store.save();
                  markerText.clear();
                }
              }, child: const Text('नोंद')),
            ]),
            if (g.rowMarks.isNotEmpty) ...[
              const SizedBox(height: 8),
              Wrap(spacing: 6, runSpacing: 6, children: g.rowMarks.entries.map((e) => Chip(label: Text('${e.key}: ${e.value}'), onDeleted: () => setState(() => g.rowMarks.remove(e.key)))).toList()),
            ],
          ]),
        ),
      );

  Future<void> _saveMapping() async {
    final g = gut;
    if (g == null) return;
    final tr = int.tryParse(top.text.trim()) ?? 0;
    final br = int.tryParse(bottom.text.trim()) ?? 0;
    if (tr <= 0 || br <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('सऱ्यांची संख्या भरा')));
      return;
    }
    final ft = int.tryParse(firstTop.text.trim()) ?? 1;
    final fb = int.tryParse(firstBottom.text.trim()) ?? 1;
    final st = int.tryParse(splitTop.text.trim()) ?? -1;
    final sa = int.tryParse(splitA.text.trim()) ?? -1;
    final sb = int.tryParse(splitB.text.trim()) ?? -1;
    final links = <RowLink>[];
    for (int i = 1; i <= tr; i++) {
      if (i == st && sa > 0 && sb > 0) {
        links.add(RowLink(i, [sa, sb]));
      } else {
        final offset = i > st ? 1 : 0;
        final b = fb + (i - ft) + offset;
        if (b > 0 && b <= br) links.add(RowLink(i, [b]));
      }
    }
    g.topRows = tr;
    g.bottomRows = br;
    g.links = links;
    await widget.store.save();
    widget.store.notifyListeners();
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Plot Update सेव्ह झाला')));
  }

  Future<void> _selectGut(BuildContext context) async {
    final n = await showDialog<String>(
      context: context,
      builder: (_) => SimpleDialog(
        title: const Text('GUT निवडा'),
        children: widget.store.guts.map((g) => SimpleDialogOption(onPressed: () => Navigator.pop(context, g.no), child: Text('GUT ${g.no}'))).toList(),
      ),
    );
    if (n != null) {
      widget.store.select(n);
      if (mounted) setState(_makeControllers);
    }
  }
}

class PlotViewPage extends StatelessWidget {
  final AppStore store;
  const PlotViewPage({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    final g = store.active;
    if (g == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Plot View')),
        body: const Center(child: Text('पहिले GUT तयार करा')),
      );
    }
    return Scaffold(
      appBar: AppBar(
        title: Text('🌾 GUT ${g.no} • Plot Map'),
        actions: [
          IconButton(
            tooltip: 'नकाशा मोठा/लहान',
            onPressed: () {},
            icon: const Icon(Icons.zoom_in),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(8),
        child: PlotMapPreview(gut: g, compact: false, interactive: true),
      ),
    );
  }
}

class PlotMapPreview extends StatelessWidget {
  final Gut gut;
  final bool compact;
  final bool interactive;
  final ValueChanged<int>? onRowTap;
  final Set<int> selectedRows;
  const PlotMapPreview({super.key, required this.gut, this.compact = false, this.interactive = false, this.onRowTap, this.selectedRows = const {}});

  static String ref(int n) => n.toString().padLeft(2, '0');

  @override
  Widget build(BuildContext context) {
    final topCount = gut.topRows;
    final bottomCount = gut.bottomRows;
    final count = topCount > bottomCount ? topCount : bottomCount;
    if (count <= 0) {
      return const Card(child: Padding(padding: EdgeInsets.all(14), child: Text('Plot Mapping अजून सेव्ह केलेले नाही.')));
    }

    // Small sari boxes: keep the whole plot compact while retaining readable references.
    final cellW = compact ? 26.0 : 32.0;
    final plotW = count * cellW + 155;
    final plotH = compact ? 245.0 : 430.0;

    Widget map = SizedBox(
      width: plotW,
      height: plotH,
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTapUp: onRowTap == null ? null : (d) {
          const left = 95.0;
          final right = left + count * cellW;
          final x = d.localPosition.dx;
          // Base numbering starts from the selected base side.
          // EAST: 01 starts at the right/east edge and increases toward WEST.
          // WEST: 01 starts at the left/west edge and increases toward EAST.
          final i = gut.numberStart == 'पूर्व'
              ? ((right - x) / cellW).floor()
              : ((x - left) / cellW).floor();
          if (i < 0 || i >= count) return;
          // The Base number is the only selection key. Reference numbers are display-only.
          onRowTap!(i + 1);
        },
        child: CustomPaint(painter: PlotPainter(gut: gut, cellW: cellW, count: count, ref: ref, selectedRows: selectedRows)),
      ),
    );

    if (interactive) {
      map = InteractiveViewer(
        minScale: 0.55,
        maxScale: 4.0,
        scaleEnabled: true,
        panEnabled: true,
        constrained: false,
        boundaryMargin: const EdgeInsets.all(100),
        child: map,
      );
    }

    return Card(
      clipBehavior: Clip.antiAlias,
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(10, 10, 10, 4),
          child: Row(children: [
            const Icon(Icons.map, size: 22),
            const SizedBox(width: 6),
            const Text('Actual Plot Map', style: TextStyle(fontWeight: FontWeight.bold)),
            const Spacer(),
            if (!compact) const Text('Pinch = Zoom • Drag = Map', style: TextStyle(fontSize: 12)),
          ]),
        ),
        SizedBox(
          height: compact ? plotH : 450,
          width: double.infinity,
          child: interactive ? map : SingleChildScrollView(scrollDirection: Axis.horizontal, child: map),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(10, 4, 10, 10),
          child: Wrap(spacing: 12, runSpacing: 5, children: [
            Text('उत्तर: ${gut.marks['उत्तर'] ?? ''}'), Text('दक्षिण: ${gut.marks['दक्षिण'] ?? ''}'),
            Text('पूर्व: ${gut.marks['पूर्व'] ?? ''}'), Text('पश्चिम: ${gut.marks['पश्चिम'] ?? ''}'),
            Text('Base: ${gut.numberStart}'),
            const Text('B = Base • R = Reference'),
          ]),
        ),
      ]),
    );
  }
}

class PlotPainter extends CustomPainter {
  final Gut gut;
  final double cellW;
  final int count;
  final String Function(int) ref;
  final Set<int> selectedRows;
  PlotPainter({required this.gut, required this.cellW, required this.count, required this.ref, this.selectedRows = const {}});

  @override
  void paint(Canvas canvas, Size size) {
    const left = 95.0;
    const top = 104.0;
    const bottom = 300.0;
    final right = left + count * cellW;

    final border = Paint()..style = PaintingStyle.stroke..strokeWidth = 2.2..color = Colors.brown.shade800;
    final bund = Paint()..style = PaintingStyle.stroke..strokeWidth = 5..color = Colors.brown.shade700;
    final pending = Paint()..style = PaintingStyle.fill..color = Colors.red.shade300;
    final running = Paint()..style = PaintingStyle.fill..color = Colors.amber.shade300;
    final complete = Paint()..style = PaintingStyle.fill..color = Colors.green.shade300;
    final rowBorder = Paint()..style = PaintingStyle.stroke..strokeWidth = 1..color = Colors.green.shade900;

    final baseLabel = gut.numberStart == 'पूर्व' ? 'पूर्व = B (Base)' : '${gut.numberStart} = B (Base)';
    _text(canvas, 'उत्तर • ${gut.marks['उत्तर'] ?? ''}', Offset(left + 2, 4), 12, Colors.black87, bold: true);
    _text(canvas, baseLabel, Offset(left, 72), 11, Colors.green.shade900, bold: true);
    _text(canvas, 'B = Base   R = Reference', Offset(right - 132, 72), 10, Colors.black87, bold: true);
    _text(canvas, 'दक्षिण • ${gut.marks['दक्षिण'] ?? ''}', Offset(left + 2, 365), 12, Colors.black87, bold: true);
    _text(canvas, 'पश्चिम • ${gut.marks['पश्चिम'] ?? ''}', Offset(4, 205), 12, Colors.black87, bold: true);
    _text(canvas, 'पूर्व • ${gut.marks['पूर्व'] ?? ''}', Offset(right + 8, 205), 12, Colors.black87, bold: true);
    _text(canvas, '↑ उत्तर', Offset(right + 8, 52), 13, Colors.blue.shade800, bold: true);

    // Continuous plot: no middle break. Extra rows on the bottom side are placed at the WEST end
    // (right-hand side when numbering starts from EAST) and occupy only half the plot length.
    canvas.drawLine(Offset(left, top - 7), Offset(right, top - 7), bund);
    canvas.drawLine(Offset(left, bottom + 7), Offset(right, bottom + 7), bund);

    final baseEast = gut.numberStart == 'पूर्व';
    final shared = gut.topRows < gut.bottomRows ? gut.topRows : gut.bottomRows;
    for (int i = 0; i < count; i++) {
      final isExtra = i >= shared;
      // Base numbering always grows from the selected base direction.
      // With EAST as base, extra rows (e.g. 38,39,40) are placed at the WEST end,
      // not on the EAST end. They remain short (half-height) because no opposite row exists.
      final x = baseEast ? right - (i + 1) * cellW : left + i * cellW;
      final northN = i < gut.topRows ? i + 1 : null;
      final southN = i < gut.bottomRows ? i + 1 : null;
      final rowNo = i + 1;
      final status = _statusFor(rowNo);
      final rowTop = isExtra ? top : top;
      final rowBottom = isExtra ? top + (bottom - top) * 0.50 : bottom;
      final rect = Rect.fromLTRB(x, rowTop, x + cellW, rowBottom);
      canvas.drawRect(rect, status == 'running' ? running : status == 'complete' ? complete : pending);
      canvas.drawRect(rect, rowBorder);

      // Each actual base row is selectable only by its B number. R is reference only.
      if (northN != null) {
        _refBox(canvas, Rect.fromLTWH(x, 38, cellW, 28), 'B${ref(northN)}', Colors.white, selected: selectedRows.contains(northN) || gut.runningRows.contains(northN));
        _refBox(canvas, Rect.fromLTWH(x, 66, cellW, 28), 'R${ref(gut.topRows - northN + 1)}', Colors.blue.shade50);
      }
      if (southN != null) {
        final bottomY = bottom + 10;
        _refBox(canvas, Rect.fromLTWH(x, bottomY, cellW, 28), 'B${ref(southN)}', Colors.white, selected: selectedRows.contains(southN) || gut.runningRows.contains(southN));
        _refBox(canvas, Rect.fromLTWH(x, bottomY + 28, cellW, 28), 'R${ref(gut.bottomRows - southN + 1)}', Colors.blue.shade50);
      }

      // Extra rows exist only on the side with the larger row count.
      // They are placed at the WEST end when EAST is the base direction.
      if (isExtra) {
        final extraY = top + (bottom - top) * 0.50;
        _centerText(canvas, 'B${ref(rowNo)}', Rect.fromLTWH(x, extraY + 2, cellW, 22), 8.5, Colors.black, bold: true);
        _centerText(canvas, 'R—', Rect.fromLTWH(x, extraY + 24, cellW, 20), 7.5, Colors.black87);
      }

      final marker = gut.rowMarks[rowNo];
      if (marker != null && marker.isNotEmpty) {
        _centerText(canvas, marker, rect, 7.5, Colors.black87, bold: true);
      }
      if (i > 0) canvas.drawLine(Offset(x, rowTop), Offset(x, rowBottom), rowBorder);
    }

    canvas.drawRect(Rect.fromLTRB(left, top, right, bottom), border);
    _text(canvas, 'पाण्याची दिशा: ${gut.rowDirection}', Offset(left, bottom + 72), 11, Colors.blue.shade800, bold: true);
    _legend(canvas, Offset(left, 405), Colors.red.shade300, 'बाकी');
    _legend(canvas, Offset(left + 72, 405), Colors.amber.shade300, 'पाणी सुरू');
    _legend(canvas, Offset(left + 175, 405), Colors.green.shade300, 'पूर्ण / बंद');
    _legend(canvas, Offset(left + 290, 405), Colors.brown.shade700, 'बांध');
  }

  String _statusFor(int row) {
    if (gut.runningRows.contains(row)) return 'running';
    final raw = gut.completedAt[row];
    if (raw != null) {
      final d = DateTime.tryParse(raw);
      if (d != null && DateTime.now().difference(d).inDays < 15) return 'complete';
    }
    return 'pending';
  }

  void _refBox(Canvas canvas, Rect r, String value, Color fill, {bool selected = false}) {
    final p = Paint()..color = selected ? Colors.lightBlue.shade100 : fill;
    canvas.drawRect(r, p);
    final b = Paint()..style = PaintingStyle.stroke..strokeWidth = selected ? 2.2 : 1..color = selected ? Colors.blue.shade900 : Colors.brown.shade400;
    canvas.drawRect(r, b);
    _centerText(canvas, value, r, 8.5, Colors.black, bold: true);
  }

  void _centerText(Canvas canvas, String value, Rect r, double size, Color color, {bool bold = false}) {
    final tp = TextPainter(
      text: TextSpan(text: value, style: TextStyle(fontSize: size, color: color, fontWeight: bold ? FontWeight.bold : FontWeight.normal)),
      textDirection: TextDirection.ltr,
    )..layout(maxWidth: r.width);
    tp.paint(canvas, Offset(r.center.dx - tp.width / 2, r.center.dy - tp.height / 2));
  }

  void _legend(Canvas canvas, Offset o, Color c, String label) {
    final p = Paint()..color = c;
    canvas.drawRect(Rect.fromLTWH(o.dx, o.dy, 16, 12), p);
    _text(canvas, label, Offset(o.dx + 20, o.dy - 2), 10, Colors.black87);
  }

  void _text(Canvas canvas, String value, Offset offset, double size, Color color, {bool bold = false}) {
    final tp = TextPainter(
      text: TextSpan(text: value, style: TextStyle(fontSize: size, color: color, fontWeight: bold ? FontWeight.bold : FontWeight.normal)),
      textDirection: TextDirection.ltr,
    )..layout();
    tp.paint(canvas, offset);
  }

  @override
  bool shouldRepaint(covariant PlotPainter oldDelegate) => true;
}

class WaterPage extends StatefulWidget {
  final AppStore store;
  const WaterPage({super.key, required this.store});
  @override State<WaterPage> createState() => _WaterPageState();
}

class _WaterPageState extends State<WaterPage> {
  final Set<int> selected = {};
  DateTime selectedDate = DateTime.now();

  String _status(Gut g, int n) {
    if (g.runningRows.contains(n)) return 'running';
    final raw = g.completedAt[n];
    if (raw != null) {
      final d = DateTime.tryParse(raw);
      if (d != null && DateTime.now().difference(d).inDays < 15) return 'complete';
    }
    return 'pending';
  }

  bool _sameDay(String iso, DateTime d) {
    final x = DateTime.tryParse(iso);
    return x != null && x.year == d.year && x.month == d.month && x.day == d.day;
  }

  String _fmt(String iso) {
    final d = DateTime.tryParse(iso);
    if (d == null) return iso;
    return '${d.day.toString().padLeft(2,'0')}/${d.month.toString().padLeft(2,'0')}/${d.year} '
        '${d.hour.toString().padLeft(2,'0')}:${d.minute.toString().padLeft(2,'0')}';
  }

  Future<void> _addSource() async {
    final c = TextEditingController();
    final name = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('नवीन पाणी स्रोत'),
        content: TextField(
          controller: c,
          autofocus: true,
          decoration: const InputDecoration(labelText: 'स्रोताचे नाव'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('रद्द')),
          FilledButton(onPressed: () => Navigator.pop(context, c.text.trim()), child: const Text('Save')),
        ],
      ),
    );
    if (name != null && name.trim().isNotEmpty) {
      await widget.store.addWaterSource(name);
      if (mounted) setState(() {});
    }
  }

  void _showReport({required bool live}) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => WaterReportPage(
          store: widget.store,
          date: selectedDate,
          live: live,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final g = widget.store.active;
    if (g == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('पाणी नियंत्रण')),
        body: const Center(child: Text('पहिले GUT तयार करा')),
      );
    }

    final count = g.topRows > g.bottomRows ? g.topRows : g.bottomRows;

    return Scaffold(
      appBar: AppBar(
        title: const Text('पाणी नियंत्रण ON / OFF'),
        actions: [
          IconButton(
            tooltip: 'आजचा Live Report',
            onPressed: () => _showReport(live: true),
            icon: const Icon(Icons.live_tv),
          ),
          IconButton(
            tooltip: 'Date-wise Report',
            onPressed: () => _showReport(live: false),
            icon: const Icon(Icons.assessment_outlined),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(10, 10, 10, 120),
        children: [
          Row(
            children: [
              Expanded(
                child: ListTile(
                  dense: true,
                  title: const Text('पाणी तारीख'),
                  subtitle: Text(
                    '${selectedDate.day.toString().padLeft(2,'0')}/${selectedDate.month.toString().padLeft(2,'0')}/${selectedDate.year}',
                  ),
                  trailing: const Icon(Icons.calendar_month),
                  onTap: () async {
                    final d = await showDatePicker(
                      context: context,
                      firstDate: DateTime(2020),
                      lastDate: DateTime(2100),
                      initialDate: selectedDate,
                    );
                    if (d != null) setState(() => selectedDate = d);
                  },
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: DropdownButtonFormField<String>(
                  value: widget.store.sources.contains(widget.store.source)
                      ? widget.store.source
                      : widget.store.sources.first,
                  decoration: const InputDecoration(labelText: 'पाणी स्रोत'),
                  items: widget.store.sources
                      .map((x) => DropdownMenuItem(value: x, child: Text(x)))
                      .toList(),
                  onChanged: (v) async {
                    if (v == null) return;
                    widget.store.source = v;
                    await widget.store.save();
                    setState(() {});
                  },
                ),
              ),
              IconButton(
                tooltip: 'नवीन पाणी स्रोत',
                onPressed: _addSource,
                icon: const Icon(Icons.add_circle),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            'GUT ${g.no} • Plot वर सरी टॅप करून निवडा',
            style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 6),
          PlotMapPreview(
            gut: g,
            compact: false,
            interactive: true,
            selectedRows: selected,
            onRowTap: (n) {
              if (n <= 0 || n > count) return;
              setState(() => selected.contains(n) ? selected.remove(n) : selected.add(n));
            },
          ),
          const SizedBox(height: 8),
          if (selected.isNotEmpty)
            Text(
              'निवडलेल्या सऱ्या: ${selected.toList()..sort()}',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: FilledButton.icon(
                  onPressed: selected.isEmpty ? null : _waterOn,
                  icon: const Icon(Icons.water_drop),
                  label: const Text('पाणी ON'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: FilledButton.tonalIcon(
                  onPressed: selected.isEmpty ? null : _waterOff,
                  icon: const Icon(Icons.water_drop_outlined),
                  label: const Text('पाणी OFF'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Text(
                '🔴 बाकी: ${List.generate(count, (i) => i+1).where((n) => _status(g,n)=='pending').length} सऱ्या\n'
                '🟡 चालू: ${g.runningRows.length} सऱ्या\n'
                '🟢 बंद करून 15 दिवसांच्या आत: ${List.generate(count, (i) => i+1).where((n) => _status(g,n)=='complete').length} सऱ्या\n'
                'स्रोत: ${widget.store.source}',
                style: const TextStyle(fontWeight: FontWeight.w600),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => _showReport(live: true),
                  icon: const Icon(Icons.live_tv),
                  label: const Text('आजचा Live Report'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => _showReport(live: false),
                  icon: const Icon(Icons.calendar_view_day),
                  label: const Text('Date-wise Report'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Future<void> _waterOn() async {
    final g = widget.store.active;
    if (g == null) return;
    final now = DateTime.now().toIso8601String();
    g.runningRows = {...g.runningRows, ...selected}.toList()..sort();
    for (final n in selected) {
      g.completedAt.remove(n);
      g.waterHistory.add(WaterEvent(
        dateTime: now,
        row: n,
        action: 'ON',
        source: widget.store.source,
      ));
    }
    await widget.store.save();
    widget.store.notifyListeners();
    if (mounted) setState(() => selected.clear());
  }

  Future<void> _waterOff() async {
    final g = widget.store.active;
    if (g == null) return;
    final now = DateTime.now().toIso8601String();
    for (final n in selected) {
      g.completedAt[n] = now;
      g.waterHistory.add(WaterEvent(
        dateTime: now,
        row: n,
        action: 'OFF',
        source: widget.store.source,
      ));
    }
    g.runningRows.removeWhere(selected.contains);
    await widget.store.save();
    widget.store.notifyListeners();
    if (mounted) setState(() => selected.clear());
  }
}

class WaterReportPage extends StatelessWidget {
  final AppStore store;
  final DateTime date;
  final bool live;

  const WaterReportPage({
    super.key,
    required this.store,
    required this.date,
    required this.live,
  });

  String _fmt(String iso) {
    final d = DateTime.tryParse(iso);
    if (d == null) return iso;
    return '${d.day.toString().padLeft(2,'0')}/${d.month.toString().padLeft(2,'0')}/${d.year} '
        '${d.hour.toString().padLeft(2,'0')}:${d.minute.toString().padLeft(2,'0')}';
  }

  bool _sameDay(String iso, DateTime d) {
    final x = DateTime.tryParse(iso);
    return x != null && x.year == d.year && x.month == d.month && x.day == d.day;
  }

  @override
  Widget build(BuildContext context) {
    final title = live ? 'पाणी Live Report • आज' : 'पाणी Date-wise Report';

    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(10, 10, 10, 40),
        children: [
          Card(
            child: ListTile(
              leading: Icon(live ? Icons.live_tv : Icons.calendar_month),
              title: Text(
                live
                    ? 'आज • ${date.day.toString().padLeft(2,'0')}/${date.month.toString().padLeft(2,'0')}/${date.year}'
                    : 'दिनांक • ${date.day.toString().padLeft(2,'0')}/${date.month.toString().padLeft(2,'0')}/${date.year}',
              ),
              subtitle: Text(live
                  ? 'प्रत्येक GUT चा आजचा पाणी status'
                  : 'निवडलेल्या तारखेतील ON / OFF history'),
            ),
          ),
          const SizedBox(height: 8),

          ...store.guts.map((g) {
            final events = g.waterHistory
                .where((e) => _sameDay(e.dateTime, date))
                .toList()
              ..sort((a, b) => a.dateTime.compareTo(b.dateTime));

            final maxRows = g.topRows > g.bottomRows ? g.topRows : g.bottomRows;

            if (live) {
              final running = g.runningRows.toList()..sort();
              final completed = List.generate(maxRows, (i) => i + 1)
                  .where((n) {
                    final raw = g.completedAt[n];
                    if (raw == null) return false;
                    final d = DateTime.tryParse(raw);
                    return d != null && DateTime.now().difference(d).inDays < 15;
                  })
                  .toList();
              final todayOn = events.where((e) => e.action == 'ON').map((e) => e.row).toSet().toList()..sort();
              final todayOff = events.where((e) => e.action == 'OFF').map((e) => e.row).toSet().toList()..sort();

              return Card(
                margin: const EdgeInsets.only(bottom: 10),
                child: ExpansionTile(
                  initiallyExpanded: true,
                  title: Text('GUT ${g.no}', style: const TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Text(
                    'आज ON: ${todayOn.length} • आज OFF: ${todayOff.length} • सध्या चालू: ${running.length}',
                  ),
                  children: [
                    ListTile(
                      dense: true,
                      title: const Text('🟡 सध्या पाणी सुरू'),
                      subtitle: Text(running.isEmpty ? 'एकही सरी सुरू नाही' : running.join(', ')),
                    ),
                    ListTile(
                      dense: true,
                      title: const Text('🟢 15 दिवसांत बंद'),
                      subtitle: Text(completed.isEmpty ? 'नाही' : completed.join(', ')),
                    ),
                    ListTile(
                      dense: true,
                      title: const Text('आजचे ON'),
                      subtitle: Text(todayOn.isEmpty ? 'नाही' : todayOn.join(', ')),
                    ),
                    ListTile(
                      dense: true,
                      title: const Text('आजचे OFF'),
                      subtitle: Text(todayOff.isEmpty ? 'नाही' : todayOff.join(', ')),
                    ),
                    if (events.isNotEmpty)
                      ...events.map(
                        (e) => ListTile(
                          dense: true,
                          leading: Icon(
                            e.action == 'ON' ? Icons.water_drop : Icons.water_drop_outlined,
                          ),
                          title: Text('सरी ${e.row} • ${e.action}'),
                          subtitle: Text('${_fmt(e.dateTime)} • स्रोत: ${e.source}'),
                        ),
                      ),
                  ],
                ),
              );
            }

            return Card(
              margin: const EdgeInsets.only(bottom: 10),
              child: ExpansionTile(
                initiallyExpanded: true,
                title: Text('GUT ${g.no}', style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text(
                  events.isEmpty
                      ? 'या तारखेला पाण्याची नोंद नाही'
                      : '${events.length} नोंदी',
                ),
                children: [
                  if (events.isEmpty)
                    const ListTile(
                      title: Text('या तारखेला पाणी ON / OFF नोंद नाही.'),
                    ),
                  ...events.map(
                    (e) => ListTile(
                      dense: true,
                      leading: CircleAvatar(
                        child: Text(e.row.toString()),
                      ),
                      title: Text(
                        'सरी ${e.row}  •  ${e.action == 'ON' ? 'पाणी लावले' : 'पाणी बंद केले'}',
                        style: const TextStyle(fontWeight: FontWeight.w600),
                      ),
                      subtitle: Text('${_fmt(e.dateTime)}\nस्रोत: ${e.source}'),
                      isThreeLine: true,
                    ),
                  ),
                ],
              ),
            );
          }),
        ],
      ),
    );
  }
}
