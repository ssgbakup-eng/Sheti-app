# Sheti App V27

Base source: Sheti_V4_25.zip. Android application ID remains `com.example.sheti_app`; release signing configuration and keystore are retained from V25 for update compatibility. Version: 4.5.0 (versionCode 27).

## V27 updates
1. Date and row-number headings in Report 1 PDF are bold; header cells use grey background.
2. Report status colors are aligned: red = no water/pending, yellow = water running, green = water stopped/completed within the completion window, black = row does not exist.
3. Water-source report dates and source headings are bold; compact row heights and narrow columns are used; PDF tables are split into date chunks of up to 50 per page.
4. Plot-mapping row marks remain saved in GUT data and are rendered on Plot View.
5. ON/OFF controls retain state-based enable/disable behavior and selection rules to prevent turning an already-running row ON by mistake.
6. Water history correction now supports GUT, date, and action/status filters.
7. All “Water Data Fresh” controls and the destructive fresh-data action were removed.
8. Water-source inactive/OFF cells are green in preview and PDF so report colors agree.
9. Report headings/date cells and status legends were aligned for readability.
10. Added Data Backup / Restore module: export GUTs, plot mapping, row marks/links, sources, water history and active selection to JSON; restore from a selected JSON backup.

## Build note
This source ZIP was updated, but a Flutter/Android build could not be run in this environment. Run the existing GitHub Actions workflow to resolve dependencies and build the APK, then test the APK and verify that its package ID and signing certificate match the installed V25 before installing as an update. Keep the installed V25 and a separate data backup until that verification succeeds.
