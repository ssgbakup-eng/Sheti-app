# Sheti App V4.0.6+12

Base: Fixed11.

Recent locked changes:
1. Extra south-side rows remain at the WEST end when numbering starts from EAST; they occupy half plot height and remain selectable.
2. Sari boxes reduced to approximately half the previous width.
3. Base/Reference are explicitly marked B/R; the B/R legend is at the north-east area of the map.
4. Base-number boxes are the water-selection keys; selected B numbers are visibly highlighted.
5. Existing design, water states, plot notes, continuous plot and zoom are retained.
