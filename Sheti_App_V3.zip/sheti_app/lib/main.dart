
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const ShetiApp());
}

enum WaterState { pending, running, done }

class RowMap {
  final int id;
  final String roadNumber;
  final List<int> drainNumbers;
  final bool marked;

  const RowMap({
    required this.id,
    required this.roadNumber,
    required this.drainNumbers,
    this.marked = false,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'roadNumber': roadNumber,
        'drainNumbers': drainNumbers,
        'marked': marked,
      };

  factory RowMap.fromJson(Map<String, dynamic> j) => RowMap(
        id: (j['id'] as num?)?.toInt() ?? 0,
        roadNumber: j['roadNumber']?.toString() ?? '',
        drainNumbers: ((j['drainNumbers'] as List?) ?? [])
            .map((e) => (e as num).toInt())
            .toList(),
        marked: j['marked'] == true,
      );
}

class RowState {
  final WaterState state;
  final DateTime? started;
  final DateTime? stopped;

  const RowState({this.state = WaterState.pending, this.started, this.stopped});

  Map<String, dynamic> toJson() => {
        'state': state.name,
        'started': started?.toIso8601String(),
        'stopped': stopped?.toIso8601String(),
      };

  factory RowState.fromJson(Map<String, dynamic> j) {
    final raw = j['state']?.toString() ?? 'pending';
    final state = WaterState.values.firstWhere(
      (e) => e.name == raw,
      orElse: () => WaterState.pending,
    );
    return RowState(
      state: state,
      started: DateTime.tryParse(j['started']?.toString() ?? ''),
      stopped: DateTime.tryParse(j['stopped']?.toString() ?? ''),
    );
  }
}

class WaterEntry {
  final String id;
  final DateTime date;
  final String gut;
  final String source;
  final List<int> rows;
  final String action;
  final DateTime time;

  WaterEntry({
    required this.id,
    required this.date,
    required this.gut,
    required this.source,
    required this.rows,
    required this.action,
    required this.time,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'date': date.toIso8601String(),
        'gut': gut,
        'source': source,
        'rows': rows,
        'action': action,
        'time': time.toIso8601String(),
      };

  factory WaterEntry.fromJson(Map<String, dynamic> j) => WaterEntry(
        id: j['id']?.toString() ?? '',
        date: DateTime.tryParse(j['date']?.toString() ?? '') ?? DateTime.now(),
        gut: j['gut']?.toString() ?? '120',
        source: j['source']?.toString() ?? '',
        rows: ((j['rows'] as List?) ?? []).map((e) => (e as num).toInt()).toList(),
        action: j['action']?.toString() ?? '',
        time: DateTime.tryParse(j['time']?.toString() ?? '') ?? DateTime.now(),
      );
}

class ShetiRecord {
  final String type;
  final String text;
  final DateTime date;
  final double? amount;

  ShetiRecord({
    required this.type,
    required this.text,
    required this.date,
    this.amount,
  });

  Map<String, dynamic> toJson() => {
        'type': type,
        'text': text,
        'date': date.toIso8601String(),
        'amount': amount,
      };

  factory ShetiRecord.fromJson(Map<String, dynamic> j) => ShetiRecord(
        type: j['type']?.toString() ?? 'इतर',
        text: j['text']?.toString() ?? '',
        date: DateTime.tryParse(j['date']?.toString() ?? '') ?? DateTime.now(),
        amount: (j['amount'] as num?)?.toDouble(),
      );
}

class ShetiStore extends ChangeNotifier {
  static const _recordKey = 'sheti_records_v1';
  static const _rowsKey = 'sheti_gut120_rows_v2';
  static const _mappingKey = 'sheti_plot_mapping_v3';
  static const _waterKey = 'sheti_water_entries_v3';

  List<ShetiRecord> records = [];
  List<WaterEntry> waterEntries = [];
  Map<int, RowState> rows = {};
  List<RowMap> mapping = List.generate(
    37,
    (i) => RowMap(
      id: i + 1,
      roadNumber: '${i + 1}',
      drainNumbers: [i + 1],
    ),
  );

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();

    final raw = p.getStringList(_recordKey) ?? [];
    records = raw.map((x) => ShetiRecord.fromJson(jsonDecode(x))).toList();

    final rowRaw = p.getString(_rowsKey);
    if (rowRaw != null) {
      final decoded = jsonDecode(rowRaw) as Map<String, dynamic>;
      rows = decoded.map(
        (k, v) => MapEntry(int.parse(k), RowState.fromJson(v)),
      );
    }

    final mapRaw = p.getString(_mappingKey);
    if (mapRaw != null) {
      final list = jsonDecode(mapRaw) as List;
      mapping = list.map((e) => RowMap.fromJson(e)).toList();
    } else {
      mapping = _defaultMapping();
    }

    final waterRaw = p.getString(_waterKey);
    if (waterRaw != null) {
      final list = jsonDecode(waterRaw) as List;
      waterEntries = list.map((e) => WaterEntry.fromJson(e)).toList();
    }

    notifyListeners();
  }

  List<RowMap> _defaultMapping() {
    final result = <RowMap>[];
    for (int i = 1; i <= 37; i++) {
      if (i == 12) {
        result.add(const RowMap(id: 12, roadNumber: '12', drainNumbers: [14, 15]));
      } else if (i <= 11) {
        result.add(RowMap(id: i, roadNumber: '$i', drainNumbers: [i]));
      } else {
        result.add(RowMap(id: i, roadNumber: '$i', drainNumbers: [i + 2]));
      }
    }
    return result;
  }

  Future<void> _saveRows() async {
    final p = await SharedPreferences.getInstance();
    await p.setString(
      _rowsKey,
      jsonEncode(rows.map((k, v) => MapEntry(k.toString(), v.toJson()))),
    );
  }

  Future<void> setRows(Iterable<int> numbers, WaterState state) async {
    final now = DateTime.now();
    for (final n in numbers) {
      final old = rows[n] ?? const RowState();
      rows[n] = RowState(
        state: state,
        started: state == WaterState.running ? now : old.started,
        stopped: state == WaterState.done ? now : old.stopped,
      );
    }
    await _saveRows();
    notifyListeners();
  }

  Future<void> setRow(int n, WaterState state) => setRows([n], state);

  Future<void> saveMapping(List<RowMap> newMap) async {
    mapping = List<RowMap>.from(newMap);
    final p = await SharedPreferences.getInstance();
    await p.setString(
      _mappingKey,
      jsonEncode(mapping.map((e) => e.toJson()).toList()),
    );
    notifyListeners();
  }

  Future<void> addWater({
    required DateTime date,
    required String gut,
    required String source,
    required List<int> selectedRows,
    required String action,
  }) async {
    final entry = WaterEntry(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      date: date,
      gut: gut,
      source: source,
      rows: List<int>.from(selectedRows),
      action: action,
      time: DateTime.now(),
    );
    waterEntries.insert(0, entry);
    final p = await SharedPreferences.getInstance();
    await p.setString(
      _waterKey,
      jsonEncode(waterEntries.map((e) => e.toJson()).toList()),
    );
    notifyListeners();
  }

  Future<void> add(ShetiRecord r) async {
    records.insert(0, r);
    final p = await SharedPreferences.getInstance();
    await p.setStringList(
      _recordKey,
      records.map((x) => jsonEncode(x.toJson())).toList(),
    );
    notifyListeners();
  }

  void resetMapping() {
    saveMapping(_defaultMapping());
  }
}

class ShetiApp extends StatefulWidget {
  const ShetiApp({super.key});
  @override
  State<ShetiApp> createState() => _ShetiAppState();
}

class _ShetiAppState extends State<ShetiApp> {
  final store = ShetiStore();

  @override
  void initState() {
    super.initState();
    store.load();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (_, __) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'शेती',
        theme: ThemeData(
          useMaterial3: true,
          colorSchemeSeed: const Color(0xFF087443),
          scaffoldBackgroundColor: const Color(0xFFF5F8F3),
          appBarTheme: const AppBarTheme(
            backgroundColor: Color(0xFF006B43),
            foregroundColor: Colors.white,
            centerTitle: false,
          ),
        ),
        home: MainPage(store: store),
      ),
    );
  }
}

class MainPage extends StatelessWidget {
  final ShetiStore store;
  const MainPage({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('🌱 शेती App', style: TextStyle(fontWeight: FontWeight.w800)),
      ),
      body: GridView.count(
        padding: const EdgeInsets.all(16),
        crossAxisCount: 2,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        childAspectRatio: 1.18,
        children: [
          _menu(context, Icons.home, 'होम', const Color(0xFFEDF5FF), () {}),
          _menu(context, Icons.grass, 'प्लॉट मास्टर', const Color(0xFFEFF8EF), () {}),
          _menu(context, Icons.water_drop, 'पाणी व्यवस्थापन', const Color(0xFFE9F7FF), () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => WaterManagementPage(store: store)));
          }),
          _menu(context, Icons.eco, 'खत व्यवस्थापन', const Color(0xFFF2F8E9), () {}),
          _menu(context, Icons.bar_chart, 'अहवाल', const Color(0xFFFFF5E8), () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => WaterReportPage(store: store)));
          }),
          _menu(context, Icons.settings, 'सेटिंग', const Color(0xFFF3ECFF), () {}),
          _menu(context, Icons.people, 'मजूर व्यवस्थापन', const Color(0xFFFFF0E7), () {}),
          _menu(context, Icons.backup, 'डेटा बॅकअप', const Color(0xFFFFEAF0), () {}),
        ],
      ),
    );
  }

  Widget _menu(
    BuildContext context,
    IconData icon,
    String title,
    Color bg,
    VoidCallback onTap,
  ) {
    return Card(
      color: bg,
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 42, color: const Color(0xFF087443)),
              const SizedBox(height: 10),
              Text(title, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w800)),
            ],
          ),
        ),
      ),
    );
  }
}

class WaterManagementPage extends StatelessWidget {
  final ShetiStore store;
  const WaterManagementPage({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('पाणी व्यवस्थापन')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _tile(context, Icons.map_outlined, 'प्लॉट मॅपिंग', 'GUT, सऱ्या, नंबरिंग, दिशा व खुणा', () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => PlotMappingPage(store: store)));
          }),
          _tile(context, Icons.play_circle_fill, 'पाणी चालू / बंद', 'तारीख, GUT, स्रोत आणि सरी निवडा', () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => WaterControlPage(store: store)));
          }),
          _tile(context, Icons.description, 'पाणी अहवाल', 'GUT-wise, दिनांकवार आणि सरीवार', () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => WaterReportPage(store: store)));
          }),
          _tile(context, Icons.history, 'पाणी इतिहास', 'पूर्वीचे सर्व पाणी रेकॉर्ड', () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => WaterHistoryPage(store: store)));
          }),
          _tile(context, Icons.water, 'पाणी स्रोत मास्टर', 'विहीर, बोअर, कालवा इ.', () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => SourceMasterPage()));
          }),
        ],
      ),
    );
  }

  Widget _tile(BuildContext c, IconData icon, String title, String sub, VoidCallback tap) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: ListTile(
        contentPadding: const EdgeInsets.all(12),
        leading: CircleAvatar(
          radius: 25,
          backgroundColor: const Color(0xFFE4F6ED),
          child: Icon(icon, color: const Color(0xFF087443)),
        ),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
        subtitle: Text(sub),
        trailing: const Icon(Icons.chevron_right),
        onTap: tap,
      ),
    );
  }
}

class PlotMappingPage extends StatelessWidget {
  final ShetiStore store;
  const PlotMappingPage({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('प्लॉट मॅपिंग'),
        actions: [
          IconButton(
            tooltip: 'मॅप अपडेट',
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => MappingEditorPage(store: store)),
            ),
            icon: const Icon(Icons.edit),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          Card(
            color: const Color(0xFFFFF900),
            child: const Padding(
              padding: EdgeInsets.all(12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('AREA 2 EKAR', style: TextStyle(fontWeight: FontWeight.w900)),
                  Text('550 फूट', style: TextStyle(fontWeight: FontWeight.w900)),
                ],
              ),
            ),
          ),
          const SizedBox(height: 8),
          const _RoadLabel(),
          const SizedBox(height: 4),
          PlotMap(store: store),
          const SizedBox(height: 10),
          const _DrainLabel(),
          const SizedBox(height: 10),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Text(
                'नंबरिंग: रस्ता बाजू 1 → 37 आणि उलट 37 → 1. '
                'नाली बाजू 1 → 40 आणि उलट 40 → 1. '
                'विशेष Mapping: रस्ता सरी 12 → नाली सरी 14, 15.',
                style: const TextStyle(fontWeight: FontWeight.w700),
              ),
            ),
          ),
          const SizedBox(height: 10),
          FilledButton.icon(
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => MappingEditorPage(store: store)),
            ),
            icon: const Icon(Icons.edit_location_alt),
            label: const Text('मॅपिंग अपडेट करा'),
          ),
        ],
      ),
    );
  }
}

class _RoadLabel extends StatelessWidget {
  const _RoadLabel();
  @override
  Widget build(BuildContext context) => Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 7),
        color: const Color(0xFF424242),
        child: const Text(
          'रस्ता बाजू • 37 सऱ्या',
          textAlign: TextAlign.center,
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900),
        ),
      );
}

class _DrainLabel extends StatelessWidget {
  const _DrainLabel();
  @override
  Widget build(BuildContext context) => Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 7),
        color: const Color(0xFF49A8D8),
        child: const Text(
          'नाली बाजू • 40 सऱ्या',
          textAlign: TextAlign.center,
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900),
        ),
      );
}

class PlotMap extends StatelessWidget {
  final ShetiStore store;
  const PlotMap({super.key, required this.store});

  Color _rowColor(int n) {
    final state = store.rows[n]?.state ?? WaterState.pending;
    if (state == WaterState.done) return Colors.green.shade600;
    if (state == WaterState.running) return Colors.amber.shade700;
    return Colors.red.shade400;
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: SizedBox(
        width: 37 * 36.0,
        child: Column(
          children: [
            _numbers(List.generate(37, (i) => i + 1)),
            Row(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: List.generate(37, (i) {
                final road = i + 1;
                return GestureDetector(
                  onTap: () async {
                    final old = store.rows[road]?.state ?? WaterState.pending;
                    final next = old == WaterState.pending
                        ? WaterState.running
                        : old == WaterState.running
                            ? WaterState.done
                            : WaterState.pending;
                    await store.setRow(road, next);
                  },
                  child: Container(
                    width: 35,
                    height: 150,
                    margin: const EdgeInsets.only(right: 1),
                    decoration: BoxDecoration(
                      color: _rowColor(road),
                      border: Border.all(color: Colors.white, width: 1),
                    ),
                    child: const Center(
                      child: RotatedBox(
                        quarterTurns: 3,
                        child: Text(
                          '550 ft • सरी',
                          style: TextStyle(color: Colors.white, fontSize: 8, fontWeight: FontWeight.w900),
                        ),
                      ),
                    ),
                  ),
                );
              }),
            ),
            _numbers(List.generate(37, (i) => 37 - i)),
            const SizedBox(height: 8),
            const Divider(thickness: 3),
            const SizedBox(height: 8),
            _numbers(List.generate(40, (i) => i + 1), width: 36),
            Row(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: List.generate(40, (i) {
                final n = i + 1;
                return GestureDetector(
                  onTap: () async {
                    final old = store.rows[n]?.state ?? WaterState.pending;
                    final next = old == WaterState.pending
                        ? WaterState.running
                        : old == WaterState.running
                            ? WaterState.done
                            : WaterState.pending;
                    await store.setRow(n, next);
                  },
                  child: Container(
                    width: 35,
                    height: 150,
                    margin: const EdgeInsets.only(right: 1),
                    decoration: BoxDecoration(
                      color: _rowColor(n),
                      border: Border.all(color: Colors.white, width: 1),
                    ),
                    child: const Center(
                      child: RotatedBox(
                        quarterTurns: 3,
                        child: Text(
                          '550 ft • सरी',
                          style: TextStyle(color: Colors.white, fontSize: 8, fontWeight: FontWeight.w900),
                        ),
                      ),
                    ),
                  ),
                );
              }),
            ),
            _numbers(List.generate(40, (i) => 40 - i), width: 36),
          ],
        ),
      ),
    );
  }

  Widget _numbers(List<int> nums, {double width = 36}) {
    return Row(
      children: nums
          .map((n) => Container(
                width: width - 1,
                margin: const EdgeInsets.only(right: 1),
                padding: const EdgeInsets.symmetric(vertical: 4),
                color: Colors.white,
                child: Text(
                  '$n',
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w900),
                ),
              ))
          .toList(),
    );
  }
}

class MappingEditorPage extends StatefulWidget {
  final ShetiStore store;
  const MappingEditorPage({super.key, required this.store});

  @override
  State<MappingEditorPage> createState() => _MappingEditorPageState();
}

class _MappingEditorPageState extends State<MappingEditorPage> {
  late List<RowMap> map;
  int selected = 12;

  @override
  void initState() {
    super.initState();
    map = List<RowMap>.from(widget.store.mapping);
  }

  void save() async {
    await widget.store.saveMapping(map);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('प्लॉट मॅपिंग सेव्ह झाले')));
      Navigator.pop(context);
    }
  }

  void addRow() {
    final next = map.length + 1;
    setState(() {
      map.add(RowMap(id: next, roadNumber: '$next', drainNumbers: [next]));
    });
  }

  void removeRow() {
    if (map.length <= 1) return;
    setState(() => map.removeLast());
  }

  @override
  Widget build(BuildContext context) {
    final current = map.firstWhere((e) => e.id == selected, orElse: () => map.first);
    return Scaffold(
      appBar: AppBar(
        title: const Text('मॅपिंग अपडेट'),
        actions: [IconButton(onPressed: save, icon: const Icon(Icons.save))],
      ),
      body: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          _section('सरी व्यवस्थापन', [
            Row(
              children: [
                Expanded(child: _numberBox('रस्ता बाजू सऱ्या', 37)),
                const SizedBox(width: 8),
                Expanded(child: _numberBox('नाली बाजू सऱ्या', 40)),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: addRow,
                    icon: const Icon(Icons.add),
                    label: const Text('सरी Insert'),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: removeRow,
                    icon: const Icon(Icons.remove),
                    label: const Text('सरी Delete'),
                  ),
                ),
              ],
            ),
          ]),
          _section('Numbering / दिशा', [
            DropdownButtonFormField<String>(
              value: '1 → 37',
              decoration: const InputDecoration(labelText: 'रस्ता बाजू नंबर'),
              items: const [
                DropdownMenuItem(value: '1 → 37', child: Text('1 → 37')),
                DropdownMenuItem(value: '37 → 1', child: Text('37 → 1')),
              ],
              onChanged: (_) {},
            ),
            const SizedBox(height: 10),
            DropdownButtonFormField<String>(
              value: '40 → 1',
              decoration: const InputDecoration(labelText: 'नाली बाजू उलट दिशा नंबर'),
              items: const [
                DropdownMenuItem(value: '40 → 1', child: Text('40 → 1')),
                DropdownMenuItem(value: '1 → 40', child: Text('1 → 40')),
              ],
              onChanged: (_) {},
            ),
          ]),
          _section('विशेष सरी जोडणी', [
            DropdownButtonFormField<int>(
              value: selected,
              decoration: const InputDecoration(labelText: 'रस्ता सरी'),
              items: map.map((e) => DropdownMenuItem(value: e.id, child: Text('${e.roadNumber}'))).toList(),
              onChanged: (v) => setState(() => selected = v ?? selected),
            ),
            const SizedBox(height: 10),
            Text('नाली बाजूचे नंबर: ${current.drainNumbers.join(', ')}', style: const TextStyle(fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 6,
              children: List.generate(40, (i) {
                final n = i + 1;
                final active = current.drainNumbers.contains(n);
                return FilterChip(
                  selected: active,
                  label: Text('$n'),
                  onSelected: (v) {
                    setState(() {
                      final idx = map.indexWhere((e) => e.id == selected);
                      final old = map[idx];
                      final next = List<int>.from(old.drainNumbers);
                      if (v) {
                        if (!next.contains(n)) next.add(n);
                      } else {
                        next.remove(n);
                      }
                      map[idx] = RowMap(
                        id: old.id,
                        roadNumber: old.roadNumber,
                        drainNumbers: next,
                        marked: old.marked,
                      );
                    });
                  },
                );
              }),
            ),
          ]),
          _section('बाजूच्या / सरींच्या खुणा', [
            SwitchListTile(
              title: const Text('निवडलेल्या सरीला विशेष खूण'),
              value: current.marked,
              onChanged: (v) {
                final idx = map.indexWhere((e) => e.id == selected);
                final old = map[idx];
                setState(() {
                  map[idx] = RowMap(
                    id: old.id,
                    roadNumber: old.roadNumber,
                    drainNumbers: old.drainNumbers,
                    marked: v,
                  );
                });
              },
            ),
            const Text('Cross / Arrow / L / Motor अशी खूण पुढील आवृत्तीतही याच Mapping मध्ये सेव्ह करता येईल.'),
          ]),
          const SizedBox(height: 8),
          FilledButton.icon(onPressed: save, icon: const Icon(Icons.save), label: const Text('मॅपिंग सेव्ह करा')),
          OutlinedButton(
            onPressed: () {
              setState(() {
                map = _defaultMappingForUi();
              });
            },
            child: const Text('Default Mapping पुन्हा लावा'),
          ),
        ],
      ),
    );
  }

  List<RowMap> _defaultMappingForUi() {
    final result = <RowMap>[];
    for (int i = 1; i <= 37; i++) {
      if (i == 12) {
        result.add(const RowMap(id: 12, roadNumber: '12', drainNumbers: [14, 15]));
      } else if (i <= 11) {
        result.add(RowMap(id: i, roadNumber: '$i', drainNumbers: [i]));
      } else {
        result.add(RowMap(id: i, roadNumber: '$i', drainNumbers: [i + 2]));
      }
    }
    return result;
  }

  Widget _numberBox(String title, int value) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(10),
        child: Column(
          children: [
            Text(title, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w700)),
            Text('$value', style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
          ],
        ),
      ),
    );
  }

  Widget _section(String title, List<Widget> children) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900, color: Color(0xFF087443))),
          const SizedBox(height: 10),
          ...children,
        ]),
      ),
    );
  }
}

class WaterControlPage extends StatefulWidget {
  final ShetiStore store;
  const WaterControlPage({super.key, required this.store});

  @override
  State<WaterControlPage> createState() => _WaterControlPageState();
}

class _WaterControlPageState extends State<WaterControlPage> {
  DateTime date = DateTime.now();
  String gut = '120';
  String source = 'विहीर 1';
  final Set<int> selected = {};

  Future<void> pickDate() async {
    final d = await showDatePicker(
      context: context,
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
      initialDate: date,
    );
    if (d != null) setState(() => date = d);
  }

  Future<void> apply(String action) async {
    if (selected.isEmpty) return;
    final list = selected.toList()..sort();
    await widget.store.setRows(
      list,
      action == 'चालू' ? WaterState.running : WaterState.done,
    );
    await widget.store.addWater(
      date: date,
      gut: gut,
      source: source,
      selectedRows: list,
      action: action,
    );
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('सरी ${list.join(', ')} • पाणी $action सेव्ह झाले')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('पाणी चालू / बंद')),
      body: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(children: [
                ListTile(
                  title: const Text('तारीख'),
                  subtitle: Text('${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}/${date.year}'),
                  trailing: IconButton(onPressed: pickDate, icon: const Icon(Icons.calendar_month)),
                ),
                DropdownButtonFormField<String>(
                  value: gut,
                  decoration: const InputDecoration(labelText: 'GUT'),
                  items: const [DropdownMenuItem(value: '120', child: Text('120'))],
                  onChanged: (v) => setState(() => gut = v ?? gut),
                ),
                const SizedBox(height: 10),
                DropdownButtonFormField<String>(
                  value: source,
                  decoration: const InputDecoration(labelText: 'पाणी स्रोत'),
                  items: const [
                    DropdownMenuItem(value: 'विहीर 1', child: Text('विहीर 1')),
                    DropdownMenuItem(value: 'बोअर 1', child: Text('बोअर 1')),
                    DropdownMenuItem(value: 'कालवा', child: Text('कालवा')),
                  ],
                  onChanged: (v) => setState(() => source = v ?? source),
                ),
              ]),
            ),
          ),
          const SizedBox(height: 8),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('सऱ्या निवडा', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 5,
                  runSpacing: 5,
                  children: List.generate(40, (i) {
                    final n = i + 1;
                    return FilterChip(
                      selected: selected.contains(n),
                      label: Text('$n'),
                      onSelected: (v) => setState(() => v ? selected.add(n) : selected.remove(n)),
                    );
                  }),
                ),
                const SizedBox(height: 8),
                Text('निवडलेल्या सऱ्या: ${selected.toList()..sort()}', style: const TextStyle(fontWeight: FontWeight.w800)),
              ]),
            ),
          ),
          const SizedBox(height: 10),
          FilledButton.icon(
            onPressed: () => apply('चालू'),
            icon: const Icon(Icons.play_arrow),
            label: const Text('पाणी चालू'),
            style: FilledButton.styleFrom(backgroundColor: Colors.amber.shade700, foregroundColor: Colors.black),
          ),
          const SizedBox(height: 8),
          FilledButton.icon(
            onPressed: () => apply('बंद'),
            icon: const Icon(Icons.stop),
            label: const Text('पाणी बंद'),
            style: FilledButton.styleFrom(backgroundColor: Colors.red.shade600),
          ),
        ],
      ),
    );
  }
}

class WaterReportPage extends StatefulWidget {
  final ShetiStore store;
  const WaterReportPage({super.key, required this.store});

  @override
  State<WaterReportPage> createState() => _WaterReportPageState();
}

class _WaterReportPageState extends State<WaterReportPage> {
  DateTimeRange? range;

  Future<void> pickRange() async {
    final r = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
      initialDateRange: range,
    );
    if (r != null) setState(() => range = r);
  }

  List<WaterEntry> get data {
    return widget.store.waterEntries.where((e) {
      if (range == null) return true;
      return !e.date.isBefore(range!.start) &&
          !e.date.isAfter(range!.end.add(const Duration(days: 1)));
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('पाणी अहवाल')),
      body: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          Card(
            child: ListTile(
              leading: const Icon(Icons.date_range),
              title: const Text('दिनांक फिल्टर'),
              subtitle: Text(range == null
                  ? 'सर्व नोंदी'
                  : '${range!.start.day}/${range!.start.month}/${range!.start.year} ते ${range!.end.day}/${range!.end.month}/${range!.end.year}'),
              trailing: IconButton(onPressed: pickRange, icon: const Icon(Icons.calendar_month)),
            ),
          ),
          const SizedBox(height: 8),
          _reportTile('GUT-wise पाणी अहवाल', Icons.bar_chart, '${data.length} नोंदी'),
          _reportTile('दिनांकवार पाणी अहवाल', Icons.calendar_month, 'तारीखेनुसार'),
          _reportTile('सरीवार पाणी इतिहास', Icons.view_column, 'सरीनुसार'),
          _reportTile('पाणी न दिलेल्या सऱ्या', Icons.warning_amber, '${widget.store.rows.values.where((e) => e.state == WaterState.pending).length} pending'),
          _reportTile('सध्या चालू पाणी', Icons.play_circle, '${widget.store.rows.values.where((e) => e.state == WaterState.running).length} सऱ्या'),
          _reportTile('प्लॉट मॅपिंग अहवाल', Icons.map, 'GUT 120'),
          _reportTile('संपूर्ण GUT पाणी इतिहास', Icons.history, '${widget.store.waterEntries.length} नोंदी'),
          const SizedBox(height: 10),
          const Text('अलीकडील पाणी नोंदी', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
          const SizedBox(height: 6),
          ...data.take(20).map((e) => Card(
                child: ListTile(
                  leading: Icon(e.action == 'चालू' ? Icons.play_arrow : Icons.stop,
                      color: e.action == 'चालू' ? Colors.amber.shade800 : Colors.green),
                  title: Text('GUT ${e.gut} • ${e.action}', style: const TextStyle(fontWeight: FontWeight.w800)),
                  subtitle: Text('सऱ्या: ${e.rows.join(', ')}\n${e.source} • ${_date(e.date)} • ${_hm(e.time)}'),
                ),
              )),
        ],
      ),
    );
  }

  Widget _reportTile(String title, IconData icon, String sub) {
    return Card(
      child: ListTile(
        leading: Icon(icon, color: const Color(0xFF087443)),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
        subtitle: Text(sub),
        trailing: const Icon(Icons.chevron_right),
      ),
    );
  }
}

class WaterHistoryPage extends StatelessWidget {
  final ShetiStore store;
  const WaterHistoryPage({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('पाणी इतिहास')),
      body: store.waterEntries.isEmpty
          ? const Center(child: Text('अजून पाणी नोंद नाही.'))
          : ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: store.waterEntries.length,
              itemBuilder: (_, i) {
                final e = store.waterEntries[i];
                return Card(
                  child: ListTile(
                    leading: CircleAvatar(
                      backgroundColor: e.action == 'चालू' ? Colors.amber.shade100 : Colors.green.shade100,
                      child: Icon(e.action == 'चालू' ? Icons.play_arrow : Icons.stop),
                    ),
                    title: Text('GUT ${e.gut} • पाणी ${e.action}', style: const TextStyle(fontWeight: FontWeight.w800)),
                    subtitle: Text('${_date(e.date)} • ${_hm(e.time)}\nस्रोत: ${e.source}\nसऱ्या: ${e.rows.join(', ')}'),
                  ),
                );
              },
            ),
    );
  }
}

class SourceMasterPage extends StatefulWidget {
  const SourceMasterPage({super.key});
  @override
  State<SourceMasterPage> createState() => _SourceMasterPageState();
}

class _SourceMasterPageState extends State<SourceMasterPage> {
  final sources = <String>['विहीर 1', 'बोअर 1', 'कालवा'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('पाणी स्रोत मास्टर')),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          ...sources.map((s) => Card(child: ListTile(title: Text(s), trailing: const Icon(Icons.water_drop)))),
          const SizedBox(height: 8),
          FilledButton.icon(
            onPressed: () async {
              final c = TextEditingController();
              final value = await showDialog<String>(
                context: context,
                builder: (_) => AlertDialog(
                  title: const Text('नवीन पाणी स्रोत'),
                  content: TextField(controller: c, decoration: const InputDecoration(labelText: 'स्रोताचे नाव')),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(context), child: const Text('रद्द')),
                    FilledButton(onPressed: () => Navigator.pop(context, c.text.trim()), child: const Text('सेव्ह')),
                  ],
                ),
              );
              if (value != null && value.isNotEmpty) setState(() => sources.add(value));
            },
            icon: const Icon(Icons.add),
            label: const Text('पाणी स्रोत जोडा'),
          ),
        ],
      ),
    );
  }
}

class VoiceUpdatePage extends StatefulWidget {
  final ShetiStore store;
  const VoiceUpdatePage({super.key, required this.store});
  @override
  State<VoiceUpdatePage> createState() => _VoiceUpdatePageState();
}

class _VoiceUpdatePageState extends State<VoiceUpdatePage> {
  final speech = stt.SpeechToText();
  final controller = TextEditingController();
  bool listening = false;

  Future<void> toggle() async {
    if (listening) {
      await speech.stop();
      setState(() => listening = false);
      return;
    }
    final ok = await speech.initialize();
    if (!ok) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('माइक परवानगी तपासा')));
      }
      return;
    }
    setState(() => listening = true);
    await speech.listen(
      localeId: 'mr_IN',
      listenOptions: stt.SpeechListenOptions(partialResults: true),
      onResult: (r) => setState(() => controller.text = r.recognizedWords),
    );
  }

  List<int> numbers(String s) => RegExp(r'\d+')
      .allMatches(s)
      .map((m) => int.tryParse(m.group(0)!) ?? 0)
      .where((n) => n >= 1 && n <= 40)
      .toSet()
      .toList();

  Future<void> apply() async {
    final s = controller.text.trim();
    final ns = numbers(s);
    if (ns.isEmpty || !s.contains('पाणी')) return;
    if (s.contains('चालू')) {
      await widget.store.setRows(ns, WaterState.running);
    } else if (s.contains('बंद') || s.contains('पूर्ण')) {
      await widget.store.setRows(ns, WaterState.done);
    } else {
      return;
    }
    await widget.store.addWater(
      date: DateTime.now(),
      gut: '120',
      source: 'Voice',
      selectedRows: ns,
      action: s.contains('चालू') ? 'चालू' : 'बंद',
    );
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Voice Update')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  Text(listening ? 'ऐकत आहे...' : 'मराठीत बोला'),
                  const SizedBox(height: 15),
                  FloatingActionButton.large(
                    onPressed: toggle,
                    child: Icon(listening ? Icons.stop : Icons.mic),
                  ),
                  const SizedBox(height: 12),
                  const Text('उदा. पाणी बंद सरी 10, 11, 12'),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: controller,
            maxLines: 5,
            decoration: const InputDecoration(border: OutlineInputBorder(), labelText: 'Voice मजकूर'),
          ),
          const SizedBox(height: 12),
          FilledButton.icon(onPressed: apply, icon: const Icon(Icons.water_drop), label: const Text('पाणी अपडेट लागू करा')),
        ],
      ),
    );
  }
}

String _date(DateTime d) => '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}';
String _hm(DateTime d) => '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';
