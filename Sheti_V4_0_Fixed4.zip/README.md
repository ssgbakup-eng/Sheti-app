# Sheti App V4.0.1 Fixed4

Flutter app for GUT Update, Plot Mapping, Plot View and Water ON/OFF Live Map.

This build includes a syntax-safe rewrite of the Plot Mapping empty-state navigation.
