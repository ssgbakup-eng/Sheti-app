# Sheti App V26

Version: 4.4.0+26

V26 changes based on the V25 source:
1. Date-wise PDF dates and row numbers bold; row-number header grey and included on each generated page.
2. PDF color legend included.
3. Water-source PDF date/source headers bold, narrower columns and up to 50 dates per page.
4. Plot row markers are saved and rendered more visibly on the plot map.
5. ON/OFF controls are enabled based on selected row states; actions affect only eligible selected rows.
6. Water history correction supports GUT, date, and ON/OFF/RESET filters.
7. Removed the destructive “सर्व पाणी डेटा Fresh” control.
8. Plot map OFF status follows event history and uses green for up to 15 days after OFF, consistent with the report.

APK builds must use the existing Android application ID and the same release signing certificate as the installed app to support in-place updates.
