Sheti V4.19

Base: previous V13 source. Only two requested changes:
1) Permanent release signing key restored from the existing Sheti release key used by the recent builds, with the same applicationId and higher versionCode for APK update.
2) Base/Reference row logic: selected Base direction controls B numbering and selection; R is reverse reference only. With EAST as Base, B01 starts at the EAST edge and progresses toward WEST; extra rows beyond the north/top count extend only on the WEST side and remain selectable by their B numbers.

No other design changes intended.


V20: Report 1 modifies the old Date-wise report (From/To, GUT filter, 1-50 sari status, DD.MM.YY, preview zoom, A4 landscape PDF). Report 2 is new Water Source Availability report (date x source, GUT/crop, preview zoom, A4 portrait PDF).


V21 water management updates: From-To row selection, water OFF preselection with unselect-to-keep-running, confirmation before OFF, row reset to red, and all-water-data fresh action preserving GUT and plot mapping.
