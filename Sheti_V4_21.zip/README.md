# Sheti App V21 (4.1.7+21)

Package/version-number baseline prepared from V20 FIXED2.
Package ID must remain com.example.sheti_app and release signing must use the same existing key.

IMPORTANT: This ZIP has not been Flutter-built or verified in GitHub Actions. The requested V21 water ON/OFF workflow, fresh-water-data action, and report refinements must be implemented and tested before treating this as a final release.
