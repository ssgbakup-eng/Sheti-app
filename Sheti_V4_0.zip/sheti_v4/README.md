# Sheti App V4.0

Finalized first release focused on:
- GUT Update
- Plot Mapping
- Actual Plot Map View
- Water ON/OFF + Live Map

Stable Android package id should remain `com.example.sheti_app` when the GitHub workflow recreates Android.
