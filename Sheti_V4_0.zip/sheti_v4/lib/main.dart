import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const ShetiApp());

class ShetiApp extends StatelessWidget {
  const ShetiApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'शेती',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.green,
        scaffoldBackgroundColor: const Color(0xFFF7FAF3),
        inputDecorationTheme: const InputDecorationTheme(border: OutlineInputBorder()),
      ),
      home: const AppShell(),
    );
  }
}

class Gut {
  String no, area, crop, length, remark;
  String rowDirection, numberStart;
  int topRows, bottomRows;
  Map<String, String> marks;
  List<RowLink> links;
  List<int> runningRows;
  Gut({
    required this.no,
    this.area = '',
    this.crop = '',
    this.length = '',
    this.remark = '',
    this.rowDirection = 'उत्तर → दक्षिण',
    this.numberStart = 'पूर्व',
    this.topRows = 0,
    this.bottomRows = 0,
    Map<String, String>? marks,
    List<RowLink>? links,
    List<int>? runningRows,
  })  : marks = marks ?? {'उत्तर': '', 'दक्षिण': '', 'पूर्व': '', 'पश्चिम': ''},
        links = links ?? [],
        runningRows = runningRows ?? [];

  Map<String, dynamic> toJson() => {
        'no': no,
        'area': area,
        'crop': crop,
        'length': length,
        'remark': remark,
        'rowDirection': rowDirection,
        'numberStart': numberStart,
        'topRows': topRows,
        'bottomRows': bottomRows,
        'marks': marks,
        'links': links.map((e) => e.toJson()).toList(),
        'runningRows': runningRows,
      };

  factory Gut.fromJson(Map<String, dynamic> j) => Gut(
        no: '${j['no'] ?? ''}',
        area: '${j['area'] ?? ''}',
        crop: '${j['crop'] ?? ''}',
        length: '${j['length'] ?? ''}',
        remark: '${j['remark'] ?? ''}',
        rowDirection: '${j['rowDirection'] ?? 'उत्तर → दक्षिण'}',
        numberStart: '${j['numberStart'] ?? 'पूर्व'}',
        topRows: (j['topRows'] ?? 0) as int,
        bottomRows: (j['bottomRows'] ?? 0) as int,
        marks: Map<String, String>.from(j['marks'] ?? {}),
        links: (j['links'] as List? ?? []).map((e) => RowLink.fromJson(Map<String, dynamic>.from(e))).toList(),
        runningRows: List<int>.from(j['runningRows'] ?? []),
      );
}

class RowLink {
  int top;
  List<int> bottom;
  RowLink(this.top, this.bottom);
  Map<String, dynamic> toJson() => {'top': top, 'bottom': bottom};
  factory RowLink.fromJson(Map<String, dynamic> j) => RowLink((j['top'] ?? 0) as int, List<int>.from(j['bottom'] ?? []));
}

class AppStore extends ChangeNotifier {
  List<Gut> guts = [];
  String? activeGut;
  String source = 'मोठी नाली';
  bool loading = true;
  final List<String> sources = ['मोठी नाली', 'विहीर', 'बोअर', 'विहीर मोटर'];

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString('guts');
    if (raw != null && raw.isNotEmpty) {
      final list = jsonDecode(raw) as List;
      guts = list.map((e) => Gut.fromJson(Map<String, dynamic>.from(e))).toList();
    }
    activeGut = p.getString('activeGut');
    loading = false;
    notifyListeners();
  }

  Future<void> save() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('guts', jsonEncode(guts.map((e) => e.toJson()).toList()));
    if (activeGut != null) await p.setString('activeGut', activeGut!);
  }

  Gut? get active => guts.cast<Gut?>().firstWhere((g) => g?.no == activeGut, orElse: () => null);

  void select(String no) {
    activeGut = no;
    save();
    notifyListeners();
  }

  Future<void> upsert(Gut gut) async {
    final i = guts.indexWhere((g) => g.no == gut.no);
    if (i >= 0) guts[i] = gut; else guts.add(gut);
    activeGut = gut.no;
    await save();
    notifyListeners();
  }

  Future<void> remove(String no) async {
    guts.removeWhere((g) => g.no == no);
    if (activeGut == no) activeGut = guts.isEmpty ? null : guts.first.no;
    await save();
    notifyListeners();
  }
}

class AppShell extends StatefulWidget {
  const AppShell({super.key});
  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  final AppStore store = AppStore();
  int tab = 0;
  @override
  void initState() {
    super.initState();
    store.load();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        if (store.loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
        final pages = [
          Dashboard(store: store, onOpen: (i) => setState(() => tab = i)),
          PlotMappingPage(store: store),
          PlotViewPage(store: store),
          WaterPage(store: store),
        ];
        return Scaffold(
          body: pages[tab],
          bottomNavigationBar: NavigationBar(
            selectedIndex: tab,
            onDestinationSelected: (i) => setState(() => tab = i),
            destinations: const [
              NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'मुख्य'),
              NavigationDestination(icon: Icon(Icons.grid_view_outlined), selectedIcon: Icon(Icons.grid_view), label: 'Mapping'),
              NavigationDestination(icon: Icon(Icons.map_outlined), selectedIcon: Icon(Icons.map), label: 'Plot View'),
              NavigationDestination(icon: Icon(Icons.water_drop_outlined), selectedIcon: Icon(Icons.water_drop), label: 'पाणी'),
            ],
          ),
        );
      },
    );
  }
}

class Dashboard extends StatelessWidget {
  final AppStore store;
  final ValueChanged<int> onOpen;
  const Dashboard({super.key, required this.store, required this.onOpen});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('🌾 शेती • मुख्य मेनू'), centerTitle: false),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        _menuCard(context, 'GUT Update', 'GUT / क्षेत्रफळ / पीक / लांबी / दिशा / Land Mark', Icons.edit_note, () => _showGutForm(context, store)),
        _menuCard(context, 'Plot Mapping', 'सऱ्या, numbering, link आणि split mapping', Icons.grid_view, () => onOpen(1)),
        _menuCard(context, 'Plot Map View', 'प्रत्यक्ष GUT नकाशा + links + Land Marks', Icons.map, () => onOpen(2)),
        _menuCard(context, 'पाणी ON / OFF + Live Map', 'सरी निवडा आणि Live status बदला', Icons.water_drop, () => onOpen(3)),
        const SizedBox(height: 12),
        Card(child: Padding(padding: const EdgeInsets.all(16), child: Text('सध्याचे GUT: ${store.activeGut ?? 'निवडलेले नाही'}\nएकूण GUT: ${store.guts.length}', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)))),
      ]),
    );
  }

  Widget _menuCard(BuildContext context, String title, String sub, IconData icon, VoidCallback tap) => Card(
        child: InkWell(onTap: tap, borderRadius: BorderRadius.circular(16), child: Padding(padding: const EdgeInsets.all(18), child: Row(children: [
          CircleAvatar(radius: 26, child: Icon(icon)), const SizedBox(width: 16), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)), const SizedBox(height: 4), Text(sub)])), const Icon(Icons.chevron_right)
        ]))),
      );

  void _showGutForm(BuildContext context, AppStore store, {Gut? existing}) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => GutFormPage(store: store, existing: existing)));
  }
}

class GutFormPage extends StatefulWidget {
  final AppStore store;
  final Gut? existing;
  const GutFormPage({super.key, required this.store, this.existing});
  @override
  State<GutFormPage> createState() => _GutFormPageState();
}

class _GutFormPageState extends State<GutFormPage> {
  late final TextEditingController no, area, crop, length, remark;
  late String direction, numberStart;
  late final Map<String, TextEditingController> marks;
  @override
  void initState() {
    super.initState();
    final g = widget.existing;
    no = TextEditingController(text: g?.no ?? ''); area = TextEditingController(text: g?.area ?? ''); crop = TextEditingController(text: g?.crop ?? ''); length = TextEditingController(text: g?.length ?? ''); remark = TextEditingController(text: g?.remark ?? '');
    direction = g?.rowDirection ?? 'उत्तर → दक्षिण'; numberStart = g?.numberStart ?? 'पूर्व';
    final m = g?.marks ?? {};
    marks = {for (final d in ['उत्तर', 'दक्षिण', 'पूर्व', 'पश्चिम']) d: TextEditingController(text: m[d] ?? '')};
  }
  @override
  void dispose() { for (final c in [no, area, crop, length, remark, ...marks.values]) c.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(widget.existing == null ? 'नवीन GUT' : 'GUT Update')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      _field('GUT क्रमांक', no), _field('क्षेत्रफळ', area), _field('पीक', crop), _field('लांबी', length),
      _drop('सऱ्यांची दिशा (पाण्याची दिशा)', direction, ['उत्तर → दक्षिण','दक्षिण → उत्तर','पूर्व → पश्चिम','पश्चिम → पूर्व'], (v) => setState(() => direction = v!)),
      _drop('सऱ्यांची नंबरिंग सुरू होण्याची दिशा', numberStart, ['पूर्व','पश्चिम','उत्तर','दक्षिण'], (v) => setState(() => numberStart = v!)),
      const SizedBox(height: 10), const Text('चारही दिशांचे Land Mark', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      for (final d in ['उत्तर','दक्षिण','पूर्व','पश्चिम']) Padding(padding: const EdgeInsets.only(top: 10), child: TextField(controller: marks[d], decoration: InputDecoration(labelText: '$d Land Mark'))),
      const SizedBox(height: 10), _field('Remark', remark, maxLines: 2),
      FilledButton.icon(onPressed: _save, icon: const Icon(Icons.save), label: const Text('Save / Update')),
    ],),
  );
  Widget _field(String label, TextEditingController c, {int maxLines = 1}) => Padding(padding: const EdgeInsets.only(bottom: 10), child: TextField(controller: c, maxLines: maxLines, decoration: InputDecoration(labelText: label)));
  Widget _drop(String label, String value, List<String> items, ValueChanged<String?> onChanged) => Padding(padding: const EdgeInsets.only(bottom: 10), child: DropdownButtonFormField<String>(value: value, decoration: InputDecoration(labelText: label), items: items.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(), onChanged: onChanged));
  Future<void> _save() async {
    if (no.text.trim().isEmpty) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('GUT क्रमांक भरा'))); return; }
    final old = widget.existing;
    final g = Gut(no: no.text.trim(), area: area.text.trim(), crop: crop.text.trim(), length: length.text.trim(), remark: remark.text.trim(), rowDirection: direction, numberStart: numberStart, topRows: old?.topRows ?? 0, bottomRows: old?.bottomRows ?? 0, marks: {for (final e in marks.entries) e.key: e.value.text.trim()}, links: old?.links, runningRows: old?.runningRows);
    await widget.store.upsert(g);
    if (mounted) Navigator.pop(context);
  }
}

class PlotMappingPage extends StatefulWidget {
  final AppStore store;
  const PlotMappingPage({super.key, required this.store});
  @override
  State<PlotMappingPage> createState() => _PlotMappingPageState();
}

class _PlotMappingPageState extends State<PlotMappingPage> {
  Gut? get gut => widget.store.active;
  late TextEditingController top, bottom, firstTop, firstBottom, splitTop, splitA, splitB;
  @override
  void initState() { super.initState(); _makeControllers(); }
  void _makeControllers() { final g = gut; top = TextEditingController(text: '${g?.topRows ?? 37}'); bottom = TextEditingController(text: '${g?.bottomRows ?? 40}'); firstTop = TextEditingController(text: '1'); firstBottom = TextEditingController(text: '3'); splitTop = TextEditingController(text: '12'); splitA = TextEditingController(text: '15'); splitB = TextEditingController(text: '16'); }
  @override
  void dispose() { for (final c in [top,bottom,firstTop,firstBottom,splitTop,splitA,splitB]) c.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) {
    if (gut == null) return _empty();
    return Scaffold(appBar: AppBar(title: Text('Plot Mapping • GUT ${gut!.no}'), actions: [IconButton(onPressed: () => _selectGut(context), icon: const Icon(Icons.swap_horiz))]), body: ListView(padding: const EdgeInsets.all(14), children: [
      _info(), const SizedBox(height: 12),
      _numberSection(), const SizedBox(height: 12),
      _linkSection(), const SizedBox(height: 12),
      FilledButton.icon(onPressed: _saveMapping, icon: const Icon(Icons.save), label: const Text('Mapping Save / Update')),
    ]));
  }
  Widget _empty() => Scaffold(appBar: AppBar(title: const Text('Plot Mapping')), body: Center(child: FilledButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => GutFormPage(store: widget.store))), child: const Text('पहिले GUT तयार करा')));
  Widget _info() => Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('GUT ${gut!.no} • ${gut!.area} • ${gut!.crop}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)), Text('सरी दिशा: ${gut!.rowDirection} • नंबरिंग: ${gut!.numberStart}'), const SizedBox(height: 8), Text('उत्तर: ${gut!.marks['उत्तर']}  |  दक्षिण: ${gut!.marks['दक्षिण']}'), Text('पूर्व: ${gut!.marks['पूर्व']}  |  पश्चिम: ${gut!.marks['पश्चिम']}')]));
  Widget _numberSection() => Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('सऱ्यांची संख्या', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)), const SizedBox(height: 10), Row(children: [Expanded(child: TextField(controller: top, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'वरची बाजू सऱ्या'))), const SizedBox(width: 10), Expanded(child: TextField(controller: bottom, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'खालची बाजू सऱ्या')))]), const SizedBox(height: 10), const Text('उदा. 37 वर / 40 खाली: वर 1 → खाली 3. खाली 1-2 = Extra/No Link.')]));
  Widget _linkSection() => Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('Link Mapping', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)), const SizedBox(height: 10), Row(children: [Expanded(child: TextField(controller: firstTop, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'वरची सरी'))), const Padding(padding: EdgeInsets.symmetric(horizontal: 8), child: Text('→')), Expanded(child: TextField(controller: firstBottom, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'खालील सरी')))]), const SizedBox(height: 10), Row(children: [Expanded(child: TextField(controller: splitTop, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Split वरची सरी'))), const Padding(padding: EdgeInsets.symmetric(horizontal: 8), child: Text('→')), Expanded(child: TextField(controller: splitA, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'खाली A'))), const SizedBox(width: 6), Expanded(child: TextField(controller: splitB, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'खाली B')))]), const SizedBox(height: 10), const Text('Split नंतर पुढील links आपोआप shift होतील. उदा. 12→15,16; 13→17; 14→18; 37→40.')]));
  Future<void> _saveMapping() async {
    final g = gut!; g.topRows = int.tryParse(top.text) ?? 0; g.bottomRows = int.tryParse(bottom.text) ?? 0; g.links = [];
    final ft = int.tryParse(firstTop.text) ?? 1; final fb = int.tryParse(firstBottom.text) ?? 1; final st = int.tryParse(splitTop.text) ?? -1; final sa = int.tryParse(splitA.text) ?? -1; final sb = int.tryParse(splitB.text) ?? -1;
    for (int i = 1; i <= g.topRows; i++) { if (i == st) { g.links.add(RowLink(i, [sa, sb])); } else { final offset = i < st ? 0 : 1; final b = fb + (i - ft) + offset; if (b > 0 && b <= g.bottomRows) g.links.add(RowLink(i, [b])); } }
    await widget.store.save(); widget.store.notifyListeners();
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Plot Mapping Save झाले')));
  }
  Future<void> _selectGut(BuildContext context) async { final n = await showDialog<String>(context: context, builder: (_) => SimpleDialog(title: const Text('GUT निवडा'), children: widget.store.guts.map((g) => SimpleDialogOption(onPressed: () => Navigator.pop(context, g.no), child: Text('GUT ${g.no}'))).toList())); if (n != null) { widget.store.select(n); setState(_makeControllers); } }
}

class PlotViewPage extends StatelessWidget {
  final AppStore store;
  const PlotViewPage({super.key, required this.store});
  @override
  Widget build(BuildContext context) {
    final g = store.active;
    if (g == null) return Scaffold(appBar: AppBar(title: const Text('Plot View')), body: const Center(child: Text('पहिले GUT तयार करा')));
    final links = g.links;
    return Scaffold(appBar: AppBar(title: Text('🌾 गट नं. ${g.no} • ${g.area}')), body: ListView(padding: const EdgeInsets.all(14), children: [
      Card(child: Padding(padding: const EdgeInsets.all(14), child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(g.marks['उत्तर']?.isEmpty == true ? 'उत्तर' : g.marks['उत्तर']!, style: const TextStyle(fontWeight: FontWeight.bold)), Text('${g.length} फूट'), Text('${g.crop} • ${g.area}', style: const TextStyle(fontWeight: FontWeight.bold))]))),
      const SizedBox(height: 8),
      Text('वरची बाजू • ${g.topRows} सऱ्या', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      _rowStrip(g.topRows, reverse: false, running: g.runningRows),
      const SizedBox(height: 10),
      const Divider(thickness: 2),
      const SizedBox(height: 10),
      Text('खालची बाजू • ${g.bottomRows} सऱ्या', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      _rowStrip(g.bottomRows, reverse: true, running: g.runningRows),
      const SizedBox(height: 14),
      _mappingCard(g, links),
      const SizedBox(height: 10),
      _marksCard(g),
      const SizedBox(height: 10),
      Card(child: Padding(padding: const EdgeInsets.all(14), child: Text('सऱ्यांची दिशा: ${g.rowDirection}\n💧 पाण्याची दिशा: ${g.rowDirection}\nनंबरिंग सुरू: ${g.numberStart}', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)))),
    ]));
  }
  Widget _rowStrip(int count, {required bool reverse, required List<int> running}) {
    if (count <= 0) return const Text('Mapping बाकी');
    final nums = List<int>.generate(count, (i) => i + 1); final shown = reverse ? nums.reversed.toList() : nums;
    return SingleChildScrollView(scrollDirection: Axis.horizontal, child: Row(children: shown.map((n) { final active = running.contains(n); return Container(width: 48, margin: const EdgeInsets.only(right: 3, top: 6), child: Column(children: [Container(height: 24, alignment: Alignment.center, decoration: BoxDecoration(color: Colors.white, borderRadius: const BorderRadius.vertical(top: Radius.circular(5))), child: Text(n.toString().padLeft(2, '0'), style: const TextStyle(fontWeight: FontWeight.bold))), Container(height: 110, alignment: Alignment.center, color: active ? Colors.orange : Colors.green, child: RotatedBox(quarterTurns: 3, child: Text('${n == 0 ? '' : '550'} ft', style: const TextStyle(color: Colors.white, fontSize: 11)))), Container(height: 24, alignment: Alignment.center, color: Colors.white, child: Text(n.toString().padLeft(2, '0'), style: const TextStyle(fontWeight: FontWeight.bold))) ])); }).toList());
  }
  Widget _mappingCard(Gut g, List<RowLink> links) => Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('सरी Link / Split Link', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)), const SizedBox(height: 6), if (links.isEmpty) const Text('Mapping अजून Save केलेले नाही.') else ...links.take(50).map((l) => Padding(padding: const EdgeInsets.symmetric(vertical: 2), child: Text('वर ${l.top.toString().padLeft(2,'0')}  →  ${l.bottom.map((x) => x.toString().padLeft(2,'0')).join(', ')}', style: TextStyle(fontWeight: l.bottom.length > 1 ? FontWeight.bold : FontWeight.normal))))]));
  Widget _marksCard(Gut g) => Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('Land Marks', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)), Text('उत्तर: ${g.marks['उत्तर']}'), Text('दक्षिण: ${g.marks['दक्षिण']}'), Text('पूर्व: ${g.marks['पूर्व']}'), Text('पश्चिम: ${g.marks['पश्चिम']}')]));
}

class WaterPage extends StatefulWidget {
  final AppStore store;
  const WaterPage({super.key, required this.store});
  @override
  State<WaterPage> createState() => _WaterPageState();
}
class _WaterPageState extends State<WaterPage> {
  final Set<int> selected = {};
  @override
  Widget build(BuildContext context) {
    final g = widget.store.active;
    if (g == null) return Scaffold(appBar: AppBar(title: const Text('पाणी नियंत्रण')), body: const Center(child: Text('पहिले GUT तयार करा')));
    return Scaffold(appBar: AppBar(title: const Text('पाणी नियंत्रण ON / OFF')), body: ListView(padding: const EdgeInsets.all(14), children: [
      DropdownButtonFormField<String>(value: widget.store.source, decoration: const InputDecoration(labelText: 'पाणी स्रोत'), items: widget.store.sources.map((s) => DropdownMenuItem(value: s, child: Text(s))).toList(), onChanged: (v) { if (v != null) setState(() => widget.store.source = v); }),
      const SizedBox(height: 12),
      Text('GUT ${g.no} • ${g.crop}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      Wrap(spacing: 6, runSpacing: 6, children: List.generate(g.topRows, (i) { final n = i + 1; final on = g.runningRows.contains(n); return FilterChip(label: Text(n.toString().padLeft(2,'0')), selected: selected.contains(n), avatar: CircleAvatar(backgroundColor: on ? Colors.orange : Colors.green, radius: 7), onSelected: (v) => setState(() { if (v) selected.add(n); else selected.remove(n); })); })),
      const SizedBox(height: 16),
      Row(children: [Expanded(child: FilledButton.icon(onPressed: selected.isEmpty ? null : () async { g.runningRows = {...g.runningRows, ...selected}.toList()..sort(); await widget.store.save(); setState(() => selected.clear()); }, icon: const Icon(Icons.water_drop), label: const Text('पाणी ON'))), const SizedBox(width: 10), Expanded(child: FilledButton.tonalIcon(onPressed: selected.isEmpty ? null : () async { g.runningRows.removeWhere((x) => selected.contains(x)); await widget.store.save(); setState(() => selected.clear()); }, icon: const Icon(Icons.water_drop_outlined), label: const Text('पाणी OFF')))]),
      const SizedBox(height: 16),
      Card(child: Padding(padding: const EdgeInsets.all(14), child: Text('Live status: ${g.runningRows.length} सऱ्या चालू\nSource: ${widget.store.source}\nदिशा: ${g.rowDirection}', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)))),
      const SizedBox(height: 8),
      FilledButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PlotViewPage(store: widget.store))), icon: const Icon(Icons.map), label: const Text('Live Plot Map पाहा')),
    ]));
  }
}
