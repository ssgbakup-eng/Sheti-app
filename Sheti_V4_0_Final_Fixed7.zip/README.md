# Sheti App V4.0.3 Final Fixed7

Base: Sheti_V4_0_Final_Fixed6.zip

Final changes:
- Existing app identity retained: applicationId com.example.sheti_app.
- Version raised to 4.0.3+9 for upgrade eligibility.
- Plot references: two reference numbers on each plot side; no numbering in the middle.
- Top side and bottom side each show forward and reverse reference strips.
- Each sari is a separate box-type strip.
- Plot changed from 3D-style to a simple four-side land-mark-based farm map.
- North, South, East and West land marks are shown around the map.
- Continuous plot without a middle break.
- Existing update/save flow, saved map in GUT Update, water/live map, pending red rows, running yellow rows retained.
