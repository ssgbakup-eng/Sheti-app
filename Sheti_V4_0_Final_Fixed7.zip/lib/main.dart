import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const ShetiApp());

class ShetiApp extends StatelessWidget {
  const ShetiApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'शेती',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.green,
        scaffoldBackgroundColor: const Color(0xFFF7FAF3),
        inputDecorationTheme: const InputDecorationTheme(border: OutlineInputBorder()),
      ),
      home: const AppShell(),
    );
  }
}

class Gut {
  String no, area, crop, length, remark;
  String rowDirection, numberStart;
  int topRows, bottomRows;
  Map<String, String> marks;
  List<RowLink> links;
  List<int> runningRows;

  Gut({
    required this.no,
    this.area = '',
    this.crop = '',
    this.length = '',
    this.remark = '',
    this.rowDirection = 'उत्तर → दक्षिण',
    this.numberStart = 'पूर्व',
    this.topRows = 0,
    this.bottomRows = 0,
    Map<String, String>? marks,
    List<RowLink>? links,
    List<int>? runningRows,
  })  : marks = marks ?? {'उत्तर': '', 'दक्षिण': '', 'पूर्व': '', 'पश्चिम': ''},
        links = links ?? [],
        runningRows = runningRows ?? [];

  Map<String, dynamic> toJson() => {
        'no': no,
        'area': area,
        'crop': crop,
        'length': length,
        'remark': remark,
        'rowDirection': rowDirection,
        'numberStart': numberStart,
        'topRows': topRows,
        'bottomRows': bottomRows,
        'marks': marks,
        'links': links.map((e) => e.toJson()).toList(),
        'runningRows': runningRows,
      };

  factory Gut.fromJson(Map<String, dynamic> j) => Gut(
        no: '${j['no'] ?? ''}',
        area: '${j['area'] ?? ''}',
        crop: '${j['crop'] ?? ''}',
        length: '${j['length'] ?? ''}',
        remark: '${j['remark'] ?? ''}',
        rowDirection: '${j['rowDirection'] ?? 'उत्तर → दक्षिण'}',
        numberStart: '${j['numberStart'] ?? 'पूर्व'}',
        topRows: int.tryParse('${j['topRows'] ?? 0}') ?? 0,
        bottomRows: int.tryParse('${j['bottomRows'] ?? 0}') ?? 0,
        marks: Map<String, String>.from(j['marks'] ?? const {}),
        links: (j['links'] as List? ?? const [])
            .map((e) => RowLink.fromJson(Map<String, dynamic>.from(e)))
            .toList(),
        runningRows: List<int>.from(j['runningRows'] ?? const []),
      );
}

class RowLink {
  int top;
  List<int> bottom;
  RowLink(this.top, this.bottom);
  Map<String, dynamic> toJson() => {'top': top, 'bottom': bottom};
  factory RowLink.fromJson(Map<String, dynamic> j) => RowLink(
        int.tryParse('${j['top'] ?? 0}') ?? 0,
        List<int>.from(j['bottom'] ?? const []),
      );
}

class AppStore extends ChangeNotifier {
  List<Gut> guts = [];
  String? activeGut;
  String source = 'मोठी नाली';
  bool loading = true;
  final List<String> sources = ['मोठी नाली', 'विहीर', 'बोअर', 'विहीर मोटर'];

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString('guts');
    if (raw != null && raw.isNotEmpty) {
      final decoded = jsonDecode(raw) as List;
      guts = decoded.map((e) => Gut.fromJson(Map<String, dynamic>.from(e))).toList();
    }
    activeGut = p.getString('activeGut');
    if (activeGut == null && guts.isNotEmpty) activeGut = guts.first.no;
    loading = false;
    notifyListeners();
  }

  Future<void> save() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('guts', jsonEncode(guts.map((e) => e.toJson()).toList()));
    if (activeGut != null) {
      await p.setString('activeGut', activeGut!);
    } else {
      await p.remove('activeGut');
    }
  }

  Gut? get active {
    for (final g in guts) {
      if (g.no == activeGut) return g;
    }
    return null;
  }

  void select(String no) {
    activeGut = no;
    save();
    notifyListeners();
  }

  Future<void> upsert(Gut gut) async {
    final i = guts.indexWhere((g) => g.no == gut.no);
    if (i >= 0) {
      guts[i] = gut;
    } else {
      guts.add(gut);
    }
    activeGut = gut.no;
    await save();
    notifyListeners();
  }

  Future<void> remove(String no) async {
    guts.removeWhere((g) => g.no == no);
    if (activeGut == no) activeGut = guts.isEmpty ? null : guts.first.no;
    await save();
    notifyListeners();
  }
}

class AppShell extends StatefulWidget {
  const AppShell({super.key});
  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  final AppStore store = AppStore();
  int tab = 0;

  @override
  void initState() {
    super.initState();
    store.load();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        if (store.loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
        final pages = [
          Dashboard(store: store, onOpen: (i) => setState(() => tab = i)),
          PlotMappingPage(store: store),
          PlotViewPage(store: store),
          WaterPage(store: store),
        ];
        return Scaffold(
          body: pages[tab],
          bottomNavigationBar: NavigationBar(
            selectedIndex: tab,
            onDestinationSelected: (i) => setState(() => tab = i),
            destinations: const [
              NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'मुख्य'),
              NavigationDestination(icon: Icon(Icons.grid_view_outlined), selectedIcon: Icon(Icons.grid_view), label: 'Mapping'),
              NavigationDestination(icon: Icon(Icons.map_outlined), selectedIcon: Icon(Icons.map), label: 'Plot View'),
              NavigationDestination(icon: Icon(Icons.water_drop_outlined), selectedIcon: Icon(Icons.water_drop), label: 'पाणी'),
            ],
          ),
        );
      },
    );
  }
}

class Dashboard extends StatelessWidget {
  final AppStore store;
  final ValueChanged<int> onOpen;
  const Dashboard({super.key, required this.store, required this.onOpen});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('🌾 शेती • मुख्य मेनू')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        _menuCard(context, 'GUT Update', 'Saved GUT आणि त्याचा Plot Map पाहा / Update करा', Icons.edit_note,
            () => Navigator.push(context, MaterialPageRoute(builder: (_) => GutUpdatePage(store: store)))),
        _menuCard(context, 'Plot Mapping', 'सऱ्या, numbering, link आणि split mapping', Icons.grid_view, () => onOpen(1)),
        _menuCard(context, 'Plot Map View', 'प्रत्यक्ष GUT नकाशा + सऱ्या + बांध + References', Icons.map, () => onOpen(2)),
        _menuCard(context, 'पाणी ON / OFF + Live Map', 'सरी निवडा आणि Live status बदला', Icons.water_drop, () => onOpen(3)),
        const SizedBox(height: 12),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Text('सध्याचे GUT: ${store.activeGut ?? 'निवडलेले नाही'}\nएकूण GUT: ${store.guts.length}',
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
          ),
        ),
      ]),
    );
  }

  Widget _menuCard(BuildContext context, String title, String sub, IconData icon, VoidCallback tap) => Card(
        child: InkWell(
          onTap: tap,
          borderRadius: BorderRadius.circular(16),
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Row(children: [
              CircleAvatar(radius: 26, child: Icon(icon)),
              const SizedBox(width: 16),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 4),
                Text(sub),
              ])),
              const Icon(Icons.chevron_right),
            ]),
          ),
        ),
      );
}

class GutUpdatePage extends StatelessWidget {
  final AppStore store;
  const GutUpdatePage({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('GUT Update')),
      body: store.guts.isEmpty
          ? Center(child: FilledButton.icon(onPressed: () => _openForm(context), icon: const Icon(Icons.add), label: const Text('नवीन GUT तयार करा')))
          : ListView(padding: const EdgeInsets.all(12), children: [
              FilledButton.icon(onPressed: () => _openForm(context), icon: const Icon(Icons.add), label: const Text('नवीन GUT')),
              const SizedBox(height: 10),
              ...store.guts.map((g) => Card(
                    child: ExpansionTile(
                      initiallyExpanded: g.no == store.activeGut,
                      title: Text('GUT ${g.no}', style: const TextStyle(fontWeight: FontWeight.bold)),
                      subtitle: Text('${g.crop} • ${g.area} • ${g.length}'),
                      onExpansionChanged: (v) {
                        if (v) store.select(g.no);
                      },
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(10),
                          child: Column(children: [
                            PlotMapPreview(gut: g, compact: true),
                            const SizedBox(height: 10),
                            Row(children: [
                              Expanded(child: FilledButton.icon(onPressed: () => _openForm(context, g), icon: const Icon(Icons.edit), label: const Text('Update'))),
                              const SizedBox(width: 8),
                              IconButton(onPressed: () => _delete(context, g), icon: const Icon(Icons.delete_outline)),
                            ]),
                          ]),
                        ),
                      ],
                    ),
                  )),
            ]),
    );
  }

  void _openForm(BuildContext context, [Gut? g]) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => GutFormPage(store: store, existing: g)));
  }

  Future<void> _delete(BuildContext context, Gut g) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('GUT Delete'),
        content: Text('GUT ${g.no} हटवायचा आहे का?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('नाही')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('होय')),
        ],
      ),
    );
    if (ok == true) await store.remove(g.no);
  }
}

class GutFormPage extends StatefulWidget {
  final AppStore store;
  final Gut? existing;
  const GutFormPage({super.key, required this.store, this.existing});
  @override
  State<GutFormPage> createState() => _GutFormPageState();
}

class _GutFormPageState extends State<GutFormPage> {
  late final TextEditingController no, area, crop, length, remark;
  late String direction, numberStart;
  late final Map<String, TextEditingController> marks;

  @override
  void initState() {
    super.initState();
    final g = widget.existing;
    no = TextEditingController(text: g?.no ?? '');
    area = TextEditingController(text: g?.area ?? '');
    crop = TextEditingController(text: g?.crop ?? '');
    length = TextEditingController(text: g?.length ?? '');
    remark = TextEditingController(text: g?.remark ?? '');
    direction = g?.rowDirection ?? 'उत्तर → दक्षिण';
    numberStart = g?.numberStart ?? 'पूर्व';
    final m = g?.marks ?? {};
    marks = {for (final d in ['उत्तर', 'दक्षिण', 'पूर्व', 'पश्चिम']) d: TextEditingController(text: m[d] ?? '')};
  }

  @override
  void dispose() {
    for (final c in [no, area, crop, length, remark, ...marks.values]) c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.existing == null ? 'नवीन GUT' : 'GUT Update')),
      body: ListView(padding: const EdgeInsets.fromLTRB(16, 16, 16, 110), children: [
        _field('GUT क्रमांक', no),
        _field('क्षेत्रफळ', area),
        _field('पीक', crop),
        _field('लांबी', length),
        _drop('सऱ्यांची दिशा (पाण्याची दिशा)', direction, ['उत्तर → दक्षिण', 'दक्षिण → उत्तर', 'पूर्व → पश्चिम', 'पश्चिम → पूर्व'], (v) => setState(() => direction = v!)),
        _drop('सऱ्यांची नंबरिंग सुरू होण्याची दिशा', numberStart, ['पूर्व', 'पश्चिम', 'उत्तर', 'दक्षिण'], (v) => setState(() => numberStart = v!)),
        const SizedBox(height: 8),
        const Text('चारही दिशांचे Land Mark', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        for (final d in ['उत्तर', 'दक्षिण', 'पूर्व', 'पश्चिम'])
          Padding(padding: const EdgeInsets.only(top: 10), child: TextField(controller: marks[d], decoration: InputDecoration(labelText: '$d Land Mark'))),
        const SizedBox(height: 10),
        _field('Remark', remark, maxLines: 2),
        if (widget.existing != null && widget.existing!.topRows > 0) ...[
          const SizedBox(height: 8),
          const Text('सेव्ह केलेला Plot Map', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          PlotMapPreview(gut: widget.existing!, compact: true),
        ],
      ]),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: FilledButton.icon(onPressed: _save, icon: const Icon(Icons.save), label: Text(widget.existing == null ? 'Save GUT' : 'Update GUT')),
        ),
      ),
    );
  }

  Widget _field(String label, TextEditingController c, {int maxLines = 1}) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: TextField(controller: c, maxLines: maxLines, decoration: InputDecoration(labelText: label)),
      );

  Widget _drop(String label, String value, List<String> items, ValueChanged<String?> onChanged) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: DropdownButtonFormField<String>(
          value: value,
          decoration: InputDecoration(labelText: label),
          items: items.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
          onChanged: onChanged,
        ),
      );

  Future<void> _save() async {
    final gutNo = no.text.trim();
    if (gutNo.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('GUT क्रमांक भरा')));
      return;
    }
    final old = widget.existing;
    if (old == null && widget.store.guts.any((g) => g.no == gutNo)) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('हा GUT क्रमांक आधीच आहे')));
      return;
    }
    final g = Gut(
      no: gutNo,
      area: area.text.trim(),
      crop: crop.text.trim(),
      length: length.text.trim(),
      remark: remark.text.trim(),
      rowDirection: direction,
      numberStart: numberStart,
      topRows: old?.topRows ?? 0,
      bottomRows: old?.bottomRows ?? 0,
      marks: {for (final e in marks.entries) e.key: e.value.text.trim()},
      links: old?.links,
      runningRows: old?.runningRows,
    );
    await widget.store.upsert(g);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('GUT Update सेव्ह झाला')));
      Navigator.pop(context);
    }
  }
}

class PlotMappingPage extends StatefulWidget {
  final AppStore store;
  const PlotMappingPage({super.key, required this.store});
  @override
  State<PlotMappingPage> createState() => _PlotMappingPageState();
}

class _PlotMappingPageState extends State<PlotMappingPage> {
  Gut? get gut => widget.store.active;
  late TextEditingController top, bottom, firstTop, firstBottom, splitTop, splitA, splitB;
  String? loadedNo;

  @override
  void initState() {
    super.initState();
    _makeControllers();
  }

  void _makeControllers() {
    final g = gut;
    for (final c in _controllers) c.dispose();
    top = TextEditingController(text: '${g?.topRows == 0 ? 37 : g?.topRows}');
    bottom = TextEditingController(text: '${g?.bottomRows == 0 ? 40 : g?.bottomRows}');
    firstTop = TextEditingController(text: '1');
    firstBottom = TextEditingController(text: '3');
    splitTop = TextEditingController(text: '12');
    splitA = TextEditingController(text: '15');
    splitB = TextEditingController(text: '16');
    loadedNo = g?.no;
  }

  List<TextEditingController> get _controllers => [
        if (loadedNo != null) top,
        if (loadedNo != null) bottom,
        if (loadedNo != null) firstTop,
        if (loadedNo != null) firstBottom,
        if (loadedNo != null) splitTop,
        if (loadedNo != null) splitA,
        if (loadedNo != null) splitB,
      ];

  @override
  void dispose() {
    for (final c in _controllers) c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final g = gut;
    if (g == null) return _empty();
    if (loadedNo != g.no) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted && loadedNo != widget.store.activeGut) setState(_makeControllers);
      });
    }
    return Scaffold(
      appBar: AppBar(title: Text('Plot Mapping • GUT ${g.no}'), actions: [IconButton(onPressed: () => _selectGut(context), icon: const Icon(Icons.swap_horiz))]),
      body: ListView(padding: const EdgeInsets.fromLTRB(14, 14, 14, 120), children: [
        _info(g),
        const SizedBox(height: 12),
        _numberSection(),
        const SizedBox(height: 12),
        _linkSection(),
        const SizedBox(height: 12),
        const Text('Plot Layout Preview', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        PlotMapPreview(gut: g, compact: true),
      ]),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: FilledButton.icon(onPressed: _saveMapping, icon: const Icon(Icons.save), label: const Text('Plot Update / Save')),
        ),
      ),
    );
  }

  Widget _empty() => Scaffold(
        appBar: AppBar(title: const Text('Plot Mapping')),
        body: Center(child: FilledButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => GutFormPage(store: widget.store))), child: const Text('पहिले GUT तयार करा'))),
      );

  Widget _info(Gut g) => Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('GUT ${g.no} • ${g.area} • ${g.crop}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            Text('सरी दिशा: ${g.rowDirection} • नंबरिंग: ${g.numberStart}'),
            Text('उत्तर: ${g.marks['उत्तर']} | दक्षिण: ${g.marks['दक्षिण']}'),
            Text('पूर्व: ${g.marks['पूर्व']} | पश्चिम: ${g.marks['पश्चिम']}'),
          ]),
        ),
      );

  Widget _numberSection() => Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('सऱ्यांची संख्या', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(child: TextField(controller: top, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'वरची बाजू सऱ्या'))),
              const SizedBox(width: 10),
              Expanded(child: TextField(controller: bottom, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'खालची बाजू सऱ्या'))),
            ]),
            const SizedBox(height: 10),
            const Text('उदा. 37 वर / 40 खाली: वर 1 → खाली 3. खाली 1-2 = Extra/No Link.'),
          ]),
        ),
      );

  Widget _linkSection() => Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Link Mapping', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(child: TextField(controller: firstTop, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'वरची सरी'))),
              const Padding(padding: EdgeInsets.symmetric(horizontal: 8), child: Text('→')),
              Expanded(child: TextField(controller: firstBottom, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'खालील सरी'))),
            ]),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(child: TextField(controller: splitTop, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Split वरची सरी'))),
              const Padding(padding: EdgeInsets.symmetric(horizontal: 8), child: Text('→')),
              Expanded(child: TextField(controller: splitA, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'खाली A'))),
              const SizedBox(width: 6),
              Expanded(child: TextField(controller: splitB, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'खाली B'))),
            ]),
            const SizedBox(height: 10),
            const Text('Split नंतर पुढील links shift होतील. उदा. 12→15,16; 13→17; 14→18; 37→40.'),
          ]),
        ),
      );

  Future<void> _saveMapping() async {
    final g = gut;
    if (g == null) return;
    final tr = int.tryParse(top.text.trim()) ?? 0;
    final br = int.tryParse(bottom.text.trim()) ?? 0;
    if (tr <= 0 || br <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('सऱ्यांची संख्या भरा')));
      return;
    }
    final ft = int.tryParse(firstTop.text.trim()) ?? 1;
    final fb = int.tryParse(firstBottom.text.trim()) ?? 1;
    final st = int.tryParse(splitTop.text.trim()) ?? -1;
    final sa = int.tryParse(splitA.text.trim()) ?? -1;
    final sb = int.tryParse(splitB.text.trim()) ?? -1;
    final links = <RowLink>[];
    for (int i = 1; i <= tr; i++) {
      if (i == st && sa > 0 && sb > 0) {
        links.add(RowLink(i, [sa, sb]));
      } else {
        final offset = i > st ? 1 : 0;
        final b = fb + (i - ft) + offset;
        if (b > 0 && b <= br) links.add(RowLink(i, [b]));
      }
    }
    g.topRows = tr;
    g.bottomRows = br;
    g.links = links;
    await widget.store.save();
    widget.store.notifyListeners();
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Plot Update सेव्ह झाला')));
  }

  Future<void> _selectGut(BuildContext context) async {
    final n = await showDialog<String>(
      context: context,
      builder: (_) => SimpleDialog(
        title: const Text('GUT निवडा'),
        children: widget.store.guts.map((g) => SimpleDialogOption(onPressed: () => Navigator.pop(context, g.no), child: Text('GUT ${g.no}'))).toList(),
      ),
    );
    if (n != null) {
      widget.store.select(n);
      if (mounted) setState(_makeControllers);
    }
  }
}

class PlotViewPage extends StatelessWidget {
  final AppStore store;
  const PlotViewPage({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    final g = store.active;
    if (g == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Plot View')),
        body: const Center(child: Text('पहिले GUT तयार करा')),
      );
    }
    return Scaffold(
      appBar: AppBar(
        title: Text('🌾 GUT ${g.no} • Plot Map'),
        actions: [
          IconButton(
            tooltip: 'नकाशा मोठा/लहान',
            onPressed: () {},
            icon: const Icon(Icons.zoom_in),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(8),
        child: PlotMapPreview(gut: g, compact: false, interactive: true),
      ),
    );
  }
}

class PlotMapPreview extends StatelessWidget {
  final Gut gut;
  final bool compact;
  final bool interactive;
  const PlotMapPreview({super.key, required this.gut, this.compact = false, this.interactive = false});

  static String ref(int n) => n.toString().padLeft(2, '0');

  @override
  Widget build(BuildContext context) {
    final topCount = gut.topRows;
    final bottomCount = gut.bottomRows;
    final count = topCount > bottomCount ? topCount : bottomCount;
    if (count <= 0) {
      return const Card(
        child: Padding(
          padding: EdgeInsets.all(14),
          child: Text('Plot Mapping अजून सेव्ह केलेले नाही.'),
        ),
      );
    }

    final cellW = compact ? 58.0 : 72.0;
    final plotW = count * cellW + 280;
    final plotH = compact ? 280.0 : 520.0;

    Widget map = SizedBox(
      width: plotW,
      height: plotH,
      child: CustomPaint(
        painter: PlotPainter(gut: gut, cellW: cellW, count: count, ref: ref),
      ),
    );

    if (interactive) {
      map = InteractiveViewer(
        minScale: 0.55,
        maxScale: 3.5,
        scaleEnabled: true,
        panEnabled: true,
        constrained: false,
        boundaryMargin: const EdgeInsets.all(120),
        child: map,
      );
    }

    return Card(
      clipBehavior: Clip.antiAlias,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 10, 10, 4),
            child: Row(
              children: [
                const Icon(Icons.threed_rotation, size: 22),
                const SizedBox(width: 6),
                const Text('Actual 3D Plot Map', style: TextStyle(fontWeight: FontWeight.bold)),
                const Spacer(),
                if (!compact) const Text('Pinch = Zoom • Drag = Map', style: TextStyle(fontSize: 12)),
              ],
            ),
          ),
          SizedBox(
            height: compact ? plotH : 540,
            width: double.infinity,
            child: interactive ? map : SingleChildScrollView(scrollDirection: Axis.horizontal, child: map),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 4, 10, 10),
            child: Wrap(
              spacing: 12,
              runSpacing: 5,
              children: [
                Text('उत्तर: ${gut.marks['उत्तर'] ?? ''}'),
                Text('दक्षिण: ${gut.marks['दक्षिण'] ?? ''}'),
                Text('पूर्व: ${gut.marks['पूर्व'] ?? ''}'),
                Text('पश्चिम: ${gut.marks['पश्चिम'] ?? ''}'),
                Text('सरी दिशा: ${gut.rowDirection}'),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class PlotPainter extends CustomPainter {
  final Gut gut;
  final double cellW;
  final int count;
  final String Function(int) ref;
  PlotPainter({required this.gut, required this.cellW, required this.count, required this.ref});

  @override
  void paint(Canvas canvas, Size size) {
    // Simple, continuous farm-map layout. The plot itself never has a middle break.
    const left = 150.0;
    const top = 105.0;
    const bottom = 365.0;
    final right = left + count * cellW;

    final border = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3
      ..color = Colors.brown.shade800;
    final bund = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 7
      ..color = Colors.brown.shade700;
    final completed = Paint()
      ..style = PaintingStyle.fill
      ..color = Colors.green.shade100;
    final pending = Paint()
      ..style = PaintingStyle.fill
      ..color = Colors.red.shade200;
    final running = Paint()
      ..style = PaintingStyle.fill
      ..color = Colors.amber.shade300;
    final rowBorder = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2
      ..color = Colors.green.shade900;

    // Land marks and side labels.
    _text(canvas, 'उत्तर', Offset(left + (right - left) / 2 - 20, 8), 16, Colors.black, bold: true);
    _text(canvas, 'उत्तर • ${gut.marks['उत्तर'] ?? ''}', Offset(left + 4, 34), 13, Colors.black87, bold: true);
    _text(canvas, 'दक्षिण • ${gut.marks['दक्षिण'] ?? ''}', Offset(left + 4, 438), 13, Colors.black87, bold: true);
    _text(canvas, 'पश्चिम • ${gut.marks['पश्चिम'] ?? ''}', Offset(8, top + 105), 13, Colors.black87, bold: true);
    _text(canvas, 'पूर्व • ${gut.marks['पूर्व'] ?? ''}', Offset(right + 10, top + 105), 13, Colors.black87, bold: true);

    // Road / bund and drain / bund markers.
    canvas.drawLine(Offset(left, top - 12), Offset(right, top - 12), bund);
    canvas.drawLine(Offset(left, bottom + 12), Offset(right, bottom + 12), bund);
    _text(canvas, 'रस्ता / बांध', Offset(10, top - 20), 13, Colors.brown.shade900, bold: true);
    _text(canvas, 'नाली / बांध', Offset(10, bottom + 4), 13, Colors.brown.shade900, bold: true);

    // Two reference rows on BOTH sides. Nothing is written in the plot middle.
    for (int i = 0; i < count; i++) {
      final x1 = left + i * cellW;
      final x2 = x1 + cellW;
      final topN = i < gut.topRows ? i + 1 : null;
      final bottomN = i < gut.bottomRows ? i + 1 : null;
      final topOpp = topN == null ? null : gut.topRows - topN + 1;
      final bottomOpp = bottomN == null ? null : gut.bottomRows - bottomN + 1;

      if (topN != null) {
        _text(canvas, ref(topN), Offset(x1 + 4, 61), 12, Colors.black, bold: true);
        _text(canvas, ref(topOpp!), Offset(x1 + 4, 80), 11, Colors.blue.shade900, bold: true);
      }
      if (bottomN != null) {
        _text(canvas, ref(bottomN), Offset(x1 + 4, bottom + 18), 12, Colors.black, bold: true);
        _text(canvas, ref(bottomOpp!), Offset(x1 + 4, bottom + 37), 11, Colors.blue.shade900, bold: true);
      }

      final fill = (topN != null && gut.runningRows.contains(topN)) ? running :
          (topN != null ? pending : completed);
      final rect = Rect.fromLTRB(x1, top, x2, bottom);
      canvas.drawRect(rect, fill);
      canvas.drawRect(rect, rowBorder);

      // A light center divider visually shows each sari without adding numbering.
      if (i > 0) {
        final divider = Paint()
          ..color = Colors.green.shade700
          ..strokeWidth = 1;
        canvas.drawLine(Offset(x1, top), Offset(x1, bottom), divider);
      }

      // Mapping links are drawn along the side of the plot, never through the center labels.
      if (topN != null) {
        for (final bn in _bottomLinks(topN)) {
          if (bn >= 1 && bn <= gut.bottomRows) {
            final bi = bn - 1;
            final bx = left + bi * cellW + cellW / 2;
            final link = Paint()
              ..style = PaintingStyle.stroke
              ..strokeWidth = 1.5
              ..color = Colors.blue.shade400.withOpacity(0.65);
            canvas.drawLine(Offset(x1 + cellW / 2, bottom - 2), Offset(bx, bottom + 10), link);
          }
        }
      }
    }

    // Plot outline and direction marker.
    canvas.drawRect(Rect.fromLTRB(left, top, right, bottom), border);
    _text(canvas, '↑ N', Offset(right + 12, 60), 16, Colors.blue.shade800, bold: true);
    _text(canvas, 'पाण्याची दिशा: ${gut.rowDirection}', Offset(right + 8, bottom - 5), 12, Colors.blue.shade800, bold: true);

    // Legend: remaining/pending rows are red.
    final ly = 480.0;
    _legend(canvas, Offset(left, ly), Colors.red.shade200, 'बाकी');
    _legend(canvas, Offset(left + 80, ly), Colors.amber.shade300, 'पाणी सुरू');
    _legend(canvas, Offset(left + 190, ly), Colors.green.shade100, 'पूर्ण / बंद');
    _legend(canvas, Offset(left + 315, ly), Colors.brown.shade700, 'बांध');
    _text(canvas, 'सरी बॉक्स', Offset(left + 415, ly - 2), 12, Colors.green.shade900, bold: true);
  }

  List<int> _bottomLinks(int top) {
    for (final l in gut.links) {
      if (l.top == top) return l.bottom;
    }
    if (top <= gut.bottomRows) return [top];
    return [];
  }

  void _legend(Canvas canvas, Offset o, Color c, String label) {
    final p = Paint()..color = c;
    canvas.drawRect(Rect.fromLTWH(o.dx, o.dy, 20, 14), p);
    _text(canvas, label, Offset(o.dx + 25, o.dy - 2), 12, Colors.black87);
  }

  void _text(Canvas canvas, String value, Offset offset, double size, Color color, {bool bold = false}) {
    final tp = TextPainter(
      text: TextSpan(
        text: value,
        style: TextStyle(fontSize: size, color: color, fontWeight: bold ? FontWeight.bold : FontWeight.normal),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    tp.paint(canvas, offset);
  }

  @override
  bool shouldRepaint(covariant PlotPainter oldDelegate) => true;
}

class WaterPage extends StatefulWidget {
  final AppStore store;
  const WaterPage({super.key, required this.store});
  @override
  State<WaterPage> createState() => _WaterPageState();
}

class _WaterPageState extends State<WaterPage> {
  final Set<int> selected = {};

  @override
  Widget build(BuildContext context) {
    final g = widget.store.active;
    if (g == null) return Scaffold(appBar: AppBar(title: const Text('पाणी नियंत्रण')), body: const Center(child: Text('पहिले GUT तयार करा')));
    return Scaffold(
      appBar: AppBar(title: const Text('पाणी नियंत्रण ON / OFF')),
      body: ListView(padding: const EdgeInsets.fromLTRB(14, 14, 14, 110), children: [
        DropdownButtonFormField<String>(
          value: widget.store.source,
          decoration: const InputDecoration(labelText: 'पाणी स्रोत'),
          items: widget.store.sources.map((s) => DropdownMenuItem(value: s, child: Text(s))).toList(),
          onChanged: (v) => setState(() => widget.store.source = v ?? widget.store.source),
        ),
        const SizedBox(height: 12),
        Text('GUT ${g.no} • ${g.crop}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Wrap(
          spacing: 6,
          runSpacing: 6,
          children: List.generate(g.topRows, (i) {
            final n = i + 1;
            final on = g.runningRows.contains(n);
            return FilterChip(
              label: Text(n.toString().padLeft(2, '0')),
              selected: selected.contains(n),
              avatar: CircleAvatar(backgroundColor: on ? Colors.orange : Colors.green, radius: 7),
              onSelected: (v) => setState(() => v ? selected.add(n) : selected.remove(n)),
            );
          }),
        ),
        const SizedBox(height: 16),
        Row(children: [
          Expanded(child: FilledButton.icon(onPressed: selected.isEmpty ? null : _waterOn, icon: const Icon(Icons.water_drop), label: const Text('पाणी ON'))),
          const SizedBox(width: 10),
          Expanded(child: FilledButton.tonalIcon(onPressed: selected.isEmpty ? null : _waterOff, icon: const Icon(Icons.water_drop_outlined), label: const Text('पाणी OFF'))),
        ]),
        const SizedBox(height: 16),
        Card(child: Padding(padding: const EdgeInsets.all(14), child: Text('🟢 बंद / पूर्ण\n🟡 सध्या पाणी सुरू: ${g.runningRows.length} सऱ्या\n🔴 बाकी सऱ्या\nSource: ${widget.store.source}\nदिशा: ${g.rowDirection}', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)))),
        const SizedBox(height: 8),
        FilledButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PlotViewPage(store: widget.store))), icon: const Icon(Icons.map), label: const Text('Live Plot Map पाहा')),
      ]),
    );
  }

  Future<void> _waterOn() async {
    final g = widget.store.active;
    if (g == null) return;
    g.runningRows = {...g.runningRows, ...selected}.toList()..sort();
    await widget.store.save();
    widget.store.notifyListeners();
    if (mounted) setState(() => selected.clear());
  }

  Future<void> _waterOff() async {
    final g = widget.store.active;
    if (g == null) return;
    g.runningRows.removeWhere(selected.contains);
    await widget.store.save();
    widget.store.notifyListeners();
    if (mounted) setState(() => selected.clear());
  }
}
