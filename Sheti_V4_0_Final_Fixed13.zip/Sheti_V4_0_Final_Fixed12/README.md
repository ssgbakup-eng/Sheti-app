Sheti V4.0.4 Fixed13

Changes:
1. Row marker entry: row number + marker type (लिंब/खांबा/कॉक/सरी) + direction (उत्तर/दक्षिण/पूर्व/पश्चिम).
2. Plot Map displays a distinct marker symbol and direction arrow on the selected row.
3. East is the default Base numbering side; existing mapping data is retained.
4. Android versionCode 10 / versionName 4.0.4.
5. applicationId remains com.example.sheti_app and release signing configuration remains externalized in signing/key.properties.

IMPORTANT: The actual release JKS signing key must be supplied to the build environment. The key.properties file alone does not contain the JKS key.
