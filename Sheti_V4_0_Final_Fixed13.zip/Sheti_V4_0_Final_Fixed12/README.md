Sheti V4.0 Final Fixed13

Based on Fixed12. Compile correction only: markerDirection undefined reference removed/avoided. No design changes.
