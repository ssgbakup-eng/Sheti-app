import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:pdf/pdf.dart' as pwpdf;
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

void main() => runApp(const ShetiApp());

class ShetiApp extends StatelessWidget {
  const ShetiApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'शेती',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.green,
        scaffoldBackgroundColor: const Color(0xFFF7FAF3),
        inputDecorationTheme: const InputDecorationTheme(border: OutlineInputBorder()),
      ),
      home: const AppShell(),
    );
  }
}

class WaterEvent {
  String dateTime;
  int row;
  String action;
  String source;

  WaterEvent({
    required this.dateTime,
    required this.row,
    required this.action,
    required this.source,
  });

  Map<String, dynamic> toJson() => {
        'dateTime': dateTime,
        'row': row,
        'action': action,
        'source': source,
      };

  factory WaterEvent.fromJson(Map<String, dynamic> j) => WaterEvent(
        dateTime: '${j['dateTime'] ?? ''}',
        row: int.tryParse('${j['row'] ?? 0}') ?? 0,
        action: '${j['action'] ?? ''}',
        source: '${j['source'] ?? ''}',
      );
}

class Gut {
  String no, area, crop, length, remark;
  String rowDirection, numberStart;
  int topRows, bottomRows;
  Map<String, String> marks;
  List<RowLink> links;
  List<int> runningRows;
  Map<int, String> rowMarks;
  Map<int, String> completedAt;
  List<WaterEvent> waterHistory;

  Gut({
    required this.no,
    this.area = '',
    this.crop = '',
    this.length = '',
    this.remark = '',
    this.rowDirection = 'उत्तर → दक्षिण',
    this.numberStart = 'पूर्व',
    this.topRows = 0,
    this.bottomRows = 0,
    Map<String, String>? marks,
    List<RowLink>? links,
    List<int>? runningRows,
    Map<int, String>? rowMarks,
    Map<int, String>? completedAt,
    List<WaterEvent>? waterHistory,
  })  : marks = marks ?? {'उत्तर': '', 'दक्षिण': '', 'पूर्व': '', 'पश्चिम': ''},
        links = links ?? [],
        runningRows = runningRows ?? [],
        rowMarks = rowMarks ?? {},
        completedAt = completedAt ?? {},
        waterHistory = waterHistory ?? [];

  Map<String, dynamic> toJson() => {
        'no': no,
        'area': area,
        'crop': crop,
        'length': length,
        'remark': remark,
        'rowDirection': rowDirection,
        'numberStart': numberStart,
        'topRows': topRows,
        'bottomRows': bottomRows,
        'marks': marks,
        'links': links.map((e) => e.toJson()).toList(),
        'runningRows': runningRows,
        'rowMarks': rowMarks.map((k, v) => MapEntry('$k', v)),
        'completedAt': completedAt.map((k, v) => MapEntry('$k', v)),
        'waterHistory': waterHistory.map((e) => e.toJson()).toList(),
      };

  factory Gut.fromJson(Map<String, dynamic> j) => Gut(
        no: '${j['no'] ?? ''}',
        area: '${j['area'] ?? ''}',
        crop: '${j['crop'] ?? ''}',
        length: '${j['length'] ?? ''}',
        remark: '${j['remark'] ?? ''}',
        rowDirection: '${j['rowDirection'] ?? 'उत्तर → दक्षिण'}',
        numberStart: '${j['numberStart'] ?? 'पूर्व'}',
        topRows: int.tryParse('${j['topRows'] ?? 0}') ?? 0,
        bottomRows: int.tryParse('${j['bottomRows'] ?? 0}') ?? 0,
        marks: Map<String, String>.from(j['marks'] ?? const {}),
        links: (j['links'] as List? ?? const [])
            .map((e) => RowLink.fromJson(Map<String, dynamic>.from(e)))
            .toList(),
        runningRows: List<int>.from(j['runningRows'] ?? const []),
        rowMarks: (j['rowMarks'] as Map? ?? const {}).map((k, v) => MapEntry(int.tryParse('$k') ?? 0, '$v')),
        completedAt: (j['completedAt'] as Map? ?? const {}).map((k, v) => MapEntry(int.tryParse('$k') ?? 0, '$v')),
        waterHistory: (j['waterHistory'] as List? ?? const [])
            .map((e) => WaterEvent.fromJson(Map<String, dynamic>.from(e)))
            .toList(),
      );
}

class RowLink {
  int top;
  List<int> bottom;
  RowLink(this.top, this.bottom);
  Map<String, dynamic> toJson() => {'top': top, 'bottom': bottom};
  factory RowLink.fromJson(Map<String, dynamic> j) => RowLink(
        int.tryParse('${j['top'] ?? 0}') ?? 0,
        List<int>.from(j['bottom'] ?? const []),
      );
}

class AppStore extends ChangeNotifier {
  List<Gut> guts = [];
  String? activeGut;
  String source = 'मोठी नाली';
  bool loading = true;
  List<String> sources = ['मोठी नाली', 'विहीर', 'बोअर', 'विहीर मोटर'];

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString('guts');
    if (raw != null && raw.isNotEmpty) {
      final decoded = jsonDecode(raw) as List;
      guts = decoded.map((e) => Gut.fromJson(Map<String, dynamic>.from(e))).toList();
    }
    activeGut = p.getString('activeGut');
    final savedSources = p.getStringList('waterSources');
    if (savedSources != null && savedSources.isNotEmpty) sources = savedSources;
    source = p.getString('activeWaterSource') ?? sources.first;
    if (activeGut == null && guts.isNotEmpty) activeGut = guts.first.no;
    loading = false;
    notifyListeners();
  }

  Future<void> save() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('guts', jsonEncode(guts.map((e) => e.toJson()).toList()));
    await p.setStringList('waterSources', sources);
    await p.setString('activeWaterSource', source);
    if (activeGut != null) {
      await p.setString('activeGut', activeGut!);
    } else {
      await p.remove('activeGut');
    }
  }

  Gut? get active {
    for (final g in guts) {
      if (g.no == activeGut) return g;
    }
    return null;
  }

  Future<void> addWaterSource(String name) async {
    final n = name.trim();
    if (n.isEmpty || sources.contains(n)) return;
    sources.add(n);
    source = n;
    await save();
    notifyListeners();
  }

  void select(String no) {
    activeGut = no;
    save();
    notifyListeners();
  }

  Future<void> upsert(Gut gut) async {
    final i = guts.indexWhere((g) => g.no == gut.no);
    if (i >= 0) {
      guts[i] = gut;
    } else {
      guts.add(gut);
    }
    activeGut = gut.no;
    await save();
    notifyListeners();
  }

  Future<void> remove(String no) async {
    guts.removeWhere((g) => g.no == no);
    if (activeGut == no) activeGut = guts.isEmpty ? null : guts.first.no;
    await save();
    notifyListeners();
  }

  // Rebuild live ON/OFF caches from the dated history after an edit or cancellation.
  void rebuildLiveState(Gut gut) {
    gut.runningRows.clear();
    gut.completedAt.clear();
    final rows = <int>{for (final e in gut.waterHistory) e.row};
    for (final row in rows) {
      final events = gut.waterHistory.where((e) => e.row == row).toList()
        ..sort((a, b) => a.dateTime.compareTo(b.dateTime));
      for (final e in events) {
        if (e.action == 'ON') {
          gut.runningRows.remove(row);
          gut.completedAt.remove(row);
          gut.runningRows.add(row);
        } else if (e.action == 'OFF') {
          gut.runningRows.remove(row);
          gut.completedAt[row] = e.dateTime;
        } else if (e.action == 'RESET') {
          gut.runningRows.remove(row);
          gut.completedAt.remove(row);
        }
      }
    }
    gut.runningRows.sort();
  }
}

class AppShell extends StatefulWidget {
  const AppShell({super.key});
  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  final AppStore store = AppStore();
  int tab = 0;

  @override
  void initState() {
    super.initState();
    store.load();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        if (store.loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
        final pages = [
          Dashboard(store: store, onOpen: (i) => setState(() => tab = i)),
          PlotMappingPage(store: store),
          PlotViewPage(store: store),
          WaterPage(store: store),
        ];
        return Scaffold(
          body: pages[tab],
          bottomNavigationBar: NavigationBar(
            selectedIndex: tab,
            onDestinationSelected: (i) => setState(() => tab = i),
            destinations: const [
              NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'मुख्य'),
              NavigationDestination(icon: Icon(Icons.grid_view_outlined), selectedIcon: Icon(Icons.grid_view), label: 'Mapping'),
              NavigationDestination(icon: Icon(Icons.map_outlined), selectedIcon: Icon(Icons.map), label: 'Plot View'),
              NavigationDestination(icon: Icon(Icons.water_drop_outlined), selectedIcon: Icon(Icons.water_drop), label: 'पाणी'),
            ],
          ),
        );
      },
    );
  }
}

class Dashboard extends StatelessWidget {
  final AppStore store;
  final ValueChanged<int> onOpen;
  const Dashboard({super.key, required this.store, required this.onOpen});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('🌾 शेती • मुख्य मेनू')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        _menuCard(context, 'GUT Update', 'Saved GUT आणि त्याचा Plot Map पाहा / Update करा', Icons.edit_note,
            () => Navigator.push(context, MaterialPageRoute(builder: (_) => GutUpdatePage(store: store)))),
        _menuCard(context, 'Plot Mapping', 'सऱ्या, numbering, link आणि split mapping', Icons.grid_view, () => onOpen(1)),
        _menuCard(context, 'Plot Map View', 'प्रत्यक्ष GUT नकाशा + सऱ्या + बांध + References', Icons.map, () => onOpen(2)),
        _menuCard(context, 'पाणी ON / OFF + Live Map', 'सरी निवडा आणि Live status बदला', Icons.water_drop, () => onOpen(3)),
        const SizedBox(height: 12),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Text('सध्याचे GUT: ${store.activeGut ?? 'निवडलेले नाही'}\nएकूण GUT: ${store.guts.length}',
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
          ),
        ),
      ]),
    );
  }

  Widget _menuCard(BuildContext context, String title, String sub, IconData icon, VoidCallback tap) => Card(
        child: InkWell(
          onTap: tap,
          borderRadius: BorderRadius.circular(16),
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Row(children: [
              CircleAvatar(radius: 26, child: Icon(icon)),
              const SizedBox(width: 16),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 4),
                Text(sub),
              ])),
              const Icon(Icons.chevron_right),
            ]),
          ),
        ),
      );
}

class GutUpdatePage extends StatelessWidget {
  final AppStore store;
  const GutUpdatePage({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('GUT Update')),
      body: store.guts.isEmpty
          ? Center(child: FilledButton.icon(onPressed: () => _openForm(context), icon: const Icon(Icons.add), label: const Text('नवीन GUT तयार करा')))
          : ListView(padding: const EdgeInsets.all(12), children: [
              FilledButton.icon(onPressed: () => _openForm(context), icon: const Icon(Icons.add), label: const Text('नवीन GUT')),
              const SizedBox(height: 10),
              ...store.guts.map((g) => Card(
                    child: ExpansionTile(
                      initiallyExpanded: g.no == store.activeGut,
                      title: Text('GUT ${g.no}', style: const TextStyle(fontWeight: FontWeight.bold)),
                      subtitle: Text('${g.crop} • ${g.area} • ${g.length}'),
                      onExpansionChanged: (v) {
                        if (v) store.select(g.no);
                      },
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(10),
                          child: Column(children: [
                            PlotMapPreview(gut: g, compact: true),
                            const SizedBox(height: 10),
                            Row(children: [
                              Expanded(child: FilledButton.icon(onPressed: () => _openForm(context, g), icon: const Icon(Icons.edit), label: const Text('Update'))),
                              const SizedBox(width: 8),
                              IconButton(onPressed: () => _delete(context, g), icon: const Icon(Icons.delete_outline)),
                            ]),
                          ]),
                        ),
                      ],
                    ),
                  )),
            ]),
    );
  }

  void _openForm(BuildContext context, [Gut? g]) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => GutFormPage(store: store, existing: g)));
  }

  Future<void> _delete(BuildContext context, Gut g) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('GUT Delete'),
        content: Text('GUT ${g.no} हटवायचा आहे का?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('नाही')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('होय')),
        ],
      ),
    );
    if (ok == true) await store.remove(g.no);
  }
}

class GutFormPage extends StatefulWidget {
  final AppStore store;
  final Gut? existing;
  const GutFormPage({super.key, required this.store, this.existing});
  @override
  State<GutFormPage> createState() => _GutFormPageState();
}

class _GutFormPageState extends State<GutFormPage> {
  late final TextEditingController no, area, crop, length, remark;
  late String direction, numberStart;
  late final Map<String, TextEditingController> marks;

  @override
  void initState() {
    super.initState();
    final g = widget.existing;
    no = TextEditingController(text: g?.no ?? '');
    area = TextEditingController(text: g?.area ?? '');
    crop = TextEditingController(text: g?.crop ?? '');
    length = TextEditingController(text: g?.length ?? '');
    remark = TextEditingController(text: g?.remark ?? '');
    direction = g?.rowDirection ?? 'उत्तर → दक्षिण';
    numberStart = g?.numberStart ?? 'पूर्व';
    final m = g?.marks ?? {};
    marks = {for (final d in ['उत्तर', 'दक्षिण', 'पूर्व', 'पश्चिम']) d: TextEditingController(text: m[d] ?? '')};
  }

  @override
  void dispose() {
    for (final c in [no, area, crop, length, remark, ...marks.values]) c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.existing == null ? 'नवीन GUT' : 'GUT Update')),
      body: ListView(padding: const EdgeInsets.fromLTRB(16, 16, 16, 110), children: [
        _field('GUT क्रमांक', no),
        _field('क्षेत्रफळ', area),
        _field('पीक', crop),
        _field('लांबी', length),
        _drop('सऱ्यांची दिशा (पाण्याची दिशा)', direction, ['उत्तर → दक्षिण', 'दक्षिण → उत्तर', 'पूर्व → पश्चिम', 'पश्चिम → पूर्व'], (v) => setState(() => direction = v!)),
        _drop('सऱ्यांची नंबरिंग सुरू होण्याची दिशा', numberStart, ['पूर्व', 'पश्चिम', 'उत्तर', 'दक्षिण'], (v) => setState(() => numberStart = v!)),
        const SizedBox(height: 8),
        const Text('चारही दिशांचे Land Mark', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        for (final d in ['उत्तर', 'दक्षिण', 'पूर्व', 'पश्चिम'])
          Padding(padding: const EdgeInsets.only(top: 10), child: TextField(controller: marks[d], decoration: InputDecoration(labelText: '$d Land Mark'))),
        const SizedBox(height: 10),
        _field('Remark', remark, maxLines: 2),
        if (widget.existing != null && widget.existing!.topRows > 0) ...[
          const SizedBox(height: 8),
          const Text('सेव्ह केलेला Plot Map', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          PlotMapPreview(gut: widget.existing!, compact: true),
        ],
      ]),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: FilledButton.icon(onPressed: _save, icon: const Icon(Icons.save), label: Text(widget.existing == null ? 'Save GUT' : 'Update GUT')),
        ),
      ),
    );
  }

  Widget _field(String label, TextEditingController c, {int maxLines = 1}) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: TextField(controller: c, maxLines: maxLines, decoration: InputDecoration(labelText: label)),
      );

  Widget _drop(String label, String value, List<String> items, ValueChanged<String?> onChanged) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: DropdownButtonFormField<String>(
          value: value,
          decoration: InputDecoration(labelText: label),
          items: items.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
          onChanged: onChanged,
        ),
      );

  Future<void> _save() async {
    final gutNo = no.text.trim();
    if (gutNo.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('GUT क्रमांक भरा')));
      return;
    }
    final old = widget.existing;
    if (old == null && widget.store.guts.any((g) => g.no == gutNo)) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('हा GUT क्रमांक आधीच आहे')));
      return;
    }
    final g = Gut(
      no: gutNo,
      area: area.text.trim(),
      crop: crop.text.trim(),
      length: length.text.trim(),
      remark: remark.text.trim(),
      rowDirection: direction,
      numberStart: numberStart,
      topRows: old?.topRows ?? 0,
      bottomRows: old?.bottomRows ?? 0,
      marks: {for (final e in marks.entries) e.key: e.value.text.trim()},
      links: old?.links,
      runningRows: old?.runningRows,
      rowMarks: old?.rowMarks,
      completedAt: old?.completedAt,
    );
    await widget.store.upsert(g);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('GUT Update सेव्ह झाला')));
      Navigator.pop(context);
    }
  }
}

class PlotMappingPage extends StatefulWidget {
  final AppStore store;
  const PlotMappingPage({super.key, required this.store});
  @override
  State<PlotMappingPage> createState() => _PlotMappingPageState();
}

class _PlotMappingPageState extends State<PlotMappingPage> {
  Gut? get gut => widget.store.active;
  late TextEditingController top, bottom, firstTop, firstBottom, splitTop, splitA, splitB, markerRow, markerText;
  String? loadedNo;

  @override
  void initState() {
    super.initState();
    _makeControllers();
  }

  void _makeControllers() {
    final g = gut;
    for (final c in _controllers) c.dispose();
    top = TextEditingController(text: '${g?.topRows == 0 ? 37 : g?.topRows}');
    bottom = TextEditingController(text: '${g?.bottomRows == 0 ? 40 : g?.bottomRows}');
    firstTop = TextEditingController(text: '1');
    firstBottom = TextEditingController(text: '3');
    splitTop = TextEditingController(text: '12');
    splitA = TextEditingController(text: '15');
    splitB = TextEditingController(text: '16');
    markerRow = TextEditingController(text: '1');
    markerText = TextEditingController();
    loadedNo = g?.no;
  }

  List<TextEditingController> get _controllers => [
        if (loadedNo != null) top,
        if (loadedNo != null) bottom,
        if (loadedNo != null) firstTop,
        if (loadedNo != null) firstBottom,
        if (loadedNo != null) splitTop,
        if (loadedNo != null) splitA,
        if (loadedNo != null) splitB,
      ];

  @override
  void dispose() {
    for (final c in _controllers) c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final g = gut;
    if (g == null) return _empty();
    if (loadedNo != g.no) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted && loadedNo != widget.store.activeGut) setState(_makeControllers);
      });
    }
    return Scaffold(
      appBar: AppBar(title: Text('Plot Mapping • GUT ${g.no}'), actions: [IconButton(onPressed: () => _selectGut(context), icon: const Icon(Icons.swap_horiz))]),
      body: ListView(padding: const EdgeInsets.fromLTRB(14, 14, 14, 120), children: [
        _info(g),
        const SizedBox(height: 12),
        _numberSection(),
        const SizedBox(height: 12),
        _linkSection(),
        const SizedBox(height: 12),
        _markerSection(g),
        const SizedBox(height: 12),
        const Text('Plot Layout Preview', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        PlotMapPreview(gut: g, compact: true),
      ]),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: FilledButton.icon(onPressed: _saveMapping, icon: const Icon(Icons.save), label: const Text('Plot Update / Save')),
        ),
      ),
    );
  }

  Widget _empty() => Scaffold(
        appBar: AppBar(title: const Text('Plot Mapping')),
        body: Center(child: FilledButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => GutFormPage(store: widget.store))), child: const Text('पहिले GUT तयार करा'))),
      );

  Widget _info(Gut g) => Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('GUT ${g.no} • ${g.area} • ${g.crop}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            Text('सरी दिशा: ${g.rowDirection} • नंबरिंग: ${g.numberStart}'),
            Text('उत्तर: ${g.marks['उत्तर']} | दक्षिण: ${g.marks['दक्षिण']}'),
            Text('पूर्व: ${g.marks['पूर्व']} | पश्चिम: ${g.marks['पश्चिम']}'),
          ]),
        ),
      );

  Widget _numberSection() => Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('सऱ्यांची संख्या', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(child: TextField(controller: top, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'वरची बाजू सऱ्या'))),
              const SizedBox(width: 10),
              Expanded(child: TextField(controller: bottom, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'खालची बाजू सऱ्या'))),
            ]),
            const SizedBox(height: 10),
            const Text('उदा. 37 वर / 40 खाली: वर 1 → खाली 3. खाली 1-2 = Extra/No Link.'),
          ]),
        ),
      );

  Widget _linkSection() => Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Link Mapping', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(child: TextField(controller: firstTop, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'वरची सरी'))),
              const Padding(padding: EdgeInsets.symmetric(horizontal: 8), child: Text('→')),
              Expanded(child: TextField(controller: firstBottom, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'खालील सरी'))),
            ]),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(child: TextField(controller: splitTop, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Split वरची सरी'))),
              const Padding(padding: EdgeInsets.symmetric(horizontal: 8), child: Text('→')),
              Expanded(child: TextField(controller: splitA, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'खाली A'))),
              const SizedBox(width: 6),
              Expanded(child: TextField(controller: splitB, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'खाली B'))),
            ]),
            const SizedBox(height: 10),
            const Text('Split नंतर पुढील links shift होतील. उदा. 12→15,16; 13→17; 14→18; 37→40.'),
          ]),
        ),
      );

  Widget _markerSection(Gut g) => Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('सरीची खूण / नोंद', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Row(children: [
              Expanded(child: TextField(controller: markerRow, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'सरी नं.'))),
              const SizedBox(width: 8),
              Expanded(child: TextField(controller: markerText, decoration: const InputDecoration(labelText: 'खूण: लिंब / खांबा / कॉक'))),
              const SizedBox(width: 8),
              FilledButton(onPressed: () {
                final n = int.tryParse(markerRow.text.trim());
                final v = markerText.text.trim();
                if (n != null && n > 0 && n <= (g.topRows > g.bottomRows ? g.topRows : g.bottomRows) && v.isNotEmpty) {
                  setState(() => g.rowMarks[n] = v);
                  widget.store.save();
                  markerText.clear();
                }
              }, child: const Text('नोंद')),
            ]),
            if (g.rowMarks.isNotEmpty) ...[
              const SizedBox(height: 8),
              Wrap(spacing: 6, runSpacing: 6, children: g.rowMarks.entries.map((e) => Chip(label: Text('${e.key}: ${e.value}'), onDeleted: () => setState(() => g.rowMarks.remove(e.key)))).toList()),
            ],
          ]),
        ),
      );

  Future<void> _saveMapping() async {
    final g = gut;
    if (g == null) return;
    final tr = int.tryParse(top.text.trim()) ?? 0;
    final br = int.tryParse(bottom.text.trim()) ?? 0;
    if (tr <= 0 || br <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('सऱ्यांची संख्या भरा')));
      return;
    }
    final ft = int.tryParse(firstTop.text.trim()) ?? 1;
    final fb = int.tryParse(firstBottom.text.trim()) ?? 1;
    final st = int.tryParse(splitTop.text.trim()) ?? -1;
    final sa = int.tryParse(splitA.text.trim()) ?? -1;
    final sb = int.tryParse(splitB.text.trim()) ?? -1;
    final links = <RowLink>[];
    for (int i = 1; i <= tr; i++) {
      if (i == st && sa > 0 && sb > 0) {
        links.add(RowLink(i, [sa, sb]));
      } else {
        final offset = i > st ? 1 : 0;
        final b = fb + (i - ft) + offset;
        if (b > 0 && b <= br) links.add(RowLink(i, [b]));
      }
    }
    g.topRows = tr;
    g.bottomRows = br;
    g.links = links;
    await widget.store.save();
    widget.store.notifyListeners();
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Plot Update सेव्ह झाला')));
  }

  Future<void> _selectGut(BuildContext context) async {
    final n = await showDialog<String>(
      context: context,
      builder: (_) => SimpleDialog(
        title: const Text('GUT निवडा'),
        children: widget.store.guts.map((g) => SimpleDialogOption(onPressed: () => Navigator.pop(context, g.no), child: Text('GUT ${g.no}'))).toList(),
      ),
    );
    if (n != null) {
      widget.store.select(n);
      if (mounted) setState(_makeControllers);
    }
  }
}

class PlotViewPage extends StatelessWidget {
  final AppStore store;
  const PlotViewPage({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    final g = store.active;
    if (g == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Plot View')),
        body: const Center(child: Text('पहिले GUT तयार करा')),
      );
    }
    return Scaffold(
      appBar: AppBar(
        title: Text('🌾 GUT ${g.no} • Plot Map'),
        actions: [
          IconButton(
            tooltip: 'नकाशा मोठा/लहान',
            onPressed: () {},
            icon: const Icon(Icons.zoom_in),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(8),
        child: PlotMapPreview(gut: g, compact: false, interactive: true),
      ),
    );
  }
}

class PlotMapPreview extends StatelessWidget {
  final Gut gut;
  final bool compact;
  final bool interactive;
  final ValueChanged<int>? onRowTap;
  final Set<int> selectedRows;
  const PlotMapPreview({super.key, required this.gut, this.compact = false, this.interactive = false, this.onRowTap, this.selectedRows = const {}});

  static String ref(int n) => n.toString().padLeft(2, '0');

  @override
  Widget build(BuildContext context) {
    final topCount = gut.topRows;
    final bottomCount = gut.bottomRows;
    final count = topCount > bottomCount ? topCount : bottomCount;
    if (count <= 0) {
      return const Card(child: Padding(padding: EdgeInsets.all(14), child: Text('Plot Mapping अजून सेव्ह केलेले नाही.')));
    }

    // Small sari boxes: keep the whole plot compact while retaining readable references.
    final cellW = compact ? 26.0 : 32.0;
    final plotW = count * cellW + 155;
    final plotH = compact ? 245.0 : 430.0;

    Widget map = SizedBox(
      width: plotW,
      height: plotH,
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTapUp: onRowTap == null ? null : (d) {
          const left = 95.0;
          final right = left + count * cellW;
          final x = d.localPosition.dx;
          // Base numbering starts from the selected base side.
          // EAST: 01 starts at the right/east edge and increases toward WEST.
          // WEST: 01 starts at the left/west edge and increases toward EAST.
          final i = gut.numberStart == 'पूर्व'
              ? ((right - x) / cellW).floor()
              : ((x - left) / cellW).floor();
          if (i < 0 || i >= count) return;
          // The Base number is the only selection key. Reference numbers are display-only.
          onRowTap!(i + 1);
        },
        child: CustomPaint(painter: PlotPainter(gut: gut, cellW: cellW, count: count, ref: ref, selectedRows: selectedRows, interactive: interactive)),
      ),
    );

    if (interactive) {
      map = InteractiveViewer(
        minScale: 0.55,
        maxScale: 4.0,
        scaleEnabled: true,
        panEnabled: true,
        constrained: false,
        boundaryMargin: const EdgeInsets.all(100),
        child: map,
      );
    }

    return Card(
      clipBehavior: Clip.antiAlias,
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(10, 10, 10, 4),
          child: Row(children: [
            const Icon(Icons.map, size: 22),
            const SizedBox(width: 6),
            const Text('Actual Plot Map', style: TextStyle(fontWeight: FontWeight.bold)),
            const Spacer(),
            if (!compact) const Text('Pinch = Zoom • Drag = Map', style: TextStyle(fontSize: 12)),
          ]),
        ),
        SizedBox(
          height: compact ? plotH : 450,
          width: double.infinity,
          child: interactive ? map : SingleChildScrollView(scrollDirection: Axis.horizontal, child: map),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(10, 4, 10, 10),
          child: Wrap(spacing: 12, runSpacing: 5, children: [
            Text('उत्तर: ${gut.marks['उत्तर'] ?? ''}'), Text('दक्षिण: ${gut.marks['दक्षिण'] ?? ''}'),
            Text('पूर्व: ${gut.marks['पूर्व'] ?? ''}'), Text('पश्चिम: ${gut.marks['पश्चिम'] ?? ''}'),
            Text('Base: ${gut.numberStart}'),
            const Text('B = Base • R = Reference'),
          ]),
        ),
      ]),
    );
  }
}

class PlotPainter extends CustomPainter {
  final Gut gut;
  final double cellW;
  final int count;
  final String Function(int) ref;
  final Set<int> selectedRows;
  PlotPainter({required this.gut, required this.cellW, required this.count, required this.ref, this.selectedRows = const {}, this.interactive = false});
  final bool interactive;

  @override
  void paint(Canvas canvas, Size size) {
    const left = 95.0;
    const top = 104.0;
    const bottom = 300.0;
    final right = left + count * cellW;

    final border = Paint()..style = PaintingStyle.stroke..strokeWidth = 2.2..color = Colors.brown.shade800;
    final bund = Paint()..style = PaintingStyle.stroke..strokeWidth = 5..color = Colors.brown.shade700;
    final pending = Paint()..style = PaintingStyle.fill..color = Colors.red.shade300;
    final running = Paint()..style = PaintingStyle.fill..color = Colors.amber.shade300;
    final complete = Paint()..style = PaintingStyle.fill..color = Colors.green.shade300;
    final rowBorder = Paint()..style = PaintingStyle.stroke..strokeWidth = 1..color = Colors.green.shade900;

    final baseLabel = gut.numberStart == 'पूर्व' ? 'पूर्व = B (Base)' : '${gut.numberStart} = B (Base)';
    _text(canvas, 'उत्तर • ${gut.marks['उत्तर'] ?? ''}', Offset(left + 2, 4), 12, Colors.black87, bold: true);
    _text(canvas, baseLabel, Offset(left, 72), 11, Colors.green.shade900, bold: true);
    _text(canvas, 'B = Base   R = Reference', Offset(right - 132, 72), 10, Colors.black87, bold: true);
    _text(canvas, 'दक्षिण • ${gut.marks['दक्षिण'] ?? ''}', Offset(left + 2, 365), 12, Colors.black87, bold: true);
    _text(canvas, 'पश्चिम • ${gut.marks['पश्चिम'] ?? ''}', Offset(4, 205), 12, Colors.black87, bold: true);
    _text(canvas, 'पूर्व • ${gut.marks['पूर्व'] ?? ''}', Offset(right + 8, 205), 12, Colors.black87, bold: true);
    _text(canvas, '↑ उत्तर', Offset(right + 8, 52), 13, Colors.blue.shade800, bold: true);

    // Continuous plot: no middle break. Extra rows on the bottom side are placed at the WEST end
    // (right-hand side when numbering starts from EAST) and occupy only half the plot length.
    canvas.drawLine(Offset(left, top - 7), Offset(right, top - 7), bund);
    canvas.drawLine(Offset(left, bottom + 7), Offset(right, bottom + 7), bund);

    final baseEast = gut.numberStart == 'पूर्व';
    final shared = gut.topRows < gut.bottomRows ? gut.topRows : gut.bottomRows;
    for (int i = 0; i < count; i++) {
      final isExtra = i >= shared;
      // Base numbering always grows from the selected base direction.
      // With EAST as base, extra rows (e.g. 38,39,40) are placed at the WEST end,
      // not on the EAST end. They remain short (half-height) because no opposite row exists.
      final x = baseEast ? right - (i + 1) * cellW : left + i * cellW;
      final northN = i < gut.topRows ? i + 1 : null;
      final southN = i < gut.bottomRows ? i + 1 : null;
      final rowNo = i + 1;
      final status = _statusFor(rowNo);
      final rowTop = isExtra ? top : top;
      final rowBottom = isExtra ? top + (bottom - top) * 0.50 : bottom;
      final rect = Rect.fromLTRB(x, rowTop, x + cellW, rowBottom);
      canvas.drawRect(rect, status == 'running' ? running : status == 'complete' ? complete : pending);
      canvas.drawRect(rect, rowBorder);

      // Each actual base row is selectable only by its B number. R is reference only.
      if (northN != null) {
        _refBox(canvas, Rect.fromLTWH(x, 38, cellW, 28), 'B${ref(northN)}', Colors.white, selected: selectedRows.contains(northN) || (!interactive && gut.runningRows.contains(northN)));
        _refBox(canvas, Rect.fromLTWH(x, 66, cellW, 28), 'R${ref(gut.topRows - northN + 1)}', Colors.blue.shade50);
      }
      if (southN != null) {
        final bottomY = bottom + 10;
        _refBox(canvas, Rect.fromLTWH(x, bottomY, cellW, 28), 'B${ref(southN)}', Colors.white, selected: selectedRows.contains(southN) || (!interactive && gut.runningRows.contains(southN)));
        _refBox(canvas, Rect.fromLTWH(x, bottomY + 28, cellW, 28), 'R${ref(gut.bottomRows - southN + 1)}', Colors.blue.shade50);
      }

      // Extra rows exist only on the side with the larger row count.
      // They are placed at the WEST end when EAST is the base direction.
      if (isExtra) {
        final extraY = top + (bottom - top) * 0.50;
        _centerText(canvas, 'B${ref(rowNo)}', Rect.fromLTWH(x, extraY + 2, cellW, 22), 8.5, Colors.black, bold: true);
        _centerText(canvas, 'R—', Rect.fromLTWH(x, extraY + 24, cellW, 20), 7.5, Colors.black87);
      }

      final marker = gut.rowMarks[rowNo];
      if (marker != null && marker.isNotEmpty) {
        _centerText(canvas, marker, rect, 7.5, Colors.black87, bold: true);
      }
      if (i > 0) canvas.drawLine(Offset(x, rowTop), Offset(x, rowBottom), rowBorder);
    }

    canvas.drawRect(Rect.fromLTRB(left, top, right, bottom), border);
    _text(canvas, 'पाण्याची दिशा: ${gut.rowDirection}', Offset(left, bottom + 72), 11, Colors.blue.shade800, bold: true);
    _legend(canvas, Offset(left, 405), Colors.red.shade300, 'बाकी');
    _legend(canvas, Offset(left + 72, 405), Colors.amber.shade300, 'पाणी सुरू');
    _legend(canvas, Offset(left + 175, 405), Colors.green.shade300, 'पूर्ण / बंद');
    _legend(canvas, Offset(left + 290, 405), Colors.brown.shade700, 'बांध');
  }

  String _statusFor(int row) {
    if (gut.runningRows.contains(row)) return 'running';
    final now = DateTime.now();
    final events = gut.waterHistory.where((e) => e.row == row)
      .map((e) => MapEntry(e, DateTime.tryParse(e.dateTime)))
      .where((p) => p.value != null && !p.value!.isAfter(now))
      .toList()
      ..sort((a, b) => a.value!.compareTo(b.value!));
    WaterEvent? last;
    for (final p in events) {
      if (p.key.action == 'ON' || p.key.action == 'OFF' || p.key.action == 'RESET') last = p.key;
    }
    if (last == null || last.action == 'RESET' || last.action == 'ON') return last?.action == 'ON' ? 'running' : 'pending';
    if (last.action == 'OFF') {
      // OFF means the row is stopped: show green on the map immediately.
      // RESET explicitly returns the row to red/pending.
      return 'complete';
    }
    return 'pending';
  }

  void _refBox(Canvas canvas, Rect r, String value, Color fill, {bool selected = false}) {
    final p = Paint()..color = selected ? Colors.lightBlue.shade100 : fill;
    canvas.drawRect(r, p);
    final b = Paint()..style = PaintingStyle.stroke..strokeWidth = selected ? 2.2 : 1..color = selected ? Colors.blue.shade900 : Colors.brown.shade400;
    canvas.drawRect(r, b);
    _centerText(canvas, value, r, 8.5, Colors.black, bold: true);
  }

  void _centerText(Canvas canvas, String value, Rect r, double size, Color color, {bool bold = false}) {
    final tp = TextPainter(
      text: TextSpan(text: value, style: TextStyle(fontSize: size, color: color, fontWeight: bold ? FontWeight.bold : FontWeight.normal)),
      textDirection: TextDirection.ltr,
    )..layout(maxWidth: r.width);
    tp.paint(canvas, Offset(r.center.dx - tp.width / 2, r.center.dy - tp.height / 2));
  }

  void _legend(Canvas canvas, Offset o, Color c, String label) {
    final p = Paint()..color = c;
    canvas.drawRect(Rect.fromLTWH(o.dx, o.dy, 16, 12), p);
    _text(canvas, label, Offset(o.dx + 20, o.dy - 2), 10, Colors.black87);
  }

  void _text(Canvas canvas, String value, Offset offset, double size, Color color, {bool bold = false}) {
    final tp = TextPainter(
      text: TextSpan(text: value, style: TextStyle(fontSize: size, color: color, fontWeight: bold ? FontWeight.bold : FontWeight.normal)),
      textDirection: TextDirection.ltr,
    )..layout();
    tp.paint(canvas, offset);
  }

  @override
  bool shouldRepaint(covariant PlotPainter oldDelegate) => true;
}

class WaterPage extends StatefulWidget {
  final AppStore store;
  const WaterPage({super.key, required this.store});
  @override State<WaterPage> createState() => _WaterPageState();
}

class _WaterPageState extends State<WaterPage> {
  final Set<int> selected = {};
  DateTime selectedDate = DateTime.now();
  final TextEditingController fromRow = TextEditingController(text: '1');
  final TextEditingController toRow = TextEditingController();
  bool offSelectionMode = false;

  String _status(Gut g, int n) {
    if (g.runningRows.contains(n)) return 'running';
    final raw = g.completedAt[n];
    if (raw != null) {
      final d = DateTime.tryParse(raw);
      if (d != null && DateTime.now().difference(d).inDays < 15) return 'complete';
    }
    return 'pending';
  }

  bool _sameDay(String iso, DateTime d) {
    final x = DateTime.tryParse(iso);
    return x != null && x.year == d.year && x.month == d.month && x.day == d.day;
  }

  String _fmt(String iso) {
    final d = DateTime.tryParse(iso);
    if (d == null) return iso;
    return '${d.day.toString().padLeft(2,'0')}/${d.month.toString().padLeft(2,'0')}/${d.year} '
        '${d.hour.toString().padLeft(2,'0')}:${d.minute.toString().padLeft(2,'0')}';
  }

  Future<void> _addSource() async {
    final c = TextEditingController();
    final name = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('नवीन पाणी स्रोत'),
        content: TextField(
          controller: c,
          autofocus: true,
          decoration: const InputDecoration(labelText: 'स्रोताचे नाव'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('रद्द')),
          FilledButton(onPressed: () => Navigator.pop(context, c.text.trim()), child: const Text('Save')),
        ],
      ),
    );
    if (name != null && name.trim().isNotEmpty) {
      await widget.store.addWaterSource(name);
      if (mounted) setState(() {});
    }
  }

  Future<void> _deleteSource() async {
    final source = widget.store.source;
    if (widget.store.sources.length <= 1) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('किमान एक पाणी स्रोत ठेवणे आवश्यक आहे.')));
      return;
    }
    final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('पाण्याचा स्रोत Delete करायचा?'),
      content: Text('“$source” स्रोत यादीतून काढायचा आहे का? जुन्या नोंदींमधील इतिहास सुरक्षित राहील.'),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('नाही')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Delete'))],
    ));
    if (ok != true) return;
    widget.store.sources.remove(source);
    widget.store.source = widget.store.sources.first;
    await widget.store.save();
    if (mounted) setState(() {});
  }

  void _showHistory() {
    Navigator.push(context, MaterialPageRoute(builder: (_) => WaterHistoryPage(store: widget.store)));
  }

  void _showReport({required bool live}) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => WaterReportPage(
          store: widget.store,
          date: selectedDate,
          live: live,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final g = widget.store.active;
    if (g == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('पाणी नियंत्रण')),
        body: const Center(child: Text('पहिले GUT तयार करा')),
      );
    }

    final count = g.topRows > g.bottomRows ? g.topRows : g.bottomRows;

    return Scaffold(
      appBar: AppBar(
        title: const Text('पाणी नियंत्रण ON / OFF'),
        actions: [
          IconButton(
            tooltip: 'आजचा Live Report',
            onPressed: () => _showReport(live: true),
            icon: const Icon(Icons.live_tv),
          ),
          IconButton(
            tooltip: 'Date-wise Report',
            onPressed: () => _showReport(live: false),
            icon: const Icon(Icons.assessment_outlined),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(10, 10, 10, 120),
        children: [
          Row(
            children: [
              Expanded(
                child: ListTile(
                  dense: true,
                  title: const Text('पाणी तारीख'),
                  subtitle: Text(
                    '${selectedDate.day.toString().padLeft(2,'0')}/${selectedDate.month.toString().padLeft(2,'0')}/${selectedDate.year}',
                  ),
                  trailing: const Icon(Icons.calendar_month),
                  onTap: () async {
                    final d = await showDatePicker(
                      context: context,
                      firstDate: DateTime(2020),
                      lastDate: DateTime(2100),
                      initialDate: selectedDate,
                    );
                    if (d != null) setState(() => selectedDate = d);
                  },
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: DropdownButtonFormField<String>(
                  value: widget.store.sources.contains(widget.store.source)
                      ? widget.store.source
                      : widget.store.sources.first,
                  decoration: const InputDecoration(labelText: 'पाणी स्रोत'),
                  items: widget.store.sources
                      .map((x) => DropdownMenuItem(value: x, child: Text(x)))
                      .toList(),
                  onChanged: (v) async {
                    if (v == null) return;
                    widget.store.source = v;
                    await widget.store.save();
                    setState(() {});
                  },
                ),
              ),
              IconButton(
                tooltip: 'नवीन पाणी स्रोत',
                onPressed: _addSource,
                icon: const Icon(Icons.add_circle),
              ),
              IconButton(
                tooltip: 'निवडलेला पाणी स्रोत Delete',
                onPressed: _deleteSource,
                icon: const Icon(Icons.delete_outline),
              ),
            ],
          ),
          const SizedBox(height: 6),
          DropdownButtonFormField<String>(
            value: widget.store.guts.any((x) => x.no == widget.store.activeGut) ? widget.store.activeGut : null,
            decoration: const InputDecoration(labelText: 'GUT Selection'),
            items: widget.store.guts.map((x) => DropdownMenuItem(value: x.no, child: Text('GUT ${x.no} • ${x.crop}'))).toList(),
            onChanged: (v) {
              if (v == null) return;
              widget.store.select(v);
              setState(() { selected.clear(); offSelectionMode = false; });
            },
          ),
          const SizedBox(height: 6),
          Text(
            'GUT ${g.no} • Plot वर सरी टॅप करून निवडा',
            style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(child: TextField(controller: fromRow, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'सरी From'))),
            const SizedBox(width: 8),
            Expanded(child: TextField(controller: toRow, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'सरी To'))),
            const SizedBox(width: 8),
            FilledButton(onPressed: () {
              final a = int.tryParse(fromRow.text) ?? 1;
              final b = int.tryParse(toRow.text) ?? a;
              if (a < 1 || b < a || b > count) {
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('सरी 1 ते $count दरम्यान निवडा')));
                return;
              }
              final range = List.generate(b-a+1, (i)=>a+i);
              final runningInRange = range.where(g.runningRows.contains).toList();
              setState(() {
                selected
                  ..clear()
                  ..addAll(runningInRange.isNotEmpty ? runningInRange : range);
                // Any currently running rows in the chosen range are selected for OFF, never ON by mistake.
                offSelectionMode = runningInRange.isNotEmpty;
              });
            }, child: const Text('निवडा')),
          ]),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(child: FilledButton.icon(onPressed: selected.isEmpty ? null : _waterOn, icon: const Icon(Icons.water_drop), label: const Text('पाणी ON'))),
            const SizedBox(width: 8),
            Expanded(child: FilledButton.tonalIcon(onPressed: g.runningRows.isEmpty && !offSelectionMode ? null : (offSelectionMode ? _waterOff : _prepareWaterOff), icon: const Icon(Icons.water_drop_outlined), label: Text(offSelectionMode ? 'निवडलेल्या OFF' : 'पाणी बंद करा'))),
          ]),
          if (offSelectionMode) Padding(padding: const EdgeInsets.symmetric(vertical: 6), child: Text('बंद करायच्या सऱ्या निवडलेल्या आहेत. चालू ठेवायच्या सऱ्या नकाशावर टॅप करून Unselect करा.', style: TextStyle(color: Colors.deepOrange.shade800, fontWeight: FontWeight.w600))),
          Row(children: [
            Expanded(child: OutlinedButton.icon(onPressed: selected.isEmpty ? null : _resetRows, icon: const Icon(Icons.refresh), label: const Text('लाल करा (Reset)'))),
            const SizedBox(width: 8),
            Expanded(child: OutlinedButton.icon(onPressed: _showHistory, icon: const Icon(Icons.history), label: const Text('नोंदी दुरुस्ती'))),
          ]),
          const SizedBox(height: 6),
          OutlinedButton.icon(onPressed: _freshWaterData, icon: const Icon(Icons.delete_sweep), label: const Text('सर्व पाणी डेटा Fresh')),
          const SizedBox(height: 8),
          PlotMapPreview(
            gut: g,
            compact: false,
            interactive: true,
            selectedRows: selected,
            onRowTap: (n) {
              if (n <= 0 || n > count) return;
              setState(() {
                if (offSelectionMode && !g.runningRows.contains(n)) return;
                if (selected.contains(n)) {
                  selected.remove(n);
                } else {
                  selected.add(n);
                }
              });
            },
          ),
          const SizedBox(height: 8),
          if (selected.isNotEmpty)
            Text(
              'निवडलेल्या सऱ्या: ${selected.toList()..sort()}',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
          const SizedBox(height: 8),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Text(
                '🔴 बाकी: ${List.generate(count, (i) => i+1).where((n) => _status(g,n)=='pending').length} सऱ्या\n'
                '🟡 चालू: ${g.runningRows.length} सऱ्या\n'
                '🟢 बंद करून 15 दिवसांच्या आत: ${List.generate(count, (i) => i+1).where((n) => _status(g,n)=='complete').length} सऱ्या\n'
                'स्रोत: ${widget.store.source}',
                style: const TextStyle(fontWeight: FontWeight.w600),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => _showReport(live: true),
                  icon: const Icon(Icons.live_tv),
                  label: const Text('आजचा Live Report'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => _showReport(live: false),
                  icon: const Icon(Icons.calendar_view_day),
                  label: const Text('Date-wise Report'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  bool _isGreenOnDate(Gut gut, int row, DateTime date) {
    final target = DateTime(date.year, date.month, date.day);
    final events = gut.waterHistory.where((e) => e.row == row).toList()
      ..sort((a, b) => a.dateTime.compareTo(b.dateTime));
    WaterEvent? on;
    WaterEvent? off;
    for (final e in events) {
      final t = DateTime.tryParse(e.dateTime);
      if (t == null || DateTime(t.year, t.month, t.day).isAfter(target)) continue;
      if (e.action == 'RESET') { on = null; off = null; }
      else if (e.action == 'ON') { on = e; off = null; }
      else if (e.action == 'OFF' && on != null) { off = e; }
    }
    if (on == null || off == null) return false;
    final offDate = DateTime.parse(off.dateTime);
    final offDay = DateTime(offDate.year, offDate.month, offDate.day);
    final diff = target.difference(offDay).inDays;
    return diff >= 1 && diff <= 15;
  }

  Future<void> _waterOn() async {
    final g = widget.store.active;
    if (g == null || selected.isEmpty) return;
    final rows = selected.toList()..sort();
    final clock = DateTime.now();
    final now = DateTime(selectedDate.year, selectedDate.month, selectedDate.day, clock.hour, clock.minute, clock.second).toIso8601String();
    final stillGreen = rows.where((n) => _isGreenOnDate(g, n, selectedDate)).toList();
    bool makeFollowingRed = false;
    if (stillGreen.isNotEmpty) {
      final firstFollowing = rows.last + 1;
      if (firstFollowing <= (g.topRows > g.bottomRows ? g.topRows : g.bottomRows)) {
        final makeRed = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
          title: const Text('पुढील सरी Red करायच्या?'),
          content: Text('निवडलेल्या सरी ${rows.join(', ')} अजून Green आहेत. 15 दिवस पूर्ण होण्यापूर्वी पुन्हा पाणी चालू करत आहात. सरी $firstFollowing पासून पुढील सर्व सरी Red करायच्या का?'),
          actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('नाही')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('हो, Red करा'))],
        ));
        makeFollowingRed = makeRed == true;
      }
    }
    final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('पाणी चालू करण्याची खात्री करा'),
      content: Text('GUT ${g.no}\nतारीख: ${selectedDate.day.toString().padLeft(2,'0')}.${selectedDate.month.toString().padLeft(2,'0')}.${selectedDate.year}\nस्रोत: ${widget.store.source}\nपाणी चालू होणाऱ्या सऱ्या: ${rows.join(', ')}\n\nमाहिती तपासून पाणी चालू करायचे आहे का?'),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('रद्द')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('हो, चालू करा'))],
    ));
    if (ok != true) return;
    for (final n in rows) {
      g.runningRows.remove(n);
      g.completedAt.remove(n);
      g.runningRows.add(n);
      g.waterHistory.add(WaterEvent(dateTime: now, row: n, action: 'ON', source: widget.store.source));
    }
    if (makeFollowingRed) {
      final count = g.topRows > g.bottomRows ? g.topRows : g.bottomRows;
      for (var n = rows.last + 1; n <= count; n++) {
        g.runningRows.remove(n);
        g.completedAt.remove(n);
        g.waterHistory.add(WaterEvent(dateTime: now, row: n, action: 'RESET', source: widget.store.source));
      }
    }
    widget.store.rebuildLiveState(g);
    await widget.store.save();
    widget.store.notifyListeners();
    if (mounted) setState(() { selected.clear(); offSelectionMode = false; });
  }

  void _prepareWaterOff() {
    final g = widget.store.active;
    if (g == null || g.runningRows.isEmpty) return;
    setState(() {
      selected
        ..clear()
        ..addAll(g.runningRows);
      offSelectionMode = true;
    });
  }

  Future<void> _waterOff() async {
    final g = widget.store.active;
    if (g == null || selected.isEmpty) return;
    final rows = selected.toList()..sort();
    final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('पाणी बंद करण्याची खात्री करा'),
      content: Text('तारीख: ${selectedDate.day.toString().padLeft(2,'0')}.${selectedDate.month.toString().padLeft(2,'0')}.${selectedDate.year}\nस्रोत: ${widget.store.source}\nबंद होणाऱ्या सऱ्या: ${rows.join(', ')}\n\nमाहिती तपासून पाणी बंद करायचे आहे का?'),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('रद्द')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('हो, बंद करा'))],
    ));
    if (ok != true) return;
    final clock = DateTime.now();
    final now = DateTime(selectedDate.year, selectedDate.month, selectedDate.day, clock.hour, clock.minute, clock.second).toIso8601String();
    for (final n in rows) {
      g.completedAt[n] = now;
      g.waterHistory.add(WaterEvent(dateTime: now, row: n, action: 'OFF', source: widget.store.source));
    }
    g.runningRows.removeWhere(rows.contains);
    widget.store.rebuildLiveState(g);
    await widget.store.save();
    widget.store.notifyListeners();
    if (mounted) setState(() { selected.clear(); offSelectionMode = false; });
  }

  Future<void> _resetRows() async {
    final g = widget.store.active;
    if (g == null || selected.isEmpty) return;
    final rows = selected.toList();
    final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('सऱ्या लाल करायच्या?'),
      content: Text('निवडलेल्या सऱ्यांचा हिरवा Status रद्द करून लाल करायचा आहे? जुनी ON/OFF नोंद इतिहासात राहील.\nसऱ्या: ${rows.join(', ')}'),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('रद्द')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('लाल करा'))],
    ));
    if (ok != true) return;
    for (final n in rows) {
      g.runningRows.remove(n);
      g.completedAt.remove(n);
      g.waterHistory.add(WaterEvent(dateTime: DateTime.now().toIso8601String(), row: n, action: 'RESET', source: widget.store.source));
    }
    widget.store.rebuildLiveState(g);
    await widget.store.save();
    widget.store.notifyListeners();
    if (mounted) setState(() { selected.clear(); offSelectionMode = false; });
  }

  Future<void> _freshWaterData() async {
    final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('सर्व पाणी डेटा Fresh करायचा?'),
      content: const Text('सर्व GUT मधील जुन्या पाणी ON/OFF नोंदी आणि पाणी Status हटतील. GUT, नकाशे, सरींचे नंबर व पाण्याचे स्रोत सुरक्षित राहतील. आधी Backup असल्याची खात्री करा.'),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('रद्द')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Fresh करा'))],
    ));
    if (ok != true) return;
    for (final gut in widget.store.guts) {
      gut.waterHistory.clear();
      gut.runningRows.clear();
      gut.completedAt.clear();
    }
    await widget.store.save();
    widget.store.notifyListeners();
    if (mounted) setState(() { selected.clear(); offSelectionMode = false; });
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('सर्व पाणी डेटा Fresh झाला. GUT व नकाशे सुरक्षित आहेत.')));
  }
}

class WaterHistoryPage extends StatefulWidget {
  final AppStore store;
  const WaterHistoryPage({super.key, required this.store});
  @override State<WaterHistoryPage> createState() => _WaterHistoryPageState();
}

class _WaterHistoryPageState extends State<WaterHistoryPage> {
  String? _selectedGut;
  Gut? _selectedGutObject() {
    for (final g in widget.store.guts) { if (g.no == _selectedGut) return g; }
    return null;
  }
  @override void initState() { super.initState(); _selectedGut = widget.store.activeGut; }

  String _date(String iso) {
    final d = DateTime.tryParse(iso);
    if (d == null) return iso;
    return '${d.day.toString().padLeft(2,'0')}.${d.month.toString().padLeft(2,'0')}.${d.year.toString().substring(2)}';
  }

  Future<void> _editOrAdd([WaterEvent? event]) async {
    final gut = _selectedGutObject();
    if (gut == null) return;
    final rowController = TextEditingController(text: '${event?.row ?? 1}');
    DateTime pickedDate = DateTime.tryParse(event?.dateTime ?? '') ?? DateTime.now();
    String action = event?.action ?? 'ON';
    String source = event?.source ?? widget.store.source;
    final saved = await showDialog<bool>(context: context, builder: (ctx) => StatefulBuilder(builder: (ctx, setDialogState) => AlertDialog(
      title: Text(event == null ? 'नवीन पाणी नोंद' : 'पाणी नोंद Edit'),
      content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        TextButton.icon(onPressed: () async { final d = await showDatePicker(context: ctx, firstDate: DateTime(2020), lastDate: DateTime(2100), initialDate: pickedDate); if (d != null) setDialogState(() => pickedDate = DateTime(d.year,d.month,d.day,pickedDate.hour,pickedDate.minute,pickedDate.second)); }, icon: const Icon(Icons.calendar_month), label: Text('तारीख: ${_date(pickedDate.toIso8601String())}')),
        TextField(controller: rowController, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'सरी क्रमांक')),
        DropdownButtonFormField<String>(value: action, decoration: const InputDecoration(labelText: 'Action'), items: const [DropdownMenuItem(value:'ON',child:Text('पाणी ON')),DropdownMenuItem(value:'OFF',child:Text('पाणी OFF')),DropdownMenuItem(value:'RESET',child:Text('Red / Reset'))], onChanged: (v) { if (v != null) setDialogState(() => action = v); }),
        DropdownButtonFormField<String>(value: widget.store.sources.contains(source) ? source : widget.store.sources.first, decoration: const InputDecoration(labelText: 'पाणी स्रोत'), items: widget.store.sources.map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(), onChanged: (v) { if (v != null) setDialogState(() => source = v); }),
      ])),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx,false), child: const Text('रद्द')), FilledButton(onPressed: () => Navigator.pop(ctx,true), child: const Text('Save'))],
    )));
    if (saved != true) return;
    final row = int.tryParse(rowController.text);
    final maxRows = (gut.topRows > gut.bottomRows ? gut.topRows : gut.bottomRows);
    if (row == null || row < 1 || row > maxRows) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('सरी क्रमांक 1 ते $maxRows दरम्यान द्या.')));
      return;
    }
    final newDateTime = DateTime(pickedDate.year,pickedDate.month,pickedDate.day,pickedDate.hour,pickedDate.minute,pickedDate.second).toIso8601String();
    if (event != null) {
      event.dateTime = newDateTime; event.row = row; event.action = action; event.source = source;
    } else {
      gut.waterHistory.add(WaterEvent(dateTime:newDateTime,row:row,action:action,source:source));
    }
    gut.waterHistory.sort((a,b)=>a.dateTime.compareTo(b.dateTime));
    widget.store.rebuildLiveState(gut);
    await widget.store.save(); widget.store.notifyListeners();
    if (mounted) setState(() {});
  }

  Future<void> _cancelEvent(Gut gut, WaterEvent event) async {
    final ok = await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(title:const Text('नोंद रद्द करायची?'),content:Text('${_date(event.dateTime)} • सरी ${event.row} • ${event.action}\nही नोंद रद्द होईल. त्याच तारखेला योग्य नोंद पुन्हा करता येईल.'),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('नाही')),FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('रद्द करा'))]));
    if (ok != true) return;
    gut.waterHistory.remove(event); widget.store.rebuildLiveState(gut); await widget.store.save(); widget.store.notifyListeners(); if(mounted)setState((){});
  }

  @override Widget build(BuildContext context) {
    final gut = _selectedGutObject();
    final events = gut == null ? <WaterEvent>[] : (gut.waterHistory.toList()..sort((a,b)=>b.dateTime.compareTo(a.dateTime)));
    return Scaffold(appBar:AppBar(title:const Text('पाणी नोंदी दुरुस्ती')),body:Padding(padding:const EdgeInsets.all(12),child:Column(children:[
      DropdownButtonFormField<String>(value:_selectedGut,decoration:const InputDecoration(labelText:'GUT Selection'),items:widget.store.guts.map((g)=>DropdownMenuItem(value:g.no,child:Text('GUT ${g.no} • ${g.crop}'))).toList(),onChanged:(v)=>setState(()=>_selectedGut=v)),
      const SizedBox(height:8),
      Row(children:[const Expanded(child:Text('जुन्या नोंदी Edit करा किंवा रद्द करून पुन्हा नोंद करा.')),IconButton(onPressed:gut==null?null:()=>_editOrAdd(),tooltip:'नवीन नोंद',icon:const Icon(Icons.add_circle))]),
      Expanded(child:events.isEmpty?const Center(child:Text('नोंदी उपलब्ध नाहीत')):ListView.builder(itemCount:events.length,itemBuilder:(ctx,i){final e=events[i];return Card(child:ListTile(title:Text('${_date(e.dateTime)} • सरी ${e.row} • ${e.action}',style:const TextStyle(fontWeight:FontWeight.bold)),subtitle:Text('स्रोत: ${e.source}'),trailing:Wrap(spacing:0,children:[IconButton(tooltip:'Edit',onPressed:()=>_editOrAdd(e),icon:const Icon(Icons.edit_outlined)),IconButton(tooltip:'नोंद रद्द',onPressed:()=>_cancelEvent(gut!,e),icon:const Icon(Icons.delete_outline))])));})),
    ])));
  }
}

class WaterReportPage extends StatefulWidget {
  final AppStore store;
  final DateTime date;
  final bool live;
  const WaterReportPage({super.key, required this.store, required this.date, required this.live});
  @override State<WaterReportPage> createState() => _WaterReportPageState();
}

class _WaterReportPageState extends State<WaterReportPage> {
  late DateTime fromDate;
  late DateTime toDate;
  String gutFilter = 'All';
  String report = 'date';
  bool loadingPdf = false;
  final TransformationController _zoomController = TransformationController();
  double _zoomScale = 1.0;

  @override
  void dispose() {
    _zoomController.dispose();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    fromDate = DateTime(widget.date.year, widget.date.month, widget.date.day);
    toDate = fromDate;
  }

  String ddmmyy(DateTime d) => '${d.day.toString().padLeft(2,'0')}.${d.month.toString().padLeft(2,'0')}.${d.year.toString().substring(2)}';
  DateTime dayOnly(DateTime d) => DateTime(d.year, d.month, d.day);
  List<DateTime> days() {
    final a = dayOnly(fromDate), b = dayOnly(toDate);
    final out=<DateTime>[];
    for (var d=a; !d.isAfter(b); d=d.add(const Duration(days:1))) out.add(d);
    return out;
  }
  List<Gut> selectedGuts() => gutFilter == 'All' ? widget.store.guts : widget.store.guts.where((g)=>g.no==gutFilter).toList();
  int rowCount(Gut g) => ((g.topRows > g.bottomRows ? g.topRows : g.bottomRows).clamp(0,50)).toInt();
  List<WaterEvent> eventsFor(Gut g, int row) => g.waterHistory.where((e)=>e.row==row).toList()..sort((a,b)=>a.dateTime.compareTo(b.dateTime));

  String statusFor(Gut g, int row, DateTime date) {
    final ds=dayOnly(date); WaterEvent? on; WaterEvent? off;
    for(final e in eventsFor(g,row)) {
      final t=DateTime.tryParse(e.dateTime); if(t==null) continue;
      final td=dayOnly(t); if(td.isAfter(ds)) break;
      if(e.action=='RESET'){on=null;off=null;} else if(e.action=='ON'){on=e;off=null;} else if(e.action=='OFF' && on!=null){off=e;}
    }
    if(on==null) return 'red';
    final onDay=dayOnly(DateTime.parse(on.dateTime));
    if(ds.isBefore(onDay)) return 'red';
    if(off==null) return 'yellow';
    final offDay=dayOnly(DateTime.parse(off.dateTime));
    if(ds.isBefore(offDay)) return 'yellow';
    final diff=ds.difference(offDay).inDays;
    if(diff==0) return 'yellow';
    if(diff>=1 && diff<=15) return 'green';
    return 'red';
  }

  String activeSourceFor(Gut g, int row, DateTime date) {
    final ds=dayOnly(date); WaterEvent? on; WaterEvent? off;
    for(final e in eventsFor(g,row)) {
      final t=DateTime.tryParse(e.dateTime); if(t==null) continue;
      final td=dayOnly(t); if(td.isAfter(ds)) break;
      if(e.action=='RESET'){on=null;off=null;} else if(e.action=='ON'){on=e;off=null;} else if(e.action=='OFF' && on!=null){off=e;}
    }
    if(on==null) return '';
    final st=statusFor(g,row,date);
    return st=='yellow' ? on.source : '';
  }

  Future<void> pickFrom() async {
    final d=await showDatePicker(context:context,firstDate:DateTime(2020),lastDate:DateTime(2100),initialDate:fromDate);
    if(d!=null)setState(()=>fromDate=d.isBefore(toDate)?d:d);
    if(d!=null && toDate.isBefore(d))setState(()=>toDate=d);
  }
  Future<void> pickTo() async {
    final d=await showDatePicker(context:context,firstDate:fromDate,lastDate:DateTime(2100),initialDate:toDate);
    if(d!=null)setState(()=>toDate=d);
  }

  Widget zoomPreview(Widget child) => Column(
    crossAxisAlignment: CrossAxisAlignment.end,
    children: [
      Row(mainAxisAlignment: MainAxisAlignment.end, children: [
        IconButton(tooltip: 'Zoom out', onPressed: () => setState(() {
          _zoomScale = (_zoomScale / 1.25).clamp(0.45, 4.0);
          _zoomController.value = Matrix4.diagonal3Values(_zoomScale, _zoomScale, 1);
        }), icon: const Icon(Icons.zoom_out)),
        Text('${(_zoomScale * 100).round()}%'),
        IconButton(tooltip: 'Zoom in', onPressed: () => setState(() {
          _zoomScale = (_zoomScale * 1.25).clamp(0.45, 4.0);
          _zoomController.value = Matrix4.diagonal3Values(_zoomScale, _zoomScale, 1);
        }), icon: const Icon(Icons.zoom_in)),
        IconButton(tooltip: 'Reset zoom', onPressed: () => setState(() {
          _zoomScale = 1.0;
          _zoomController.value = Matrix4.identity();
        }), icon: const Icon(Icons.fit_screen)),
      ]),
      Container(
        height: MediaQuery.of(context).size.height * .52,
        decoration: BoxDecoration(border: Border.all(color: Colors.grey.shade400), borderRadius: BorderRadius.circular(10), color: Colors.white),
        child: InteractiveViewer(
          transformationController: _zoomController,
          minScale: .45, maxScale: 4, panEnabled: true, scaleEnabled: true,
          constrained: false, boundaryMargin: const EdgeInsets.all(80),
          child: child,
        ),
      ),
    ],
  );

  Widget cell(String text,{Color? color,double w=30,double h=30,bool bold=false})=>Container(
    width:w,height:h,alignment:Alignment.center,padding:const EdgeInsets.all(2),
    decoration:BoxDecoration(color:color,border:Border.all(color:Colors.grey.shade400)),
    child:Text(text,textAlign:TextAlign.center,style:TextStyle(fontSize:10,fontWeight:bold?FontWeight.bold:FontWeight.normal,color:color!=null && color.computeLuminance()<.25?Colors.white:Colors.black)));

  Widget report1Preview(){
    final ds=days();
    return Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      for(final g in selectedGuts()) ...[
        Padding(padding:const EdgeInsets.all(8),child:Text('GUT ${g.no} • ${g.crop}',style:const TextStyle(fontSize:16,fontWeight:FontWeight.bold))),
        SingleChildScrollView(scrollDirection:Axis.horizontal,child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Row(children:[cell('तारीख',w:55,bold:true),for(var r=1;r<=50;r++)cell('$r',bold:true)]),
          for(final d in ds) Row(children:[cell(ddmmyy(d),w:55,bold:true),for(var r=1;r<=50;r++)cell('',color:r>rowCount(g)?Colors.black:(statusFor(g,r,d)=='red'?Colors.red:statusFor(g,r,d)=='yellow'?Colors.yellow:Colors.green))])
        ])),
        const SizedBox(height:16)
      ]
    ]);
  }

  List<String> _sourceEntries(String source, DateTime d) {
    final entries = <String>[];
    for (final g in selectedGuts()) {
      final rows = <int>[];
      for (var r = 1; r <= rowCount(g); r++) {
        if (activeSourceFor(g, r, d) == source) rows.add(r);
      }
      if (rows.isEmpty) continue;
      rows.sort();
      final ranges = <String>[];
      var first = rows.first, last = rows.first;
      for (final r in rows.skip(1)) {
        if (r == last + 1) { last = r; } else {
          ranges.add(first == last ? '$first' : '$first-$last');
          first = last = r;
        }
      }
      ranges.add(first == last ? '$first' : '$first-$last');
      entries.add('${g.no} / ${g.crop} / ${ranges.join(', ')}');
    }
    return entries;
  }

  Widget _sourceCell(String source, DateTime d){
    final entries = _sourceEntries(source, d);
    final active = entries.isNotEmpty;
    return Container(width:150,constraints:const BoxConstraints(minHeight:44),padding:const EdgeInsets.all(3),alignment:Alignment.center,decoration:BoxDecoration(color:active?Colors.yellow:Colors.red,border:Border.all(color:Colors.grey.shade400)),child:Text(active?entries.join('\n'):'पाणी चालू नाही',textAlign:TextAlign.center,style:TextStyle(fontSize:9,color:active?Colors.black:Colors.white,fontWeight:FontWeight.w600)));
  }

  Widget report2Preview(){
    final ds=days(); final sources=<String>{...widget.store.sources};
    for(final g in selectedGuts()) for(final e in g.waterHistory) if(e.source.trim().isNotEmpty) sources.add(e.source);
    final list=sources.toList();
    return SingleChildScrollView(scrollDirection:Axis.horizontal,child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Row(children:[cell('तारीख',w:60,bold:true),for(final s in list)cell(s,w:150,bold:true)]),
      for(final d in ds) Row(children:[cell(ddmmyy(d),w:60,bold:true),for(final source in list)_sourceCell(source,d)])
    ]));
  }

  pw.Widget _pdfStatusCell(Gut g, int row, DateTime d){
    final st=row>rowCount(g)?'black':statusFor(g,row,d);
    final c=st=='red'?pwpdf.PdfColors.red:st=='yellow'?pwpdf.PdfColors.yellow:st=='green'?pwpdf.PdfColors.green:pwpdf.PdfColors.black;
    return pw.Container(width:14,height:17,color:c);
  }

  List<pw.Widget> pdf1Widgets(pw.Font font){
    final ds=days();
    final out=<pw.Widget>[];
    for(final g in selectedGuts()) {
      out.add(pw.Text('GUT ${g.no} • ${g.crop}',style:pw.TextStyle(font:font,fontSize:10,fontWeight:pw.FontWeight.bold)));
      out.add(pw.SizedBox(height:3));
      final pdfWidths = <int, pw.TableColumnWidth>{0: pw.FixedColumnWidth(42)};
      for (var c = 1; c <= 50; c++) { pdfWidths[c] = pw.FixedColumnWidth(14); }
      out.add(pw.Table(
        border:pw.TableBorder.all(width:.3),
        columnWidths: pdfWidths,
        defaultVerticalAlignment:pw.TableCellVerticalAlignment.middle,
        children:[
          pw.TableRow(children:[
            pw.Container(width:42,height:16,alignment:pw.Alignment.center,child:pw.Text('तारीख',style:pw.TextStyle(font:font,fontSize:5,fontWeight:pw.FontWeight.bold))),
            for(var r=1;r<=50;r++) pw.Container(width:14,height:16,alignment:pw.Alignment.center,child:pw.Text('$r',style:pw.TextStyle(font:font,fontSize:4,fontWeight:pw.FontWeight.bold)))
          ]),
          for(final d in ds) pw.TableRow(children:[
            pw.Container(width:42,height:14,alignment:pw.Alignment.center,child:pw.Text(ddmmyy(d),style:pw.TextStyle(font:font,fontSize:5))),
            for(var r=1;r<=50;r++) _pdfStatusCell(g,r,d)
          ])
        ],
      ));
      out.add(pw.SizedBox(height:8));
    }
    return out;
  }

  pw.Widget _pdfSourceCell(String source, DateTime d, pw.Font font){
    final entries = _sourceEntries(source, d);
    final active = entries.isNotEmpty;
    return pw.Container(width:95,height:42,color:active?pwpdf.PdfColors.yellow:pwpdf.PdfColors.red,alignment:pw.Alignment.center,padding:const pw.EdgeInsets.all(2),child:pw.Text(active?entries.join('\n'):'पाणी चालू नाही',textAlign:pw.TextAlign.center,style:pw.TextStyle(font:font,fontSize:5,color:active?pwpdf.PdfColors.black:pwpdf.PdfColors.white)));
  }

  pw.Widget pdf2(pw.Font font){
    final ds=days(); final sources=<String>{...widget.store.sources};
    for(final g in selectedGuts()) for(final e in g.waterHistory) if(e.source.trim().isNotEmpty) sources.add(e.source);
    final list=sources.toList();
    return pw.Table(border:pw.TableBorder.all(width:.35),children:[
      pw.TableRow(children:[pw.Container(width:45,height:28,alignment:pw.Alignment.center,child:pw.Text('तारीख',style:pw.TextStyle(font:font,fontSize:7))),for(final s in list)pw.Container(width:80,height:28,alignment:pw.Alignment.center,child:pw.Text(s,style:pw.TextStyle(font:font,fontSize:7,fontWeight:pw.FontWeight.bold)))]),
      for(final d in ds) pw.TableRow(children:[pw.Container(width:45,height:34,alignment:pw.Alignment.center,child:pw.Text(ddmmyy(d),style:pw.TextStyle(font:font,fontSize:6))),for(final source in list)_pdfSourceCell(source,d,font)])
    ]);
  }

  Future<void> downloadPdf() async {
    setState(()=>loadingPdf=true);
    try{
      final font=pw.Font.ttf(await rootBundle.load('assets/fonts/Lohit-Devanagari.ttf'));
      final doc=pw.Document();
      final reportWidgets = report == 'date'
          ? pdf1Widgets(font)
          : <pw.Widget>[pdf2(font)];
      doc.addPage(
        pw.MultiPage(
          pageFormat: report == 'date'
              ? pwpdf.PdfPageFormat.a4.landscape
              : pwpdf.PdfPageFormat.a4,
          margin: const pw.EdgeInsets.all(12),
          maxPages: 200,
          theme: pw.ThemeData.withFont(base: font, bold: font),
          build: (ctx) => <pw.Widget>[
            pw.Text(
              report == 'date'
                  ? 'पाणी Date-wise Report'
                  : 'पाणी स्रोत उपलब्धता Report',
              style: pw.TextStyle(
                font: font,
                fontSize: 13,
                fontWeight: pw.FontWeight.bold,
              ),
            ),
            pw.SizedBox(height: 4),
            pw.Text(
              '${ddmmyy(fromDate)} ते ${ddmmyy(toDate)}',
              style: pw.TextStyle(font: font, fontSize: 7),
            ),
            pw.SizedBox(height: 6),
            ...reportWidgets,
          ],
        ),
      );
      await Printing.sharePdf(bytes:await doc.save(),filename:report=='date'?'Sheti_Report1_Datewise.pdf':'Sheti_Report2_WaterSource.pdf');
    }finally{if(mounted)setState(()=>loadingPdf=false);}
  }

  @override Widget build(BuildContext context){
    final preview=report=='date'?report1Preview():report2Preview();
    return Scaffold(appBar:AppBar(title:Text(report=='date'?'Report 1 • Date-wise':'Report 2 • Water Source')),body:ListView(padding:const EdgeInsets.all(10),children:[
      Row(children:[Expanded(child:OutlinedButton(onPressed:pickFrom,child:Text('From: ${ddmmyy(fromDate)}'))),const SizedBox(width:8),Expanded(child:OutlinedButton(onPressed:pickTo,child:Text('To: ${ddmmyy(toDate)}')))]),
      const SizedBox(height:8),
      Row(children:[Expanded(child:OutlinedButton(onPressed:()=>setState(()=>report='date'),child:const Text('Report 1 • Date-wise'))),const SizedBox(width:8),Expanded(child:OutlinedButton(onPressed:()=>setState(()=>report='source'),child:const Text('Report 2 • Water Source')))]),
      if(report=='date')...[
        const SizedBox(height:8),DropdownButtonFormField<String>(value:gutFilter,decoration:const InputDecoration(labelText:'GUT Selection'),items:[const DropdownMenuItem(value:'All',child:Text('All GUT')),...widget.store.guts.map((g)=>DropdownMenuItem(value:g.no,child:Text('GUT ${g.no}')))],onChanged:(v){if(v!=null)setState(()=>gutFilter=v);})
      ],
      const SizedBox(height:10),Text('Preview • Zoom In / Zoom Out',style:const TextStyle(fontWeight:FontWeight.bold)),const SizedBox(height:6),zoomPreview(preview),const SizedBox(height:10),
      FilledButton.icon(onPressed:loadingPdf?null:downloadPdf,icon:const Icon(Icons.picture_as_pdf),label:Text(report=='date'?'PDF Download • A4 Landscape':'PDF Download • A4 Portrait')),
      const SizedBox(height:8),const Text('🔴 लाल = पाणी नाही  •  🟡 पाणी सुरू  •  🟢 OFF नंतर 15 दिवस  •  ⬛ सरी नाही',style:TextStyle(fontSize:12))
    ]));
  }
}
