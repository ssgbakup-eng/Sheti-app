Sheti App V25 (versionName 4.3.0, versionCode 25)

Base: Sheti_V4_24.zip. Existing Android application ID and release signing configuration are retained for direct upgrade compatibility.

V25 changes: seven locked requirements from the V24 discussion: display-matching Report 1 PDF grid; edit/cancel/add water history records with dated state recalculation; GUT selection on water control; currently-running row ranges default to OFF action; prompt to mark following rows Red when restarting water before the 15-day Green period ends; confirmation before water ON; delete selected water source with confirmation.

Build: use the existing Flutter/GitHub Actions workflow and signing setup. Test the APK on a device before production use.
