# Sheti App V4.0.2 Final

Base: Sheti_V4_0_Fixed5.zip

Final Plot requirements implemented:
- Existing GUT/Plot update flow retained.
- Saved Plot Map remains visible in GUT Update.
- Continuous single plot map; no middle break.
- Single unified pan/zoom interaction for full Plot Map.
- Two reference numbers for each row, shown at both sides; no numbering in the plot middle.
- Row strips shown as box-type cells.
- Four-side land marks shown around the map.
- 3D-style perspective Plot Map.
- Pinch zoom and drag/pan.
- Remaining/pending rows shown red; currently watering rows yellow.
- Existing GUT data stored with SharedPreferences.

Android update identity:
- applicationId: com.example.sheti_app
- release signing files included from the established Sheti release signing set.
- versionName: 4.0.2
- versionCode: 8
