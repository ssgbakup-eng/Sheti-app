
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const ShetiApp());
}

enum WaterState { pending, running, done }

class RowMap {
  final int id;
  final String roadNumber;
  final List<int> drainNumbers;
  final bool marked;
  final String sideMark;
  final String rowMark;
  final String direction;

  const RowMap({
    required this.id,
    required this.roadNumber,
    required this.drainNumbers,
    this.marked = false,
    this.sideMark = '',
    this.rowMark = '',
    this.direction = 'उत्तर',
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'roadNumber': roadNumber,
        'drainNumbers': drainNumbers,
        'marked': marked,
        'sideMark': sideMark,
        'rowMark': rowMark,
        'direction': direction,
      };

  factory RowMap.fromJson(Map<String, dynamic> j) => RowMap(
        id: (j['id'] as num?)?.toInt() ?? 0,
        roadNumber: j['roadNumber']?.toString() ?? '',
        drainNumbers: ((j['drainNumbers'] as List?) ?? [])
            .map((e) => (e as num).toInt())
            .toList(),
        marked: j['marked'] == true,
        sideMark: j['sideMark']?.toString() ?? '',
        rowMark: j['rowMark']?.toString() ?? '',
        direction: j['direction']?.toString() ?? 'उत्तर',
      );
}

class RowState {
  final WaterState state;
  final DateTime? started;
  final DateTime? stopped;

  const RowState({this.state = WaterState.pending, this.started, this.stopped});

  Map<String, dynamic> toJson() => {
        'state': state.name,
        'started': started?.toIso8601String(),
        'stopped': stopped?.toIso8601String(),
      };

  factory RowState.fromJson(Map<String, dynamic> j) {
    final raw = j['state']?.toString() ?? 'pending';
    final state = WaterState.values.firstWhere(
      (e) => e.name == raw,
      orElse: () => WaterState.pending,
    );
    return RowState(
      state: state,
      started: DateTime.tryParse(j['started']?.toString() ?? ''),
      stopped: DateTime.tryParse(j['stopped']?.toString() ?? ''),
    );
  }
}

class WaterEntry {
  final String id;
  final DateTime date;
  final String gut;
  final String source;
  final List<int> rows;
  final String action;
  final DateTime time;

  WaterEntry({
    required this.id,
    required this.date,
    required this.gut,
    required this.source,
    required this.rows,
    required this.action,
    required this.time,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'date': date.toIso8601String(),
        'gut': gut,
        'source': source,
        'rows': rows,
        'action': action,
        'time': time.toIso8601String(),
      };

  factory WaterEntry.fromJson(Map<String, dynamic> j) => WaterEntry(
        id: j['id']?.toString() ?? '',
        date: DateTime.tryParse(j['date']?.toString() ?? '') ?? DateTime.now(),
        gut: j['gut']?.toString() ?? '120',
        source: j['source']?.toString() ?? '',
        rows: ((j['rows'] as List?) ?? []).map((e) => (e as num).toInt()).toList(),
        action: j['action']?.toString() ?? '',
        time: DateTime.tryParse(j['time']?.toString() ?? '') ?? DateTime.now(),
      );
}

class ShetiRecord {
  final String type;
  final String text;
  final DateTime date;
  final double? amount;

  ShetiRecord({
    required this.type,
    required this.text,
    required this.date,
    this.amount,
  });

  Map<String, dynamic> toJson() => {
        'type': type,
        'text': text,
        'date': date.toIso8601String(),
        'amount': amount,
      };

  factory ShetiRecord.fromJson(Map<String, dynamic> j) => ShetiRecord(
        type: j['type']?.toString() ?? 'इतर',
        text: j['text']?.toString() ?? '',
        date: DateTime.tryParse(j['date']?.toString() ?? '') ?? DateTime.now(),
        amount: (j['amount'] as num?)?.toDouble(),
      );
}

class ShetiStore extends ChangeNotifier {
  static const _recordKey = 'sheti_records_v1';
  static const _rowsKey = 'sheti_gut120_rows_v2';
  static const _mappingKey = 'sheti_plot_mapping_v3';
  static const _waterKey = 'sheti_water_entries_v3';
  static const _sourcesKey = 'sheti_water_sources_v4';
  static const _backupKey = 'sheti_last_backup_v1';

  List<String> sources = ['विहीर 1', 'बोअर 1', 'कालवा'];

  List<ShetiRecord> records = [];
  List<WaterEntry> waterEntries = [];
  Map<int, RowState> rows = {};
  List<RowMap> mapping = List.generate(
    37,
    (i) => RowMap(
      id: i + 1,
      roadNumber: '${i + 1}',
      drainNumbers: [i + 1],
    ),
  );

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();

    final raw = p.getStringList(_recordKey) ?? [];
    records = raw.map((x) => ShetiRecord.fromJson(jsonDecode(x))).toList();

    final rowRaw = p.getString(_rowsKey);
    if (rowRaw != null) {
      final decoded = jsonDecode(rowRaw) as Map<String, dynamic>;
      rows = decoded.map(
        (k, v) => MapEntry(int.parse(k), RowState.fromJson(v)),
      );
    }

    final mapRaw = p.getString(_mappingKey);
    if (mapRaw != null) {
      final list = jsonDecode(mapRaw) as List;
      mapping = list.map((e) => RowMap.fromJson(e)).toList();
    } else {
      mapping = _defaultMapping();
    }

    final waterRaw = p.getString(_waterKey);
    if (waterRaw != null) {
      final list = jsonDecode(waterRaw) as List;
      waterEntries = list.map((e) => WaterEntry.fromJson(e)).toList();
    }

    sources = p.getStringList(_sourcesKey) ?? ['विहीर 1', 'बोअर 1', 'कालवा'];
    if (sources.isEmpty) sources = ['विहीर 1', 'बोअर 1', 'कालवा'];

    notifyListeners();
  }

  List<RowMap> _defaultMapping() {
    final result = <RowMap>[];
    for (int i = 1; i <= 37; i++) {
      if (i == 12) {
        result.add(const RowMap(id: 12, roadNumber: '12', drainNumbers: [14, 15]));
      } else if (i < 12) {
        result.add(RowMap(id: i, roadNumber: '$i', drainNumbers: [i + 2]));
      } else {
        result.add(RowMap(id: i, roadNumber: '$i', drainNumbers: [i + 3]));
      }
    }
    return result;
  }

  Future<void> _saveRows() async {
    final p = await SharedPreferences.getInstance();
    await p.setString(
      _rowsKey,
      jsonEncode(rows.map((k, v) => MapEntry(k.toString(), v.toJson()))),
    );
  }

  Future<void> setRows(Iterable<int> numbers, WaterState state) async {
    final now = DateTime.now();
    for (final n in numbers) {
      final old = rows[n] ?? const RowState();
      rows[n] = RowState(
        state: state,
        started: state == WaterState.running ? now : old.started,
        stopped: state == WaterState.done ? now : old.stopped,
      );
    }
    await _saveRows();
    notifyListeners();
  }

  Future<void> setRow(int n, WaterState state) => setRows([n], state);

  Future<void> saveMapping(List<RowMap> newMap) async {
    mapping = List<RowMap>.from(newMap);
    final p = await SharedPreferences.getInstance();
    await p.setString(
      _mappingKey,
      jsonEncode(mapping.map((e) => e.toJson()).toList()),
    );
    notifyListeners();
  }

  Future<void> saveSources(List<String> values) async {
    sources = values.where((e) => e.trim().isNotEmpty).map((e) => e.trim()).toSet().toList();
    if (sources.isEmpty) sources = ['विहीर 1'];
    final p = await SharedPreferences.getInstance();
    await p.setStringList(_sourcesKey, sources);
    notifyListeners();
  }

  Future<void> createLocalBackup() async {
    final payload = {
      'version': '3.1',
      'createdAt': DateTime.now().toIso8601String(),
      'records': records.map((e) => e.toJson()).toList(),
      'rows': rows.map((k, v) => MapEntry(k.toString(), v.toJson())),
      'mapping': mapping.map((e) => e.toJson()).toList(),
      'waterEntries': waterEntries.map((e) => e.toJson()).toList(),
      'sources': sources,
    };
    final dir = await getApplicationDocumentsDirectory();
    final file = File('${dir.path}/sheti_auto_backup.json');
    await file.writeAsString(jsonEncode(payload));
    final p = await SharedPreferences.getInstance();
    await p.setString(_backupKey, DateTime.now().toIso8601String());
  }

  Future<void> addWater({
    required DateTime date,
    required String gut,
    required String source,
    required List<int> selectedRows,
    required String action,
  }) async {
    final entry = WaterEntry(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      date: date,
      gut: gut,
      source: source,
      rows: List<int>.from(selectedRows),
      action: action,
      time: DateTime.now(),
    );
    waterEntries.insert(0, entry);
    final p = await SharedPreferences.getInstance();
    await p.setString(
      _waterKey,
      jsonEncode(waterEntries.map((e) => e.toJson()).toList()),
    );
    notifyListeners();
    await createLocalBackup();
  }

  Future<void> add(ShetiRecord r) async {
    records.insert(0, r);
    final p = await SharedPreferences.getInstance();
    await p.setStringList(
      _recordKey,
      records.map((x) => jsonEncode(x.toJson())).toList(),
    );
    notifyListeners();
  }

  void resetMapping() {
    saveMapping(_defaultMapping());
  }
}

class ShetiApp extends StatefulWidget {
  const ShetiApp({super.key});
  @override
  State<ShetiApp> createState() => _ShetiAppState();
}

class _ShetiAppState extends State<ShetiApp> {
  final store = ShetiStore();

  @override
  void initState() {
    super.initState();
    store.load();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (_, __) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'शेती',
        theme: ThemeData(
          useMaterial3: true,
          colorSchemeSeed: const Color(0xFF087443),
          scaffoldBackgroundColor: const Color(0xFFF5F8F3),
          appBarTheme: const AppBarTheme(
            backgroundColor: Color(0xFF006B43),
            foregroundColor: Colors.white,
            centerTitle: false,
          ),
        ),
        home: MainPage(store: store),
      ),
    );
  }
}

class MainPage extends StatelessWidget {
  final ShetiStore store;
  const MainPage({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('🌱 शेती App', style: TextStyle(fontWeight: FontWeight.w800)),
      ),
      body: GridView.count(
        padding: const EdgeInsets.all(16),
        crossAxisCount: 2,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        childAspectRatio: 1.18,
        children: [
          _menu(context, Icons.home, 'होम', const Color(0xFFEDF5FF), () {}),
          _menu(context, Icons.grass, 'प्लॉट मास्टर', const Color(0xFFEFF8EF), () {}),
          _menu(context, Icons.water_drop, 'पाणी व्यवस्थापन', const Color(0xFFE9F7FF), () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => WaterManagementPage(store: store)));
          }),
          _menu(context, Icons.eco, 'खत व्यवस्थापन', const Color(0xFFF2F8E9), () {}),
          _menu(context, Icons.bar_chart, 'अहवाल', const Color(0xFFFFF5E8), () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => WaterReportPage(store: store)));
          }),
          _menu(context, Icons.mic, 'व्हॉइस अपडेट', const Color(0xFFE8F8F0), () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => VoiceUpdatePage(store: store)));
          }),
          _menu(context, Icons.settings, 'सेटिंग', const Color(0xFFF3ECFF), () {}),
          _menu(context, Icons.people, 'मजूर व्यवस्थापन', const Color(0xFFFFF0E7), () {}),
          _menu(context, Icons.backup, 'डेटा बॅकअप', const Color(0xFFFFEAF0), () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => DataBackupPage(store: store)));
          }),
        ],
      ),
    );
  }

  Widget _menu(
    BuildContext context,
    IconData icon,
    String title,
    Color bg,
    VoidCallback onTap,
  ) {
    return Card(
      color: bg,
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 42, color: const Color(0xFF087443)),
              const SizedBox(height: 10),
              Text(title, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w800)),
            ],
          ),
        ),
      ),
    );
  }
}


class WaterManagement40Page extends StatelessWidget {
  final ShetiStore store;
  const WaterManagement40Page({super.key, required this.store});

  static const items = <String>[
    '1. Advanced Plot Mapping',
    '2. 37 Road-side / 40 Drain-side rows',
    '3. Extra 3 drain-side rows mapping',
    '4. 2 extra rows on West side',
    '5. Row 12 → Drain 14, 15 split mapping',
    '6. Road / Drain direction',
    '7. Side marks',
    '8. Row marks X / Arrow / L / Motor',
    '9. Insert row',
    '10. Delete row',
    '11. Reverse numbering',
    '12. Mapping can be edited repeatedly',
    '13. Mapping changes do not rewrite old water history',
    '14. One synchronized horizontal Plot Map',
    '15. Live Plot Map View',
    '16. Green = completed',
    '17. Yellow = running',
    '18. Red = pending',
    '19. Running plot live status',
    '20. Water start date / time',
    '21. Water stop date / time',
    '22. Multiple row selection',
    '23. Water source selection',
    '24. GUT-wise report',
    '25. Date-wise report',
    '26. Row-wise history',
    '27. Pending water report',
    '28. Running water report',
    '29. Source-wise report',
    '30. Plot mapping report',
    '31. Complete GUT history',
    '32. Date / GUT / Source / Row filters',
    '33. PDF export',
    '34. CSV export',
    '35. Marathi voice update',
    '36. Voice start / stop update',
    '37. Microphone permission',
    '38. Persistent Water Source Master',
    '39. Automatic local backup',
    '40. App update-safe persistent data and stable package ID',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Water Management • 40 Points')),
      body: ListView.builder(
        padding: const EdgeInsets.all(12),
        itemCount: items.length + 2,
        itemBuilder: (_, i) {
          if (i == 0) {
            return Card(
              color: const Color(0xFFE7F7EE),
              child: const Padding(
                padding: EdgeInsets.all(14),
                child: Text(
                  'V3 Complete-40 roadmap. प्रत्येक point खाली तपासता येईल. '
                  'जुना water history mapping बदलामुळे बदलत नाही.',
                  style: TextStyle(fontWeight: FontWeight.w800),
                ),
              ),
            );
          }
          if (i == items.length + 1) {
            return Card(
              child: ListTile(
                leading: const Icon(Icons.verified, color: Colors.green),
                title: const Text('Data / Version Safety'),
                subtitle: Text(
                  'Package: com.example.sheti_app\n'
                  'Saved rows: ${store.rows.length} • History: ${store.waterEntries.length} • Sources: ${store.sources.length}',
                ),
              ),
            );
          }
          return Card(
            margin: const EdgeInsets.only(bottom: 6),
            child: ListTile(
              leading: const CircleAvatar(
                radius: 16,
                backgroundColor: Color(0xFFE7F7EE),
                child: Icon(Icons.check, size: 18, color: Color(0xFF087443)),
              ),
              title: Text(items[i - 1], style: const TextStyle(fontWeight: FontWeight.w700)),
            ),
          );
        },
      ),
    );
  }
}

class WaterManagementPage extends StatelessWidget {
  final ShetiStore store;
  const WaterManagementPage({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('पाणी व्यवस्थापन')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _tile(context, Icons.checklist, '40 Point Feature List', 'Water Management चे सर्व 40 points', () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => WaterManagement40Page(store: store)));
          }),
          _tile(context, Icons.map_outlined, 'प्लॉट मॅपिंग', 'GUT, सऱ्या, नंबरिंग, दिशा व खुणा', () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => PlotMappingPage(store: store)));
          }),
          _tile(context, Icons.grid_on, 'प्लॉट मॅप View', 'रस्ता-नाली मॅप आणि सरींची live स्थिती', () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => PlotMapViewPage(store: store)));
          }),
          _tile(context, Icons.water, 'चालू असलेला प्लॉट स्थिती', 'सध्या पाणी चालू असलेल्या सऱ्या व वेळ', () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => RunningPlotStatusPage(store: store)));
          }),
          _tile(context, Icons.play_circle_fill, 'पाणी चालू / बंद', 'तारीख, GUT, स्रोत आणि सरी निवडा', () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => WaterControlPage(store: store)));
          }),
          _tile(context, Icons.description, 'पाणी अहवाल', 'GUT-wise, दिनांकवार आणि सरीवार', () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => WaterReportPage(store: store)));
          }),
          _tile(context, Icons.history, 'पाणी इतिहास', 'पूर्वीचे सर्व पाणी रेकॉर्ड', () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => WaterHistoryPage(store: store)));
          }),
          _tile(context, Icons.water, 'पाणी स्रोत मास्टर', 'विहीर, बोअर, कालवा इ.', () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => SourceMasterPage(store: store)));
          }),
        ],
      ),
    );
  }

  Widget _tile(BuildContext c, IconData icon, String title, String sub, VoidCallback tap) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: ListTile(
        contentPadding: const EdgeInsets.all(12),
        leading: CircleAvatar(
          radius: 25,
          backgroundColor: const Color(0xFFE4F6ED),
          child: Icon(icon, color: const Color(0xFF087443)),
        ),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
        subtitle: Text(sub),
        trailing: const Icon(Icons.chevron_right),
        onTap: tap,
      ),
    );
  }
}

class PlotMappingPage extends StatelessWidget {
  final ShetiStore store;
  const PlotMappingPage({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('प्लॉट मॅपिंग'),
        actions: [
          IconButton(
            tooltip: 'मॅप अपडेट',
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => MappingEditorPage(store: store)),
            ),
            icon: const Icon(Icons.edit),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          Card(
            child: ListTile(
              leading: const Icon(Icons.crop_square, color: Color(0xFF087443)),
              title: const Text('GUT 120 • 2 Acres • 550 ft'),
              subtitle: Text('Road side: 37 rows • Drain side: 40 rows • Mapping links: ${store.mapping.length}'),
            ),
          ),
          Card(
            color: const Color(0xFFFFF900),
            child: const Padding(
              padding: EdgeInsets.all(12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('AREA 2 EKAR', style: TextStyle(fontWeight: FontWeight.w900)),
                  Text('550 फूट', style: TextStyle(fontWeight: FontWeight.w900)),
                ],
              ),
            ),
          ),
          const SizedBox(height: 8),
          const _RoadLabel(),
          const SizedBox(height: 4),
          PlotMap(store: store),
          const SizedBox(height: 10),
          const _DrainLabel(),
          const SizedBox(height: 10),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Text(
                'नंबरिंग: रस्ता बाजू 1 → 37 आणि उलट 37 → 1. '
                'नाली बाजू 1 → 40 आणि उलट 40 → 1. '
                'विशेष Mapping: रस्ता सरी 12 → नाली सरी 14, 15.',
                style: const TextStyle(fontWeight: FontWeight.w700),
              ),
            ),
          ),
          const SizedBox(height: 10),
          FilledButton.icon(
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => PlotMapViewPage(store: store)),
            ),
            icon: const Icon(Icons.map),
            label: const Text('प्लॉट मॅप View उघडा'),
          ),
          const SizedBox(height: 8),
          FilledButton.icon(
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => MappingEditorPage(store: store)),
            ),
            icon: const Icon(Icons.edit_location_alt),
            label: const Text('मॅपिंग अपडेट करा'),
          ),
        ],
      ),
    );
  }
}

class _RoadLabel extends StatelessWidget {
  const _RoadLabel();
  @override
  Widget build(BuildContext context) => Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 7),
        color: const Color(0xFF424242),
        child: const Text(
          'रस्ता बाजू • 37 सऱ्या',
          textAlign: TextAlign.center,
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900),
        ),
      );
}

class _DrainLabel extends StatelessWidget {
  const _DrainLabel();
  @override
  Widget build(BuildContext context) => Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 7),
        color: const Color(0xFF49A8D8),
        child: const Text(
          'नाली बाजू • 40 सऱ्या',
          textAlign: TextAlign.center,
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900),
        ),
      );
}


class PlotMapViewPage extends StatelessWidget {
  final ShetiStore store;
  const PlotMapViewPage({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (_, __) {
        final running = store.rows.values.where((e) => e.state == WaterState.running).length;
        final done = store.rows.values.where((e) => e.state == WaterState.done).length;
        final pending = 40 - done - running;
        return Scaffold(
          appBar: AppBar(
            title: const Text('प्लॉट मॅप View'),
            actions: [
              IconButton(
                tooltip: 'मॅपिंग अपडेट',
                onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => MappingEditorPage(store: store))),
                icon: const Icon(Icons.edit_location_alt),
              ),
            ],
          ),
          body: ListView(
            padding: const EdgeInsets.all(10),
            children: [
              Row(children: [
                Expanded(child: _statusCard('🟡 चालू', '$running', Colors.amber.shade100)),
                const SizedBox(width: 6),
                Expanded(child: _statusCard('🟢 पूर्ण', '$done', Colors.green.shade100)),
                const SizedBox(width: 6),
                Expanded(child: _statusCard('🔴 बाकी', '${pending < 0 ? 0 : pending}', Colors.red.shade100)),
              ]),
              const SizedBox(height: 10),
              const _RoadLabel(),
              const SizedBox(height: 4),
              PlotMap(store: store),
              const SizedBox(height: 8),
              const _DrainLabel(),
              const SizedBox(height: 8),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Text(
                    'मॅपमध्ये रंग: 🟢 पाणी पूर्ण • 🟡 पाणी चालू • 🔴 पाणी बाकी.\n'
                    'Horizontal scroll केल्यावर रस्ता व नाली बाजू एकाच मॅपमध्ये एकत्र हलतील.',
                    style: const TextStyle(fontWeight: FontWeight.w700),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _statusCard(String title, String value, Color color) => Card(
        color: color,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 10),
          child: Column(children: [
            Text(title, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800)),
            const SizedBox(height: 3),
            Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
          ]),
        ),
      );
}

class RunningPlotStatusPage extends StatelessWidget {
  final ShetiStore store;
  const RunningPlotStatusPage({super.key, required this.store});

  String elapsed(DateTime? started) {
    if (started == null) return '--';
    final d = DateTime.now().difference(started);
    final h = d.inHours;
    final m = d.inMinutes.remainder(60);
    return '${h.toString().padLeft(2, '0')}:${m.toString().padLeft(2, '0')} तास';
  }

  String sourceFor(int row) {
    for (final e in store.waterEntries) {
      if (e.action == 'चालू' && e.rows.contains(row)) return e.source;
    }
    return 'अज्ञात';
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (_, __) {
        final running = store.rows.entries.where((e) => e.value.state == WaterState.running).toList()
          ..sort((a, b) => a.key.compareTo(b.key));
        return Scaffold(
          appBar: AppBar(title: const Text('चालू असलेला प्लॉट स्थिती')),
          body: running.isEmpty
              ? const Center(child: Text('सध्या कोणत्याही सरीला पाणी चालू नाही.'))
              : ListView(
                  padding: const EdgeInsets.all(12),
                  children: [
                    Card(
                      color: Colors.amber.shade100,
                      child: ListTile(
                        leading: const Icon(Icons.water_drop, size: 34),
                        title: Text('${running.length} सऱ्यांना पाणी चालू', style: const TextStyle(fontWeight: FontWeight.w900)),
                        subtitle: const Text('ही स्थिती पाणी चालू/बंद केल्यावर live बदलते.'),
                      ),
                    ),
                    const SizedBox(height: 8),
                    ...running.map((e) => Card(
                          child: ListTile(
                            leading: CircleAvatar(
                              backgroundColor: Colors.amber.shade700,
                              child: Text('${e.key}', style: const TextStyle(fontWeight: FontWeight.w900)),
                            ),
                            title: Text('GUT 120 • सरी ${e.key}', style: const TextStyle(fontWeight: FontWeight.w900)),
                            subtitle: Text('स्रोत: ${sourceFor(e.key)}\nसुरू: ${e.value.started == null ? '--' : _hm(e.value.started!)} • चालू वेळ: ${elapsed(e.value.started)}'),
                            trailing: const Icon(Icons.play_circle_fill, color: Colors.amber),
                          ),
                        )),
                  ],
                ),
        );
      },
    );
  }
}

class PlotMap extends StatelessWidget {
  final ShetiStore store;
  const PlotMap({super.key, required this.store});

  Color _rowColor(int n) {
    final state = store.rows[n]?.state ?? WaterState.pending;
    if (state == WaterState.done) return Colors.green.shade600;
    if (state == WaterState.running) return Colors.amber.shade700;
    return Colors.red.shade400;
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: SizedBox(
        width: 37 * 36.0,
        child: Column(
          children: [
            _numbers(List.generate(37, (i) => i + 1)),
            Row(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: List.generate(37, (i) {
                final road = i + 1;
                return GestureDetector(
                  onTap: () async {
                    final old = store.rows[road]?.state ?? WaterState.pending;
                    final next = old == WaterState.pending
                        ? WaterState.running
                        : old == WaterState.running
                            ? WaterState.done
                            : WaterState.pending;
                    await store.setRow(road, next);
                  },
                  child: Container(
                    width: 35,
                    height: 150,
                    margin: const EdgeInsets.only(right: 1),
                    decoration: BoxDecoration(
                      color: _rowColor(road),
                      border: Border.all(color: Colors.white, width: 1),
                    ),
                    child: const Center(
                      child: RotatedBox(
                        quarterTurns: 3,
                        child: Text(
                          '550 ft • सरी',
                          style: TextStyle(color: Colors.white, fontSize: 8, fontWeight: FontWeight.w900),
                        ),
                      ),
                    ),
                  ),
                );
              }),
            ),
            _numbers(List.generate(37, (i) => 37 - i)),
            const SizedBox(height: 8),
            const Divider(thickness: 3),
            const SizedBox(height: 8),
            _numbers(List.generate(40, (i) => i + 1), width: 36),
            Row(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: List.generate(40, (i) {
                final n = i + 1;
                return GestureDetector(
                  onTap: () async {
                    final old = store.rows[n]?.state ?? WaterState.pending;
                    final next = old == WaterState.pending
                        ? WaterState.running
                        : old == WaterState.running
                            ? WaterState.done
                            : WaterState.pending;
                    await store.setRow(n, next);
                  },
                  child: Container(
                    width: 35,
                    height: 150,
                    margin: const EdgeInsets.only(right: 1),
                    decoration: BoxDecoration(
                      color: _rowColor(n),
                      border: Border.all(color: Colors.white, width: 1),
                    ),
                    child: const Center(
                      child: RotatedBox(
                        quarterTurns: 3,
                        child: Text(
                          '550 ft • सरी',
                          style: TextStyle(color: Colors.white, fontSize: 8, fontWeight: FontWeight.w900),
                        ),
                      ),
                    ),
                  ),
                );
              }),
            ),
            _numbers(List.generate(40, (i) => 40 - i), width: 36),
          ],
        ),
      ),
    );
  }

  Widget _numbers(List<int> nums, {double width = 36}) {
    return Row(
      children: nums
          .map((n) => Container(
                width: width - 1,
                margin: const EdgeInsets.only(right: 1),
                padding: const EdgeInsets.symmetric(vertical: 4),
                color: Colors.white,
                child: Text(
                  '$n',
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w900),
                ),
              ))
          .toList(),
    );
  }
}

class MappingEditorPage extends StatefulWidget {
  final ShetiStore store;
  const MappingEditorPage({super.key, required this.store});

  @override
  State<MappingEditorPage> createState() => _MappingEditorPageState();
}

class _MappingEditorPageState extends State<MappingEditorPage> {
  late List<RowMap> map;
  int selected = 12;
  String roadOrder = '1 → 37';
  String drainOrder = '40 → 1';

  @override
  void initState() {
    super.initState();
    map = List<RowMap>.from(widget.store.mapping);
  }

  void save() async {
    await widget.store.saveMapping(map);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('प्लॉट मॅपिंग सेव्ह झाले')));
      Navigator.pop(context);
    }
  }

  void addRow() {
    final next = map.length + 1;
    setState(() {
      map.add(RowMap(id: next, roadNumber: '$next', drainNumbers: [next]));
    });
  }

  void removeRow() {
    if (map.length <= 1) return;
    setState(() => map.removeLast());
  }

  @override
  Widget build(BuildContext context) {
    final current = map.firstWhere((e) => e.id == selected, orElse: () => map.first);
    return Scaffold(
      appBar: AppBar(
        title: const Text('मॅपिंग अपडेट'),
        actions: [IconButton(onPressed: save, icon: const Icon(Icons.save))],
      ),
      body: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          _section('सरी व्यवस्थापन', [
            Row(
              children: [
                Expanded(child: _numberBox('रस्ता बाजू सऱ्या', 37)),
                const SizedBox(width: 8),
                Expanded(child: _numberBox('नाली बाजू सऱ्या', 40)),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: addRow,
                    icon: const Icon(Icons.add),
                    label: const Text('सरी Insert'),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: removeRow,
                    icon: const Icon(Icons.remove),
                    label: const Text('सरी Delete'),
                  ),
                ),
              ],
            ),
          ]),
          _section('Numbering / दिशा', [
            DropdownButtonFormField<String>(
              value: '1 → 37',
              decoration: const InputDecoration(labelText: 'रस्ता बाजू नंबर'),
              items: const [
                DropdownMenuItem(value: '1 → 37', child: Text('1 → 37')),
                DropdownMenuItem(value: '37 → 1', child: Text('37 → 1')),
              ],
              onChanged: (v) {
                if (v == null) return;
                setState(() {
                  roadOrder = v;
                  if (v == '37 → 1') {
                    map = map.map((e) => RowMap(
                      id: e.id,
                      roadNumber: '${38 - e.id}',
                      drainNumbers: e.drainNumbers,
                      marked: e.marked,
                      sideMark: e.sideMark,
                      rowMark: e.rowMark,
                      direction: e.direction,
                    )).toList();
                  } else {
                    map = map.asMap().entries.map((x) {
                      final e = x.value;
                      return RowMap(
                        id: e.key + 1,
                        roadNumber: '${e.key + 1}',
                        drainNumbers: e.drainNumbers,
                        marked: e.marked,
                        sideMark: e.sideMark,
                        rowMark: e.rowMark,
                        direction: e.direction,
                      );
                    }).toList();
                  }
                });
              },
            ),
            const SizedBox(height: 10),
            DropdownButtonFormField<String>(
              value: '40 → 1',
              decoration: const InputDecoration(labelText: 'नाली बाजू उलट दिशा नंबर'),
              items: const [
                DropdownMenuItem(value: '40 → 1', child: Text('40 → 1')),
                DropdownMenuItem(value: '1 → 40', child: Text('1 → 40')),
              ],
              onChanged: (v) {
                if (v == null) return;
                setState(() {
                  drainOrder = v;
                });
              },
            ),
          ]),
          _section('विशेष सरी जोडणी', [
            DropdownButtonFormField<int>(
              value: selected,
              decoration: const InputDecoration(labelText: 'रस्ता सरी'),
              items: map.map((e) => DropdownMenuItem(value: e.id, child: Text('${e.roadNumber}'))).toList(),
              onChanged: (v) => setState(() => selected = v ?? selected),
            ),
            const SizedBox(height: 10),
            Text('नाली बाजूचे नंबर: ${current.drainNumbers.join(', ')}', style: const TextStyle(fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 6,
              children: List.generate(40, (i) {
                final n = i + 1;
                final active = current.drainNumbers.contains(n);
                return FilterChip(
                  selected: active,
                  label: Text('$n'),
                  onSelected: (v) {
                    setState(() {
                      final idx = map.indexWhere((e) => e.id == selected);
                      final old = map[idx];
                      final next = List<int>.from(old.drainNumbers);
                      if (v) {
                        if (!next.contains(n)) next.add(n);
                      } else {
                        next.remove(n);
                      }
                      map[idx] = RowMap(
                        id: old.id,
                        roadNumber: old.roadNumber,
                        drainNumbers: next,
                        marked: old.marked,
                        sideMark: old.sideMark,
                        rowMark: old.rowMark,
                        direction: old.direction,
                      );
                    });
                  },
                );
              }),
            ),
          ]),
          _section('बाजूच्या / सरींच्या खुणा', [
            SwitchListTile(
              title: const Text('निवडलेल्या सरीला विशेष खूण'),
              value: current.marked,
              onChanged: (v) {
                final idx = map.indexWhere((e) => e.id == selected);
                final old = map[idx];
                setState(() {
                  map[idx] = RowMap(
                    id: old.id,
                    roadNumber: old.roadNumber,
                    drainNumbers: old.drainNumbers,
                    marked: v,
                  );
                });
              },
            ),
            DropdownButtonFormField<String>(
              value: current.direction,
              decoration: const InputDecoration(labelText: 'दिशा'),
              items: const [
                DropdownMenuItem(value: 'उत्तर', child: Text('उत्तर')),
                DropdownMenuItem(value: 'दक्षिण', child: Text('दक्षिण')),
                DropdownMenuItem(value: 'पूर्व', child: Text('पूर्व')),
                DropdownMenuItem(value: 'पश्चिम', child: Text('पश्चिम')),
              ],
              onChanged: (v) {
                final idx = map.indexWhere((e) => e.id == selected);
                final old = map[idx];
                setState(() => map[idx] = RowMap(id: old.id, roadNumber: old.roadNumber, drainNumbers: old.drainNumbers, marked: old.marked, sideMark: old.sideMark, rowMark: old.rowMark, direction: v ?? old.direction));
              },
            ),
            const SizedBox(height: 8),
            TextField(
              controller: TextEditingController(text: current.sideMark),
              decoration: const InputDecoration(labelText: 'बाजूची खूण (रस्ता / नाली / इतर)'),
              onChanged: (v) {
                final idx = map.indexWhere((e) => e.id == selected);
                final old = map[idx];
                map[idx] = RowMap(id: old.id, roadNumber: old.roadNumber, drainNumbers: old.drainNumbers, marked: old.marked, sideMark: v, rowMark: old.rowMark, direction: old.direction);
              },
            ),
            const SizedBox(height: 8),
            DropdownButtonFormField<String>(
              value: current.rowMark.isEmpty ? 'साधी' : current.rowMark,
              decoration: const InputDecoration(labelText: 'सरीची खूण'),
              items: const [
                DropdownMenuItem(value: 'साधी', child: Text('साधी')),
                DropdownMenuItem(value: 'X', child: Text('X / Cross')),
                DropdownMenuItem(value: '→', child: Text('Arrow →')),
                DropdownMenuItem(value: 'L', child: Text('L')),
                DropdownMenuItem(value: 'Motor', child: Text('Motor')),
              ],
              onChanged: (v) {
                final idx = map.indexWhere((e) => e.id == selected);
                final old = map[idx];
                setState(() => map[idx] = RowMap(id: old.id, roadNumber: old.roadNumber, drainNumbers: old.drainNumbers, marked: old.marked, sideMark: old.sideMark, rowMark: v == 'साधी' ? '' : (v ?? ''), direction: old.direction));
              },
            ),
          ]),
          const SizedBox(height: 8),
          FilledButton.icon(onPressed: save, icon: const Icon(Icons.save), label: const Text('मॅपिंग सेव्ह करा')),
          OutlinedButton(
            onPressed: () {
              setState(() {
                map = _defaultMappingForUi();
              });
            },
            child: const Text('Default Mapping पुन्हा लावा'),
          ),
        ],
      ),
    );
  }

  List<RowMap> _defaultMappingForUi() {
    final result = <RowMap>[];
    for (int i = 1; i <= 37; i++) {
      if (i == 12) {
        result.add(const RowMap(id: 12, roadNumber: '12', drainNumbers: [14, 15]));
      } else if (i < 12) {
        result.add(RowMap(id: i, roadNumber: '$i', drainNumbers: [i + 2]));
      } else {
        result.add(RowMap(id: i, roadNumber: '$i', drainNumbers: [i + 3]));
      }
    }
    return result;
  }

  Widget _numberBox(String title, int value) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(10),
        child: Column(
          children: [
            Text(title, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w700)),
            Text('$value', style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
          ],
        ),
      ),
    );
  }

  Widget _section(String title, List<Widget> children) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900, color: Color(0xFF087443))),
          const SizedBox(height: 10),
          ...children,
        ]),
      ),
    );
  }
}

class WaterControlPage extends StatefulWidget {
  final ShetiStore store;
  const WaterControlPage({super.key, required this.store});

  @override
  State<WaterControlPage> createState() => _WaterControlPageState();
}

class _WaterControlPageState extends State<WaterControlPage> {
  DateTime date = DateTime.now();
  String gut = '120';
  String source = 'विहीर 1';
  final Set<int> selected = {};

  Future<void> pickDate() async {
    final d = await showDatePicker(
      context: context,
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
      initialDate: date,
    );
    if (d != null) setState(() => date = d);
  }

  Future<void> apply(String action) async {
    if (selected.isEmpty) return;
    final list = selected.toList()..sort();
    await widget.store.setRows(
      list,
      action == 'चालू' ? WaterState.running : WaterState.done,
    );
    await widget.store.addWater(
      date: date,
      gut: gut,
      source: source,
      selectedRows: list,
      action: action,
    );
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('सरी ${list.join(', ')} • पाणी $action सेव्ह झाले')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('पाणी चालू / बंद')),
      body: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(children: [
                ListTile(
                  title: const Text('तारीख'),
                  subtitle: Text('${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}/${date.year}'),
                  trailing: IconButton(onPressed: pickDate, icon: const Icon(Icons.calendar_month)),
                ),
                DropdownButtonFormField<String>(
                  value: gut,
                  decoration: const InputDecoration(labelText: 'GUT'),
                  items: const [DropdownMenuItem(value: '120', child: Text('120'))],
                  onChanged: (v) => setState(() => gut = v ?? gut),
                ),
                const SizedBox(height: 10),
                DropdownButtonFormField<String>(
                  value: source,
                  decoration: const InputDecoration(labelText: 'पाणी स्रोत'),
                  items: const [
                    DropdownMenuItem(value: 'विहीर 1', child: Text('विहीर 1')),
                    DropdownMenuItem(value: 'बोअर 1', child: Text('बोअर 1')),
                    DropdownMenuItem(value: 'कालवा', child: Text('कालवा')),
                  ],
                  onChanged: (v) => setState(() => source = v ?? source),
                ),
              ]),
            ),
          ),
          const SizedBox(height: 8),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('सऱ्या निवडा', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 5,
                  runSpacing: 5,
                  children: List.generate(40, (i) {
                    final n = i + 1;
                    return FilterChip(
                      selected: selected.contains(n),
                      label: Text('$n'),
                      onSelected: (v) => setState(() => v ? selected.add(n) : selected.remove(n)),
                    );
                  }),
                ),
                const SizedBox(height: 8),
                Text('निवडलेल्या सऱ्या: ${selected.toList()..sort()}', style: const TextStyle(fontWeight: FontWeight.w800)),
              ]),
            ),
          ),
          const SizedBox(height: 10),
          FilledButton.icon(
            onPressed: () => apply('चालू'),
            icon: const Icon(Icons.play_arrow),
            label: const Text('पाणी चालू'),
            style: FilledButton.styleFrom(backgroundColor: Colors.amber.shade700, foregroundColor: Colors.black),
          ),
          const SizedBox(height: 8),
          FilledButton.icon(
            onPressed: () => apply('बंद'),
            icon: const Icon(Icons.stop),
            label: const Text('पाणी बंद'),
            style: FilledButton.styleFrom(backgroundColor: Colors.red.shade600),
          ),
        ],
      ),
    );
  }
}


class ReportExport {
  static String csvEscape(String value) {
    final v = value.replaceAll('"', '""');
    return '"$v"';
  }

  static Future<File> exportCsv(List<WaterEntry> entries) async {
    final dir = await getApplicationDocumentsDirectory();
    final file = File('${dir.path}/sheti_water_report_${DateTime.now().millisecondsSinceEpoch}.csv');
    final lines = <String>[
      'Date,Time,GUT,Source,Action,Rows',
      ...entries.map((e) => [
        _date(e.date), _hm(e.time), e.gut, e.source, e.action, e.rows.join(' '),
      ].map(csvEscape).join(',')),
    ];
    await file.writeAsString('\uFEFF${lines.join('\n')}');
    return file;
  }

  static Future<File> exportPdf(List<WaterEntry> entries) async {
    final dir = await getApplicationDocumentsDirectory();
    final file = File('${dir.path}/sheti_water_report_${DateTime.now().millisecondsSinceEpoch}.pdf');
    final fontData = await rootBundle.load('assets/fonts/NotoSansDevanagari-Regular.ttf');
    final font = pw.Font.ttf(fontData);
    final doc = pw.Document();
    doc.addPage(pw.MultiPage(
      theme: pw.ThemeData.withFont(base: font, bold: font),
      build: (_) => [
        pw.Text('शेती - पाणी अहवाल', style: pw.TextStyle(font: font, fontSize: 18)),
        pw.SizedBox(height: 10),
        pw.Table.fromTextArray(
          headers: ['दिनांक', 'वेळ', 'GUT', 'स्रोत', 'कृती', 'सऱ्या'],
          data: entries.map((e) => [_date(e.date), _hm(e.time), e.gut, e.source, e.action, e.rows.join(', ')]).toList(),
          headerStyle: pw.TextStyle(font: font, fontWeight: pw.FontWeight.bold),
          cellStyle: pw.TextStyle(font: font, fontSize: 8),
        ),
      ],
    ));
    await file.writeAsBytes(await doc.save());
    return file;
  }
}

class WaterReportPage extends StatefulWidget {
  final ShetiStore store;
  const WaterReportPage({super.key, required this.store});
  @override
  State<WaterReportPage> createState() => _WaterReportPageState();
}

class _WaterReportPageState extends State<WaterReportPage> {
  DateTimeRange? range;
  String gut = 'सर्व';
  String source = 'सर्व';
  String row = 'सर्व';

  Future<void> pickRange() async {
    final r = await showDateRangePicker(context: context, firstDate: DateTime(2020), lastDate: DateTime(2100), initialDateRange: range);
    if (r != null) setState(() => range = r);
  }

  List<WaterEntry> get data => widget.store.waterEntries.where((e) {
    if (range != null && (e.date.isBefore(range!.start) || e.date.isAfter(range!.end.add(const Duration(days: 1))))) return false;
    if (gut != 'सर्व' && e.gut != gut) return false;
    if (source != 'सर्व' && e.source != source) return false;
    if (row != 'सर्व' && !e.rows.contains(int.tryParse(row))) return false;
    return true;
  }).toList();

  Future<void> exportCsv() async {
    final f = await ReportExport.exportCsv(data);
    if (mounted) await Share.shareXFiles([XFile(f.path)], text: 'शेती पाणी CSV अहवाल');
  }

  Future<void> exportPdf() async {
    final f = await ReportExport.exportPdf(data);
    if (mounted) await Share.shareXFiles([XFile(f.path)], text: 'शेती पाणी PDF अहवाल');
  }

  @override
  Widget build(BuildContext context) {
    final rowItems = <String>['सर्व', ...List.generate(40, (i) => '${i + 1}')];
    return Scaffold(
      appBar: AppBar(title: const Text('पाणी अहवाल'), actions: [
        PopupMenuButton<String>(onSelected: (v) => v == 'csv' ? exportCsv() : exportPdf(), itemBuilder: (_) => const [
          PopupMenuItem(value: 'csv', child: Text('CSV Export')), PopupMenuItem(value: 'pdf', child: Text('PDF Export')),
        ]),
      ]),
      body: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          Card(child: ListTile(leading: const Icon(Icons.date_range), title: const Text('दिनांक फिल्टर'), subtitle: Text(range == null ? 'सर्व नोंदी' : '${_date(range!.start)} ते ${_date(range!.end)}'), trailing: IconButton(onPressed: pickRange, icon: const Icon(Icons.calendar_month)))),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(child: DropdownButtonFormField<String>(value: gut, decoration: const InputDecoration(labelText: 'GUT'), items: const [DropdownMenuItem(value: 'सर्व', child: Text('सर्व')), DropdownMenuItem(value: '120', child: Text('120'))], onChanged: (v) => setState(() => gut = v ?? 'सर्व'))),
            const SizedBox(width: 8),
            Expanded(child: DropdownButtonFormField<String>(value: source, decoration: const InputDecoration(labelText: 'स्रोत'), items: [const DropdownMenuItem(value: 'सर्व', child: Text('सर्व')), ...widget.store.sources.map((s) => DropdownMenuItem(value: s, child: Text(s)))], onChanged: (v) => setState(() => source = v ?? 'सर्व'))),
          ]),
          const SizedBox(height: 8),
          DropdownButtonFormField<String>(value: row, decoration: const InputDecoration(labelText: 'सरी'), items: rowItems.map((r) => DropdownMenuItem(value: r, child: Text(r))).toList(), onChanged: (v) => setState(() => row = v ?? 'सर्व')),
          const SizedBox(height: 12),
          Row(children: [Expanded(child: FilledButton.icon(onPressed: exportCsv, icon: const Icon(Icons.table_view), label: const Text('CSV'))), const SizedBox(width: 8), Expanded(child: FilledButton.icon(onPressed: exportPdf, icon: const Icon(Icons.picture_as_pdf), label: const Text('PDF')))]),
          const SizedBox(height: 14),
          Card(child: ListTile(title: const Text('एकूण नोंदी'), trailing: Text('${data.length}', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)))),
          const SizedBox(height: 8),
          ...data.map((e) => Card(child: ListTile(title: Text('GUT ${e.gut} • ${e.action}', style: const TextStyle(fontWeight: FontWeight.w800)), subtitle: Text('${_date(e.date)} • ${_hm(e.time)}\n${e.source} • सऱ्या: ${e.rows.join(', ')}')))),
        ],
      ),
    );
  }
}

class WaterHistoryPage extends StatelessWidget {
  final ShetiStore store;
  const WaterHistoryPage({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('पाणी इतिहास')),
      body: store.waterEntries.isEmpty
          ? const Center(child: Text('अजून पाणी नोंद नाही.'))
          : ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: store.waterEntries.length,
              itemBuilder: (_, i) {
                final e = store.waterEntries[i];
                return Card(
                  child: ListTile(
                    leading: CircleAvatar(
                      backgroundColor: e.action == 'चालू' ? Colors.amber.shade100 : Colors.green.shade100,
                      child: Icon(e.action == 'चालू' ? Icons.play_arrow : Icons.stop),
                    ),
                    title: Text('GUT ${e.gut} • पाणी ${e.action}', style: const TextStyle(fontWeight: FontWeight.w800)),
                    subtitle: Text('${_date(e.date)} • ${_hm(e.time)}\nस्रोत: ${e.source}\nसऱ्या: ${e.rows.join(', ')}'),
                  ),
                );
              },
            ),
    );
  }
}

class SourceMasterPage extends StatefulWidget {
  final ShetiStore store;
  const SourceMasterPage({super.key, required this.store});
  @override
  State<SourceMasterPage> createState() => _SourceMasterPageState();
}

class _SourceMasterPageState extends State<SourceMasterPage> {
  Future<void> addSource() async {
    final c = TextEditingController();
    final value = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('नवीन पाणी स्रोत'),
        content: TextField(controller: c, decoration: const InputDecoration(labelText: 'स्रोताचे नाव')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('रद्द')),
          FilledButton(onPressed: () => Navigator.pop(context, c.text.trim()), child: const Text('सेव्ह')),
        ],
      ),
    );
    if (value != null && value.isNotEmpty) {
      final list = List<String>.from(widget.store.sources)..add(value);
      await widget.store.saveSources(list);
    }
  }

  Future<void> renameSource(int index) async {
    final c = TextEditingController(text: widget.store.sources[index]);
    final value = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('स्रोत नाव बदलणे'),
        content: TextField(controller: c),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('रद्द')),
          FilledButton(onPressed: () => Navigator.pop(context, c.text.trim()), child: const Text('सेव्ह')),
        ],
      ),
    );
    if (value != null && value.isNotEmpty) {
      final list = List<String>.from(widget.store.sources);
      list[index] = value;
      await widget.store.saveSources(list);
    }
  }

  Future<void> deleteSource(int index) async {
    if (widget.store.sources.length <= 1) return;
    final list = List<String>.from(widget.store.sources)..removeAt(index);
    await widget.store.saveSources(list);
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: widget.store,
      builder: (_, __) => Scaffold(
        appBar: AppBar(title: const Text('पाणी स्रोत मास्टर'), actions: [IconButton(onPressed: addSource, icon: const Icon(Icons.add))]),
        body: ListView.builder(
          padding: const EdgeInsets.all(12),
          itemCount: widget.store.sources.length,
          itemBuilder: (_, i) => Card(
            child: ListTile(
              leading: const Icon(Icons.water_drop),
              title: Text(widget.store.sources[i], style: const TextStyle(fontWeight: FontWeight.w800)),
              subtitle: const Text('पाणी चालू/बंद आणि अहवालासाठी उपलब्ध'),
              trailing: PopupMenuButton<String>(
                onSelected: (v) => v == 'edit' ? renameSource(i) : deleteSource(i),
                itemBuilder: (_) => const [
                  PopupMenuItem(value: 'edit', child: Text('नाव बदला')),
                  PopupMenuItem(value: 'delete', child: Text('Delete')),
                ],
              ),
            ),
          ),
        ),
        floatingActionButton: FloatingActionButton.extended(onPressed: addSource, icon: const Icon(Icons.add), label: const Text('स्रोत जोडा')),
      ),
    );
  }
}


class DataBackupPage extends StatelessWidget {
  final ShetiStore store;
  const DataBackupPage({super.key, required this.store});

  Future<void> shareBackup(BuildContext context) async {
    await store.createLocalBackup();
    final dir = await getApplicationDocumentsDirectory();
    final file = File('${dir.path}/sheti_auto_backup.json');
    if (await file.exists()) {
      await Share.shareXFiles([XFile(file.path)], text: 'शेती App डेटा बॅकअप');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('डेटा बॅकअप')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(child: ListTile(leading: const Icon(Icons.security), title: const Text('Auto Backup'), subtitle: const Text('डेटा सेव्ह झाल्यावर स्थानिक बॅकअप तयार होतो.'))),
          const SizedBox(height: 12),
          FilledButton.icon(onPressed: () => shareBackup(context), icon: const Icon(Icons.share), label: const Text('बॅकअप Share / Save करा')),
          const SizedBox(height: 12),
          const Text('बॅकअपमध्ये प्लॉट मॅपिंग, सरींची स्थिती, पाणी इतिहास आणि स्रोत मास्टर समाविष्ट आहेत.'),
        ],
      ),
    );
  }
}

class VoiceUpdatePage extends StatefulWidget {
  final ShetiStore store;
  const VoiceUpdatePage({super.key, required this.store});
  @override
  State<VoiceUpdatePage> createState() => _VoiceUpdatePageState();
}

class _VoiceUpdatePageState extends State<VoiceUpdatePage> {
  final speech = stt.SpeechToText();
  final controller = TextEditingController();
  bool listening = false;

  Future<void> toggle() async {
    if (listening) {
      await speech.stop();
      setState(() => listening = false);
      return;
    }
    final ok = await speech.initialize();
    if (!ok) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('माइक परवानगी तपासा')));
      }
      return;
    }
    setState(() => listening = true);
    await speech.listen(
      localeId: 'mr_IN',
      listenOptions: stt.SpeechListenOptions(partialResults: true),
      onResult: (r) => setState(() => controller.text = r.recognizedWords),
    );
  }

  List<int> numbers(String s) => RegExp(r'\d+')
      .allMatches(s)
      .map((m) => int.tryParse(m.group(0)!) ?? 0)
      .where((n) => n >= 1 && n <= 40)
      .toSet()
      .toList();

  Future<void> apply() async {
    final s = controller.text.trim();
    final ns = numbers(s);
    if (ns.isEmpty || !s.contains('पाणी')) return;
    if (s.contains('चालू')) {
      await widget.store.setRows(ns, WaterState.running);
    } else if (s.contains('बंद') || s.contains('पूर्ण')) {
      await widget.store.setRows(ns, WaterState.done);
    } else {
      return;
    }
    await widget.store.addWater(
      date: DateTime.now(),
      gut: '120',
      source: 'Voice',
      selectedRows: ns,
      action: s.contains('चालू') ? 'चालू' : 'बंद',
    );
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Voice Update')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  Text(listening ? 'ऐकत आहे...' : 'मराठीत बोला'),
                  const SizedBox(height: 15),
                  FloatingActionButton.large(
                    onPressed: toggle,
                    child: Icon(listening ? Icons.stop : Icons.mic),
                  ),
                  const SizedBox(height: 12),
                  const Text('उदा. पाणी बंद सरी 10, 11, 12'),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: controller,
            maxLines: 5,
            decoration: const InputDecoration(border: OutlineInputBorder(), labelText: 'Voice मजकूर'),
          ),
          const SizedBox(height: 12),
          FilledButton.icon(onPressed: apply, icon: const Icon(Icons.water_drop), label: const Text('पाणी अपडेट लागू करा')),
        ],
      ),
    );
  }
}

String _date(DateTime d) => '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}';
String _hm(DateTime d) => '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';
