# शेती App V2

This V2 upgrades the existing Marathi farming app without changing the Android applicationId (`com.example.sheti_app`) or the existing `sheti_records_v1` storage key.

## V2 features
- Modern Marathi dashboard
- Date + time on manual entries
- Date-range filtering in Reports
- Marathi speech input with Android microphone permission
- Voice water commands such as `पाणी बंद सरी 10, 11, 12` and `पाणी चालू सरी 14, 15`
- GUT No. 120 / 2 acre sugarcane plot view
- 550 ft row scale display
- 37 top-side rows and 40 drain-side rows
- Tap rows to cycle pending → running → done
- Full-row red/yellow/green status
- Persistent row status and existing records across updates
