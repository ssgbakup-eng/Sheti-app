# Sheti App V4.0.5+11
Base: Sheti_V4_0_Final_Fixed8.zip
Final recent changes: small sari boxes; sari notes visible on Plot; water page shows the Plot and allows tapping sari boxes to select; existing app identity retained; base-side numbering drives selection while opposite side is reference; extra south-side rows remain on their side and are selectable; water states are red pending, yellow running, green for 15 days after stop then red.
