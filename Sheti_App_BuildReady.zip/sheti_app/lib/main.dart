import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const ShetiApp());
}

class ShetiRecord {
  final String type;
  final String text;
  final DateTime date;
  final double? amount;

  ShetiRecord({required this.type, required this.text, required this.date, this.amount});

  Map<String, dynamic> toJson() => {
    'type': type,
    'text': text,
    'date': date.toIso8601String(),
    'amount': amount,
  };

  factory ShetiRecord.fromJson(Map<String, dynamic> j) => ShetiRecord(
    type: j['type'] ?? 'इतर',
    text: j['text'] ?? '',
    date: DateTime.tryParse(j['date'] ?? '') ?? DateTime.now(),
    amount: (j['amount'] as num?)?.toDouble(),
  );
}

class ShetiStore extends ChangeNotifier {
  static const _key = 'sheti_records_v1';
  List<ShetiRecord> records = [];

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getStringList(_key) ?? [];
    records = raw.map((x) => ShetiRecord.fromJson(jsonDecode(x))).toList();
    notifyListeners();
  }

  Future<void> add(ShetiRecord r) async {
    records.insert(0, r);
    final p = await SharedPreferences.getInstance();
    await p.setStringList(_key, records.map((x) => jsonEncode(x.toJson())).toList());
    notifyListeners();
  }
}

class ShetiApp extends StatefulWidget {
  const ShetiApp({super.key});
  @override
  State<ShetiApp> createState() => _ShetiAppState();
}

class _ShetiAppState extends State<ShetiApp> {
  final store = ShetiStore();
  int index = 0;

  @override
  void initState() {
    super.initState();
    store.load();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (_, __) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'शेती',
        theme: ThemeData(
          useMaterial3: true,
          colorSchemeSeed: Colors.green,
          fontFamily: 'sans',
        ),
        home: HomePage(store: store, index: index, onIndex: (i) => setState(() => index = i)),
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  final ShetiStore store;
  final int index;
  final ValueChanged<int> onIndex;

  const HomePage({super.key, required this.store, required this.index, required this.onIndex});

  @override
  Widget build(BuildContext context) {
    final pages = [
      Dashboard(store: store, onIndex: onIndex),
      PlanningPage(store: store),
      ReportsPage(store: store),
      HistoryPage(store: store),
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('🌾 शेती')),
      body: pages[index],
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: onIndex,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'मुख्य'),
          NavigationDestination(icon: Icon(Icons.calendar_month_outlined), selectedIcon: Icon(Icons.calendar_month), label: 'नियोजन'),
          NavigationDestination(icon: Icon(Icons.bar_chart_outlined), selectedIcon: Icon(Icons.bar_chart), label: 'रिपोर्ट'),
          NavigationDestination(icon: Icon(Icons.history), label: 'इतिहास'),
        ],
      ),
    );
  }
}

class Dashboard extends StatelessWidget {
  final ShetiStore store;
  final ValueChanged<int> onIndex;
  const Dashboard({super.key, required this.store, required this.onIndex});

  @override
  Widget build(BuildContext context) {
    final recent = store.records.take(4).toList();
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('आजचे शेती व्यवस्थापन', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Text('${store.records.length} नोंदी सेव्ह आहेत.'),
              const SizedBox(height: 16),
              FilledButton.icon(
                onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => VoicePage(store: store))),
                icon: const Icon(Icons.mic),
                label: const Text('🎤 बोलून नोंद करा'),
              ),
            ]),
          ),
        ),
        const SizedBox(height: 12),
        const Text('जलद नोंद', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8, runSpacing: 8,
          children: [
            _quick(context, '💧 पाणी', 'पाणी'),
            _quick(context, '🧪 खत', 'खत'),
            _quick(context, '🚜 मशागत', 'मशागत'),
            _quick(context, '💊 फवारणी', 'फवारणी'),
            _quick(context, '💰 खर्च', 'खर्च'),
          ],
        ),
        const SizedBox(height: 18),
        const Text('अलीकडील नोंदी', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        ...recent.map((r) => ListTile(
          leading: CircleAvatar(child: Text(_icon(r.type))),
          title: Text(r.type),
          subtitle: Text(r.text),
          trailing: Text('${r.date.day}/${r.date.month}'),
        )),
      ],
    );
  }

  String _icon(String t) => {'पाणी':'💧','खत':'🧪','मशागत':'🚜','फवारणी':'💊','खर्च':'💰'}[t] ?? '📝';

  Widget _quick(BuildContext c, String label, String type) => OutlinedButton(
    onPressed: () => Navigator.push(c, MaterialPageRoute(builder: (_) => AddRecordPage(store: store, type: type))),
    child: Text(label),
  );
}

class PlanningPage extends StatelessWidget {
  final ShetiStore store;
  const PlanningPage({super.key, required this.store});
  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      const Text('नियोजन', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      _tile(context, '💧', 'पाणी नियोजन', 'पाणी देण्याची तारीख, वेळ व तास', 'पाणी'),
      _tile(context, '🧪', 'खत नियोजन', 'खताचे नाव, प्रमाण व तारीख', 'खत'),
      _tile(context, '🚜', 'मशागत नियोजन', 'काम, तारीख व क्षेत्र', 'मशागत'),
      _tile(context, '💊', 'फवारणी नियोजन', 'औषध, प्रमाण व तारीख', 'फवारणी'),
      _tile(context, '💰', 'खर्च नोंद', 'शेतीवरील खर्चाची नोंद', 'खर्च'),
    ],
  );

  Widget _tile(BuildContext c, String icon, String title, String sub, String type) => Card(
    child: ListTile(
      leading: Text(icon, style: const TextStyle(fontSize: 28)),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
      subtitle: Text(sub),
      trailing: const Icon(Icons.chevron_right),
      onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => AddRecordPage(store: store, type: type))),
    ),
  );
}

class AddRecordPage extends StatefulWidget {
  final ShetiStore store;
  final String type;
  const AddRecordPage({super.key, required this.store, required this.type});
  @override
  State<AddRecordPage> createState() => _AddRecordPageState();
}

class _AddRecordPageState extends State<AddRecordPage> {
  final controller = TextEditingController();
  final amount = TextEditingController();

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text('${widget.type} नोंद')),
    body: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(children: [
        TextField(controller: controller, maxLines: 4, decoration: const InputDecoration(
          labelText: 'तपशील', hintText: 'उदा. गट 125 ला 6 तास पाणी दिले', border: OutlineInputBorder())),
        const SizedBox(height: 12),
        if (widget.type == 'खर्च') TextField(controller: amount, keyboardType: TextInputType.number,
          decoration: const InputDecoration(labelText: 'रक्कम', prefixText: '₹ ', border: OutlineInputBorder())),
        const Spacer(),
        SizedBox(width: double.infinity, child: FilledButton.icon(
          onPressed: () async {
            if (controller.text.trim().isEmpty) return;
            await widget.store.add(ShetiRecord(
              type: widget.type, text: controller.text.trim(), date: DateTime.now(),
              amount: double.tryParse(amount.text.trim()),
            ));
            if (context.mounted) Navigator.pop(context);
          },
          icon: const Icon(Icons.save), label: const Text('सेव्ह करा'),
        )),
      ]),
    ),
  );
}

class VoicePage extends StatefulWidget {
  final ShetiStore store;
  const VoicePage({super.key, required this.store});
  @override
  State<VoicePage> createState() => _VoicePageState();
}

class _VoicePageState extends State<VoicePage> {
  final speech = stt.SpeechToText();
  final text = TextEditingController();
  bool listening = false;
  String status = 'माइक दाबून मराठीत बोला';

  Future<void> toggle() async {
    if (listening) {
      await speech.stop();
      setState(() { listening = false; status = 'नोंद तपासा आणि सेव्ह करा'; });
      return;
    }
    final ok = await speech.initialize(onStatus: (s) => setState(() => listening = s == 'listening'));
    if (!ok) {
      setState(() => status = 'माइकची परवानगी किंवा Speech सेवा उपलब्ध नाही');
      return;
    }
    setState(() { listening = true; status = 'ऐकत आहे...'; });
    await speech.listen(
      localeId: 'mr_IN',
      onResult: (r) => setState(() => text.text = r.recognizedWords),
    );
  }

  Future<void> save() async {
    if (text.text.trim().isEmpty) return;
    await widget.store.add(ShetiRecord(type: 'Voice Update', text: text.text.trim(), date: DateTime.now()));
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('🎤 Voice Update')),
    body: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(children: [
        Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(children: [
          Text(status, textAlign: TextAlign.center),
          const SizedBox(height: 18),
          FloatingActionButton.large(onPressed: toggle, child: Icon(listening ? Icons.stop : Icons.mic)),
        ]))),
        const SizedBox(height: 16),
        TextField(controller: text, maxLines: 7, decoration: const InputDecoration(
          labelText: 'तुमची नोंद', border: OutlineInputBorder())),
        const Spacer(),
        SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: save, icon: const Icon(Icons.save), label: const Text('नोंद सेव्ह करा'))),
      ]),
    ),
  );
}

class ReportsPage extends StatelessWidget {
  final ShetiStore store;
  const ReportsPage({super.key, required this.store});
  @override
  Widget build(BuildContext context) {
    final counts = <String, int>{};
    for (final r in store.records) counts[r.type] = (counts[r.type] ?? 0) + 1;
    return ListView(padding: const EdgeInsets.all(16), children: [
      const Text('रिपोर्ट', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      ...counts.entries.map((e) => Card(child: ListTile(title: Text(e.key), trailing: Text('${e.value} नोंदी')))),
      if (counts.isEmpty) const Card(child: Padding(padding: EdgeInsets.all(20), child: Text('अजून नोंदी नाहीत.'))),
    ]);
  }
}

class HistoryPage extends StatelessWidget {
  final ShetiStore store;
  const HistoryPage({super.key, required this.store});
  @override
  Widget build(BuildContext context) => ListView.builder(
    padding: const EdgeInsets.all(8),
    itemCount: store.records.length,
    itemBuilder: (_, i) {
      final r = store.records[i];
      return Card(child: ListTile(
        leading: const Icon(Icons.event_note),
        title: Text(r.type),
        subtitle: Text('${r.text}\n${r.date.day}/${r.date.month}/${r.date.year}'),
      ));
    },
  );
}
