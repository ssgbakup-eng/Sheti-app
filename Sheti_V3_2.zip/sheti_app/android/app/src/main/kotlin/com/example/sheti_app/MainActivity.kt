package com.example.sheti_app
import io.flutter.embedding.android.FlutterActivity
class MainActivity: FlutterActivity()
